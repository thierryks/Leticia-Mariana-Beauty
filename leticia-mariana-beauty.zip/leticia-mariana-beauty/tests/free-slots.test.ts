import { describe, expect, it } from "vitest";
import { computeFreeSlots, timeToMinutes } from "@/features/appointments/free-slots";

describe("horários livres", () => {
  const open = timeToMinutes("08:00");
  const close = timeToMinutes("19:00");

  it("dia vazio vira um único horário livre", () => {
    expect(computeFreeSlots([], open, close, 30)).toEqual([{ start: open, end: close }]);
  });

  it("encontra as janelas entre atendimentos e ignora as muito curtas", () => {
    const busy = [
      { start: timeToMinutes("08:30"), end: timeToMinutes("10:15") },
      { start: timeToMinutes("10:30"), end: timeToMinutes("13:45") },
      { start: timeToMinutes("16:00"), end: timeToMinutes("18:00") },
    ];
    expect(computeFreeSlots(busy, open, close, 30)).toEqual([
      { start: timeToMinutes("08:00"), end: timeToMinutes("08:30") },
      { start: timeToMinutes("13:45"), end: timeToMinutes("16:00") },
      { start: timeToMinutes("18:00"), end: timeToMinutes("19:00") },
    ]);
  });

  it("lida com atendimentos sobrepostos e fora do expediente", () => {
    const busy = [
      { start: timeToMinutes("07:00"), end: timeToMinutes("09:00") },
      { start: timeToMinutes("08:30"), end: timeToMinutes("12:00") },
      { start: timeToMinutes("18:30"), end: timeToMinutes("20:00") },
    ];
    expect(computeFreeSlots(busy, open, close, 30)).toEqual([
      { start: timeToMinutes("12:00"), end: timeToMinutes("18:30") },
    ]);
  });
});
