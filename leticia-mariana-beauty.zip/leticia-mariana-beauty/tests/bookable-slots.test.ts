import { describe, expect, it } from "vitest";
import { bookableStartTimes } from "@/features/appointments/agenda";
import { zonedDateTimeToUtc } from "@/lib/datetime";
import type { Appointment, AppointmentStatus } from "@/types/appointment";

const TZ = "America/Sao_Paulo";
const DAY = "2030-01-02"; // quarta-feira
const TOTAL_75 = 75; // 60 min de serviço + 15 min de preparo

function appt(date: string, startTime: string, endTime: string, status: AppointmentStatus = "confirmed"): Appointment {
  const startAt = zonedDateTimeToUtc(date, startTime, TZ);
  const endAt = zonedDateTimeToUtc(date, endTime, TZ);
  return {
    id: `${startTime}-${status}`,
    tenantId: "t1",
    clientId: "c1",
    clientName: "Cliente fictícia",
    serviceId: "s1",
    serviceName: "Fio a fio",
    professionalId: "p1",
    professionalName: "Profissional fictícia",
    startAt,
    endAt,
    status,
    priceInCents: 10_000,
    signalInCents: 0,
    source: "admin",
    createdAt: startAt,
    updatedAt: startAt,
  };
}

function options(appointments: Appointment[], overrides: Partial<Parameters<typeof bookableStartTimes>[0]> = {}) {
  return bookableStartTimes({
    appointments,
    dateKey: DAY,
    todayKey: "2029-12-01",
    timezone: TZ,
    totalMinutes: TOTAL_75,
    nowMinute: 0,
    ...overrides,
  });
}

describe("horários livres para o agendamento", () => {
  it("dia vazio: vai da abertura até o último horário em que o atendimento termina antes do fechamento", () => {
    const times = options([]);
    expect(times[0]).toBe("08:00");
    expect(times.at(-1)).toBe("17:45");
    expect(times).toHaveLength(40);
  });

  it("não oferece horários que encostam em um atendimento ativo", () => {
    const times = options([appt(DAY, "10:00", "11:30")]);
    expect(times).not.toContain("09:00");
    expect(times).not.toContain("10:00");
    expect(times).not.toContain("11:15");
    expect(times).toContain("08:45"); // termina às 10:00, exatamente quando o outro começa
    expect(times).toContain("11:30"); // começa quando o outro termina
  });

  it("o preparo de um atendimento existente também ocupa o horário", () => {
    // Atendimento das 08:00 às 09:15 (já inclui o preparo).
    const times = options([appt(DAY, "08:00", "09:15")]);
    expect(times).not.toContain("08:30");
    expect(times).toContain("09:15");
  });

  it("cancelado, remarcado e falta não ocupam o horário", () => {
    const times = options([
      appt(DAY, "14:00", "15:30", "cancelled_by_client"),
      appt(DAY, "16:00", "17:30", "no_show"),
    ]);
    expect(times).toContain("14:00");
    expect(times).toContain("16:00");
  });

  it("hoje não oferece horários que já passaram, arredondando para o próximo passo", () => {
    const times = options([], { dateKey: DAY, todayKey: DAY, nowMinute: 9 * 60 + 10 });
    expect(times[0]).toBe("09:15");
  });

  it("dia passado não tem horários", () => {
    expect(options([], { dateKey: "2029-12-31", todayKey: DAY })).toEqual([]);
  });

  it("domingo, dia sem atendimento, não tem horários", () => {
    expect(options([], { dateKey: "2030-01-06", todayKey: "2029-12-01" })).toEqual([]);
  });

  it("dia lotado devolve lista vazia", () => {
    const times = options([appt(DAY, "08:00", "19:00")]);
    expect(times).toEqual([]);
  });
});
