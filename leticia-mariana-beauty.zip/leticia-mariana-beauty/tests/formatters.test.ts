import { describe, expect, it } from "vitest";
import { digitsToCents, formatCents, parseBRLToCents } from "@/lib/formatters/currency";
import { formatPhone, maskPhoneInput, normalizeBrazilianPhone } from "@/lib/formatters/phone";

/** Intl usa espaço não separável depois de "R$"; normalizamos para comparar. */
const plain = (value: string) => value.replace(/ /g, " ");

describe("formatação de BRL", () => {
  it("formata centavos inteiros no padrão brasileiro", () => {
    expect(plain(formatCents(18_000))).toBe("R$ 180,00");
    expect(plain(formatCents(123_456))).toBe("R$ 1.234,56");
    expect(plain(formatCents(5))).toBe("R$ 0,05");
    expect(plain(formatCents(0))).toBe("R$ 0,00");
  });

  it("recusa valores que não estão em centavos inteiros", () => {
    expect(() => formatCents(10.5)).toThrow();
  });

  it("converte texto em centavos sem erro de ponto flutuante", () => {
    expect(parseBRLToCents("R$ 1.234,56")).toBe(123_456);
    expect(parseBRLToCents("0,1")).toBe(10);
    expect(parseBRLToCents("80")).toBe(8_000);
    expect(parseBRLToCents("19,99")).toBe(1_999);
    expect(parseBRLToCents("abc")).toBeNull();
    expect(parseBRLToCents("")).toBeNull();
  });

  it("campo monetário trata dígitos como centavos", () => {
    expect(digitsToCents("1")).toBe(1);
    expect(digitsToCents("18000")).toBe(18_000);
    expect(digitsToCents("R$ 180,00")).toBe(18_000);
    expect(digitsToCents("")).toBe(0);
  });
});

describe("normalização de telefone", () => {
  it("aceita as formas mais comuns de digitar um celular", () => {
    const expected = "5521987654321";
    expect(normalizeBrazilianPhone("(21) 98765-4321")).toBe(expected);
    expect(normalizeBrazilianPhone("21987654321")).toBe(expected);
    expect(normalizeBrazilianPhone("+55 21 98765-4321")).toBe(expected);
    expect(normalizeBrazilianPhone("5521987654321")).toBe(expected);
    expect(normalizeBrazilianPhone("021 98765 4321")).toBe(expected);
  });

  it("aceita telefone fixo", () => {
    expect(normalizeBrazilianPhone("(21) 3456-7890")).toBe("552134567890");
  });

  it("recusa números inválidos", () => {
    expect(normalizeBrazilianPhone("")).toBeNull();
    expect(normalizeBrazilianPhone("98765-4321")).toBeNull(); // sem DDD
    expect(normalizeBrazilianPhone("(21) 88765-4321")).toBeNull(); // celular sem 9
    expect(normalizeBrazilianPhone("(01) 98765-4321")).toBeNull(); // DDD inválido
    expect(normalizeBrazilianPhone("(21) 1234-5678")).toBeNull(); // fixo começando em 1
  });

  it("aceita DDD 55 sem confundir com o código do país", () => {
    expect(normalizeBrazilianPhone("(55) 99123-4567")).toBe("5555991234567");
  });

  it("formata para exibição e aplica máscara progressiva", () => {
    expect(formatPhone("5521987654321")).toBe("(21) 98765-4321");
    expect(formatPhone("552134567890")).toBe("(21) 3456-7890");
    expect(maskPhoneInput("2")).toBe("(2");
    expect(maskPhoneInput("2198")).toBe("(21) 98");
    expect(maskPhoneInput("21987654321")).toBe("(21) 98765-4321");
  });
});
