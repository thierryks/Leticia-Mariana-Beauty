import { describe, expect, it } from "vitest";
import { findDuplicateByPhone, matchesClientSearch } from "@/features/clients/rules";
import { EMPTY_CLIENT_FORM, clientFormSchema, toClientInput } from "@/lib/validators/client";
import type { Client } from "@/types/client";

function errorsOf(values: Partial<typeof EMPTY_CLIENT_FORM>) {
  const result = clientFormSchema.safeParse({ ...EMPTY_CLIENT_FORM, ...values });
  if (result.success) return {};
  return Object.fromEntries(result.error.issues.map((issue) => [issue.path.join("."), issue.message]));
}

describe("validação de cliente", () => {
  it("exige nome e telefone", () => {
    const errors = errorsOf({});
    expect(errors.fullName).toBeDefined();
    expect(errors.phone).toBeDefined();
  });

  it("aceita cadastro mínimo válido", () => {
    expect(errorsOf({ fullName: "Maria Exemplo", phone: "(21) 98765-4321" })).toEqual({});
  });

  it("recusa telefone inválido, Instagram inválido e data futura", () => {
    const errors = errorsOf({
      fullName: "Maria Exemplo",
      phone: "1234",
      instagram: "perfil com espaço",
      birthDate: "2999-01-01",
    });
    expect(errors.phone).toMatch(/Telefone inválido/);
    expect(errors.instagram).toBeDefined();
    expect(errors.birthDate).toBeDefined();
  });

  it("normaliza telefone e campos opcionais ao converter", () => {
    const parsed = clientFormSchema.parse({
      ...EMPTY_CLIENT_FORM,
      fullName: "  Maria   Exemplo ",
      phone: "(21) 98765-4321",
      instagram: "maria.exemplo",
    });
    const input = toClientInput(parsed);
    expect(input.fullName).toBe("Maria Exemplo");
    expect(input.phone).toBe("5521987654321");
    expect(input.instagram).toBe("@maria.exemplo");
    expect(input.notes).toBeUndefined();
    expect(input.source).toBeUndefined();
  });
});

describe("duplicidade e busca de cliente", () => {
  const base: Client = {
    id: "cli_1",
    tenantId: "tenant_a",
    fullName: "Letícia Exemplo",
    phone: "5521987654321",
    createdAt: "2026-01-01T00:00:00Z",
    updatedAt: "2026-01-01T00:00:00Z",
    active: true,
  };

  it("alerta duplicidade apenas dentro da mesma empresa", () => {
    const other = { ...base, id: "cli_2", tenantId: "tenant_b" };
    expect(findDuplicateByPhone([base, other], "tenant_a", "5521987654321")?.id).toBe("cli_1");
    expect(findDuplicateByPhone([other], "tenant_a", "5521987654321")).toBeUndefined();
    expect(findDuplicateByPhone([base], "tenant_a", "5521987654321", "cli_1")).toBeUndefined();
  });

  it("busca por nome sem acento e por parte do telefone", () => {
    expect(matchesClientSearch(base, "leticia")).toBe(true);
    expect(matchesClientSearch(base, "98765")).toBe(true);
    expect(matchesClientSearch(base, "(21) 98765-4321")).toBe(true);
    expect(matchesClientSearch(base, "camila")).toBe(false);
  });
});
