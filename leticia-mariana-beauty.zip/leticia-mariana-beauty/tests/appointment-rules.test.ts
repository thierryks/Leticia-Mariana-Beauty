import { describe, expect, it } from "vitest";
import {
  calculateEndAt,
  findConflicts,
  hasConflict,
  intervalsOverlap,
  isBlockingStatus,
  signalState,
  type ScheduleCandidate,
} from "@/features/appointments/rules";
import type { Appointment, AppointmentStatus } from "@/types/appointment";

const TENANT = "tenant_a";

function appointment(overrides: Partial<Appointment> & Pick<Appointment, "startAt" | "endAt">): Appointment {
  return {
    id: "apt_1",
    tenantId: TENANT,
    clientId: "cli_1",
    clientName: "Cliente Teste",
    serviceId: "svc_1",
    serviceName: "Volume brasileiro",
    professionalId: "prof_1",
    professionalName: "Profissional",
    status: "confirmed",
    priceInCents: 22_000,
    signalInCents: 0,
    source: "admin",
    createdAt: "2026-10-01T00:00:00.000Z",
    updatedAt: "2026-10-01T00:00:00.000Z",
    ...overrides,
  };
}

// 09:00–11:45 (150 min + 15 min de intervalo) no horário de Brasília = 12:00–14:45 UTC
const existing = appointment({ startAt: "2026-10-27T12:00:00.000Z", endAt: "2026-10-27T14:45:00.000Z" });

function candidate(startAt: string, endAt: string, overrides: Partial<ScheduleCandidate> = {}): ScheduleCandidate {
  return { tenantId: TENANT, professionalId: "prof_1", startAt, endAt, ...overrides };
}

describe("cálculo do horário final", () => {
  it("soma duração e intervalo de preparação", () => {
    expect(calculateEndAt("2026-10-27T12:00:00.000Z", 150, 15)).toBe("2026-10-27T14:45:00.000Z");
  });

  it("funciona sem intervalo e atravessando a meia-noite UTC", () => {
    expect(calculateEndAt("2026-10-27T23:30:00.000Z", 60, 0)).toBe("2026-10-28T00:30:00.000Z");
  });

  it("rejeita duração inválida", () => {
    expect(() => calculateEndAt("2026-10-27T12:00:00.000Z", 0, 10)).toThrow();
    expect(() => calculateEndAt("2026-10-27T12:00:00.000Z", 60, -5)).toThrow();
    expect(() => calculateEndAt("data-invalida", 60, 0)).toThrow();
  });
});

describe("detecção de conflito", () => {
  it("bloqueia sobreposição parcial com a mesma profissional", () => {
    const c = candidate("2026-10-27T14:00:00.000Z", "2026-10-27T15:00:00.000Z");
    expect(findConflicts(c, [existing])).toHaveLength(1);
  });

  it("bloqueia horário totalmente contido em outro", () => {
    const c = candidate("2026-10-27T12:30:00.000Z", "2026-10-27T13:00:00.000Z");
    expect(hasConflict(c, [existing])).toBe(true);
  });

  it("considera o intervalo de preparação como tempo ocupado", () => {
    // O serviço termina 14:30, mas o preparo vai até 14:45: começar 14:40 conflita.
    const c = candidate("2026-10-27T14:40:00.000Z", "2026-10-27T15:40:00.000Z");
    expect(hasConflict(c, [existing])).toBe(true);
  });

  it("permite começar exatamente quando o anterior termina (com preparo)", () => {
    const c = candidate("2026-10-27T14:45:00.000Z", "2026-10-27T16:00:00.000Z");
    expect(hasConflict(c, [existing])).toBe(false);
  });

  it("não conflita com outra profissional", () => {
    const c = candidate("2026-10-27T12:00:00.000Z", "2026-10-27T13:00:00.000Z", { professionalId: "prof_2" });
    expect(hasConflict(c, [existing])).toBe(false);
  });

  it("não conflita com agendamento de outra empresa", () => {
    const c = candidate("2026-10-27T12:00:00.000Z", "2026-10-27T13:00:00.000Z", { tenantId: "tenant_b" });
    expect(hasConflict(c, [existing])).toBe(false);
  });

  it("ao editar, ignora o próprio agendamento", () => {
    const c = candidate(existing.startAt, existing.endAt, { id: existing.id });
    expect(hasConflict(c, [existing])).toBe(false);
  });

  it("intervalos semiabertos: encostar não é sobrepor", () => {
    expect(intervalsOverlap("2026-10-27T10:00:00Z", "2026-10-27T11:00:00Z", "2026-10-27T11:00:00Z", "2026-10-27T12:00:00Z")).toBe(false);
  });
});

describe("agendamentos cancelados não bloqueiam horário", () => {
  const freeing: AppointmentStatus[] = ["cancelled_by_client", "cancelled_by_business", "rescheduled", "no_show"];

  it.each(freeing)("status %s libera o horário", (status) => {
    const cancelled = { ...existing, status };
    const c = candidate(existing.startAt, existing.endAt);
    expect(isBlockingStatus(status)).toBe(false);
    expect(hasConflict(c, [cancelled])).toBe(false);
  });

  it("um cancelado não impede, mas um ativo no mesmo horário impede", () => {
    const cancelled = { ...existing, id: "apt_cancel", status: "cancelled_by_client" as const };
    const active = { ...existing, id: "apt_active", status: "signal_pending" as const };
    const conflicts = findConflicts(candidate(existing.startAt, existing.endAt), [cancelled, active]);
    expect(conflicts.map((a) => a.id)).toEqual(["apt_active"]);
  });
});

describe("estado do sinal", () => {
  it("identifica sinal pendente, pago e ausente", () => {
    expect(signalState({ status: "signal_pending", signalInCents: 5000 })).toBe("pending");
    expect(signalState({ status: "signal_paid", signalInCents: 5000 })).toBe("paid");
    expect(signalState({ status: "confirmed", signalInCents: 0 })).toBe("none");
  });
});
