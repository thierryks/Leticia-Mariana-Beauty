import { describe, expect, it } from "vitest";
import { buildFinanceSummary, resolvePeriod } from "@/features/finance/summary";
import { zonedDateTimeToUtc } from "@/lib/datetime";
import type { Appointment, AppointmentStatus } from "@/types/appointment";

const TZ = "America/Sao_Paulo";

function appt(
  id: string,
  date: string,
  time: string,
  status: AppointmentStatus,
  priceInCents: number,
  signalInCents: number,
): Appointment {
  const startAt = zonedDateTimeToUtc(date, time, TZ);
  return {
    id,
    tenantId: "t1",
    clientId: "c1",
    clientName: "Cliente fictícia",
    serviceId: "s1",
    serviceName: "Fio a fio",
    professionalId: "p1",
    professionalName: "Profissional fictícia",
    startAt,
    endAt: new Date(new Date(startAt).getTime() + 90 * 60_000).toISOString(),
    status,
    priceInCents,
    signalInCents,
    source: "admin",
    createdAt: startAt,
    updatedAt: startAt,
  };
}

describe("períodos do financeiro", () => {
  it("semana começa na segunda", () => {
    // 2030-01-02 é quarta-feira.
    expect(resolvePeriod("week", "2030-01-02")).toEqual({ startKey: "2029-12-31", endKey: "2030-01-07" });
  });

  it("mês vai do dia 1 ao primeiro dia do mês seguinte, inclusive em dezembro", () => {
    expect(resolvePeriod("month", "2030-01-15")).toEqual({ startKey: "2030-01-01", endKey: "2030-02-01" });
    expect(resolvePeriod("month", "2030-12-15")).toEqual({ startKey: "2030-12-01", endKey: "2031-01-01" });
  });

  it("dia é o próprio dia", () => {
    expect(resolvePeriod("day", "2030-01-02")).toEqual({ startKey: "2030-01-02", endKey: "2030-01-03" });
  });
});

describe("resumo financeiro", () => {
  const range = resolvePeriod("day", "2030-01-02");
  const list = [
    appt("a", "2030-01-02", "09:00", "confirmed", 10_000, 3_000),
    appt("b", "2030-01-02", "11:00", "signal_paid", 8_000, 2_000),
    appt("c", "2030-01-02", "14:00", "cancelled_by_client", 12_000, 4_000),
    appt("d", "2030-01-02", "16:00", "completed", 9_000, 0),
    appt("e", "2030-01-03", "10:00", "confirmed", 15_000, 5_000),
  ];

  it("soma só o que ocupa a agenda e separa sinais pagos e pendentes", () => {
    const summary = buildFinanceSummary(list, range, TZ);
    expect(summary.expectedInCents).toBe(10_000 + 8_000 + 9_000);
    expect(summary.activeCount).toBe(3);
    expect(summary.signalsPaidInCents).toBe(2_000);
    expect(summary.signalsPaidCount).toBe(1);
    expect(summary.signalsPendingInCents).toBe(3_000);
    expect(summary.signalsPendingCount).toBe(1);
    expect(summary.completedInCents).toBe(9_000);
    expect(summary.completedCount).toBe(1);
  });

  it("cancelado não entra no previsto nem nos sinais", () => {
    const summary = buildFinanceSummary([appt("c", "2030-01-02", "14:00", "cancelled_by_client", 12_000, 4_000)], range, TZ);
    expect(summary.expectedInCents).toBe(0);
    expect(summary.signalsPendingInCents).toBe(0);
  });

  it("ignora datas fora do período e agrupa por dia", () => {
    const week = resolvePeriod("week", "2030-01-02");
    const summary = buildFinanceSummary(list, week, TZ);
    expect(summary.days.map((d) => d.dateKey)).toEqual(["2030-01-02", "2030-01-03"]);
    expect(summary.days[1]?.expectedInCents).toBe(15_000);
  });
});
