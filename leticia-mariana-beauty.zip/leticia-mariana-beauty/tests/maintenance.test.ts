import { describe, expect, it } from "vitest";
import { buildClientOverviews } from "@/features/clients/overview";
import type { Appointment } from "@/types/appointment";
import type { Client } from "@/types/client";
import type { Service } from "@/types/service";

const DAY = 86_400_000;
const NOW = Date.UTC(2026, 9, 27, 15, 0);

const client: Client = {
  id: "cli_1",
  tenantId: "t",
  fullName: "Cliente Teste",
  phone: "5521987654321",
  createdAt: new Date(NOW - 200 * DAY).toISOString(),
  updatedAt: new Date(NOW - 200 * DAY).toISOString(),
  active: true,
};

const services: Service[] = [
  { id: "svc_volume", tenantId: "t", name: "Volume", category: "extensao", durationMinutes: 150, preparationIntervalMinutes: 15, priceInCents: 1, active: true },
  { id: "svc_remocao", tenantId: "t", name: "Remoção", category: "remocao", durationMinutes: 30, preparationIntervalMinutes: 10, priceInCents: 1, active: true },
];

function done(serviceId: string, daysAgo: number, overrides: Partial<Appointment> = {}): Appointment {
  const start = new Date(NOW - daysAgo * DAY).toISOString();
  return {
    id: `${serviceId}_${daysAgo}`,
    tenantId: "t",
    clientId: client.id,
    clientName: client.fullName,
    serviceId,
    serviceName: serviceId,
    professionalId: "p",
    professionalName: "P",
    startAt: start,
    endAt: start,
    status: "completed",
    priceInCents: 1,
    signalInCents: 0,
    source: "admin",
    createdAt: start,
    updatedAt: start,
    ...overrides,
  };
}

const stateFor = (appointments: Appointment[]) => buildClientOverviews([client], appointments, services, NOW)[0]!.maintenance.kind;

describe("manutenção sugerida (15 a 20 dias)", () => {
  it("antes de 15 dias ainda não é hora", () => {
    expect(stateFor([done("svc_volume", 10)])).toBe("upcoming");
  });

  it("entre 15 e 20 dias está no prazo", () => {
    expect(stateFor([done("svc_volume", 17)])).toBe("due");
  });

  it("depois de 20 dias está atrasada", () => {
    expect(stateFor([done("svc_volume", 26)])).toBe("overdue");
  });

  it("remoção não gera manutenção", () => {
    expect(stateFor([done("svc_remocao", 40)])).toBe("none");
  });

  it("horário futuro marcado conta como agendada", () => {
    const future = done("svc_volume", -2, { id: "future", status: "confirmed" });
    future.endAt = new Date(NOW + 2 * DAY + 3 * 3_600_000).toISOString();
    expect(stateFor([done("svc_volume", 26), future])).toBe("scheduled");
  });
});
