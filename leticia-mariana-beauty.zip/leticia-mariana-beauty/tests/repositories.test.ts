import { beforeEach, describe, expect, it } from "vitest";
import { createMockDatabase, resetMockDatabase } from "@/mocks/store";
import { DEMO_TENANT_ID, OTHER_TENANT_ID } from "@/mocks/tenants";
import { AppointmentConflictError, DuplicatePhoneError, repositories } from "@/repositories";
import { dateKeyOf, zonedDateTimeToUtc, todayKey } from "@/lib/datetime";

const TZ = "America/Sao_Paulo";

beforeEach(() => {
  resetMockDatabase(createMockDatabase());
});

describe("isolamento entre empresas nos repositórios", () => {
  it("clientes, serviços e agendamentos vêm somente da empresa atual", async () => {
    const [clients, services, appointments] = await Promise.all([
      repositories.clients.list(DEMO_TENANT_ID),
      repositories.services.list(DEMO_TENANT_ID),
      repositories.appointments.listAll(DEMO_TENANT_ID),
    ]);
    for (const row of [...clients, ...services, ...appointments]) {
      expect(row.tenantId).toBe(DEMO_TENANT_ID);
    }
    expect(clients.length).toBeGreaterThanOrEqual(8);
    expect(clients.length).toBeLessThanOrEqual(12);
  });

  it("não encontra registro de outra empresa pelo id", async () => {
    expect(await repositories.clients.getById(DEMO_TENANT_ID, "cli_outra_empresa")).toBeNull();
    const own = await repositories.clients.list(OTHER_TENANT_ID);
    expect(own.map((c) => c.id)).toEqual(["cli_outra_empresa"]);
  });

  it("telefone repetido em outra empresa não gera duplicidade", async () => {
    const created = await repositories.clients.create(OTHER_TENANT_ID, {
      fullName: "Nova de outra empresa",
      phone: "5521900001002",
    });
    expect(created.tenantId).toBe(OTHER_TENANT_ID);
  });

  it("telefone repetido na mesma empresa exige confirmação", async () => {
    await expect(
      repositories.clients.create(DEMO_TENANT_ID, { fullName: "Repetida", phone: "5521900001001" }),
    ).rejects.toBeInstanceOf(DuplicatePhoneError);
  });
});

describe("criação de agendamento", () => {
  it("bloqueia conflito no momento de salvar e aceita horário livre", async () => {
    const today = todayKey(TZ);
    // apt_hoje_3: 11:00 volume russo (180 + 15) com a Letícia → ocupa até 14:15.
    const busyStart = zonedDateTimeToUtc(today, "13:00", TZ);
    await expect(
      repositories.appointments.create(DEMO_TENANT_ID, {
        clientId: "cli_ana",
        serviceId: "svc_remocao",
        professionalId: "prof_leticia",
        startAt: busyStart,
        status: "confirmed",
        signalInCents: 0,
        source: "admin",
      }),
    ).rejects.toBeInstanceOf(AppointmentConflictError);

    // A profissional parceira só atende às 10:00 hoje: 15:00 está livre.
    const freeStart = zonedDateTimeToUtc(today, "15:00", TZ);
    const created = await repositories.appointments.create(DEMO_TENANT_ID, {
      clientId: "cli_ana",
      serviceId: "svc_remocao",
      professionalId: "prof_parceira",
      startAt: freeStart,
      status: "confirmed",
      signalInCents: 0,
      source: "admin",
    });
    expect(created.endAt).toBe(new Date(new Date(freeStart).getTime() + 40 * 60_000).toISOString());
    expect(created.priceInCents).toBe(5_000);
  });

  it("converte horário local para UTC e de volta para a data do studio", () => {
    const iso = zonedDateTimeToUtc("2026-10-27", "09:30", TZ);
    expect(iso).toBe("2026-10-27T12:30:00.000Z");
    expect(dateKeyOf("2026-10-28T02:30:00.000Z", TZ)).toBe("2026-10-27");
  });
});
