import { describe, expect, it } from "vitest";
import { assertSameTenant, scopeToTenant } from "@/lib/tenant-scope";

describe("filtro por tenantId", () => {
  const rows = [
    { id: "1", tenantId: "tenant_a" },
    { id: "2", tenantId: "tenant_b" },
    { id: "3", tenantId: "tenant_a" },
  ];

  it("retorna apenas registros da empresa atual", () => {
    expect(scopeToTenant(rows, "tenant_a").map((r) => r.id)).toEqual(["1", "3"]);
    expect(scopeToTenant(rows, "tenant_c")).toEqual([]);
  });

  it("falha quando a empresa atual não está definida", () => {
    expect(() => scopeToTenant(rows, "")).toThrow();
  });

  it("trata registro de outra empresa como inexistente", () => {
    expect(() => assertSameTenant(rows[1], "tenant_a")).toThrow("Registro não encontrado.");
    expect(() => assertSameTenant(rows[0], "tenant_a")).not.toThrow();
  });
});
