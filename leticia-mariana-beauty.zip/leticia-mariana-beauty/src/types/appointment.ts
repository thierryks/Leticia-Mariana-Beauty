import type { TenantScoped } from "./tenant";

export const APPOINTMENT_STATUSES = [
  "pending_confirmation",
  "confirmed",
  "signal_pending",
  "signal_paid",
  "in_progress",
  "completed",
  "cancelled_by_client",
  "cancelled_by_business",
  "no_show",
  "rescheduled",
] as const;

export type AppointmentStatus = (typeof APPOINTMENT_STATUSES)[number];

export const APPOINTMENT_SOURCES = [
  "admin",
  "website",
  "whatsapp",
  "instagram",
  "phone",
  "in_person",
] as const;

export type AppointmentSource = (typeof APPOINTMENT_SOURCES)[number];

export interface Appointment extends TenantScoped {
  id: string;
  clientId: string;
  clientName: string;
  serviceId: string;
  serviceName: string;
  professionalId: string;
  professionalName: string;
  /** Instante ISO 8601 em UTC. Exibir sempre no fuso da empresa. */
  startAt: string;
  /** Início + duração + intervalo de preparação. ISO 8601 em UTC. */
  endAt: string;
  status: AppointmentStatus;
  /** Preço copiado do serviço no momento da criação (RN-03). */
  priceInCents: number;
  /** Valor de sinal combinado. 0 quando não há sinal. */
  signalInCents: number;
  notes?: string;
  source: AppointmentSource;
  createdAt: string;
  updatedAt: string;
}

export interface NewAppointmentInput {
  clientId: string;
  serviceId: string;
  professionalId: string;
  /** Instante de início em UTC (ISO). */
  startAt: string;
  status: AppointmentStatus;
  signalInCents: number;
  notes?: string;
  source: AppointmentSource;
}
