// Permite importar folhas de estilo (globals.css e fontes) antes do Next gerar o next-env.d.ts.
declare module "*.css";
