import type { TenantScoped } from "./tenant";

export const SERVICE_CATEGORIES = [
  "extensao",
  "manutencao",
  "remocao",
  "sobrancelhas",
] as const;

export type ServiceCategory = (typeof SERVICE_CATEGORIES)[number];

export interface Service extends TenantScoped {
  id: string;
  name: string;
  category: ServiceCategory;
  durationMinutes: number;
  /** Tempo de higienização/preparo após o atendimento. Bloqueia a agenda. */
  preparationIntervalMinutes: number;
  /** Valor em centavos inteiros. Nunca use decimal para dinheiro. */
  priceInCents: number;
  active: boolean;
  description?: string;
}

export type ServiceInput = Omit<Service, "id" | "tenantId">;
