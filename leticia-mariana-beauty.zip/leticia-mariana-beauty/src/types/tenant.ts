/**
 * Empresa (tenant). Raiz do isolamento multiempresa.
 *
 * Supabase/RLS: toda tabela operacional terá a coluna `tenant_id` e uma policy
 * do tipo `tenant_id = auth.jwt() ->> 'tenant_id'` (ou via tabela de vínculos
 * usuário↔empresa). O front nunca deve ser a única barreira de isolamento.
 */
export interface Tenant {
  id: string;
  name: string;
  slug: string;
  /** Fuso IANA, ex.: "America/Sao_Paulo". */
  timezone: string;
  /** Código ISO 4217. No MVP sempre "BRL". */
  currency: "BRL";
  active: boolean;
}

/** Contrato mínimo de qualquer registro operacional. */
export interface TenantScoped {
  tenantId: string;
}
