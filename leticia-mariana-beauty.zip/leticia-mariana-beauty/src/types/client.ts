import type { TenantScoped } from "./tenant";

export const CLIENT_SOURCES = [
  "instagram",
  "whatsapp",
  "indicacao",
  "google",
  "passou_na_frente",
  "outro",
] as const;

export type ClientSource = (typeof CLIENT_SOURCES)[number];

export interface Client extends TenantScoped {
  id: string;
  fullName: string;
  /** Telefone normalizado: somente dígitos, com DDI 55. Ex.: "5521999990000". */
  phone: string;
  /** Data civil no formato "yyyy-MM-dd" (sem fuso). */
  birthDate?: string;
  instagram?: string;
  /** Id do serviço preferido. */
  preferredService?: string;
  emergencyContact?: string;
  source?: ClientSource;
  notes?: string;
  /**
   * Informação RESTRITA (alergias/sensibilidades). Não pode aparecer em
   * relatórios comerciais nem em logs. No Supabase, avaliar tabela separada
   * com policy de leitura mais restrita e trilha de auditoria de acesso.
   */
  sensitivities?: string;
  createdAt: string;
  updatedAt: string;
  active: boolean;
}

export type ClientInput = Omit<Client, "id" | "tenantId" | "createdAt" | "updatedAt" | "active">;

export type ClientStatusFilter = "all" | "active" | "inactive" | "new" | "maintenance_due";
