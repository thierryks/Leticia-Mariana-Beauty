import type { TenantScoped } from "./tenant";

export interface Professional extends TenantScoped {
  id: string;
  name: string;
  active: boolean;
}
