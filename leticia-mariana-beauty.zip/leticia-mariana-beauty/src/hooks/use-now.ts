"use client";

import { useState } from "react";

function currentTime(): number {
  return Date.now();
}

/** Instante fixado na montagem da tela, para cálculos estáveis durante a renderização. */
export function useNow(): number {
  const [now] = useState(currentTime);
  return now;
}
