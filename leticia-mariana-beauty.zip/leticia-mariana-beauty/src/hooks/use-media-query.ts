"use client";

import { useSyncExternalStore } from "react";

/** Lê uma media query de forma segura para SSR (no servidor retorna `serverFallback`). */
export function useMediaQuery(query: string, serverFallback = false): boolean {
  return useSyncExternalStore(
    (onChange) => {
      const media = window.matchMedia(query);
      media.addEventListener("change", onChange);
      return () => media.removeEventListener("change", onChange);
    },
    () => window.matchMedia(query).matches,
    () => serverFallback,
  );
}

export function useIsDesktop(): boolean {
  return useMediaQuery("(min-width: 768px)", true);
}
