"use client";

import { useCallback, useEffect, useRef, useState } from "react";

interface AsyncState<T> {
  key: string;
  data?: T;
  error?: Error;
}

/**
 * Carrega dados de um repositório e expõe loading/erro/recarregar.
 * `key` identifica a consulta: quando muda, a consulta é refeita.
 * O estado de carregamento é derivado (sem setState síncrono em efeito).
 */
export function useAsyncData<T>(key: string, loader: () => Promise<T>) {
  const loaderRef = useRef(loader);
  const [nonce, setNonce] = useState(0);
  const [state, setState] = useState<AsyncState<T>>({ key: "" });

  useEffect(() => {
    loaderRef.current = loader;
  });

  const requestKey = `${key}#${nonce}`;

  useEffect(() => {
    let active = true;
    loaderRef.current().then(
      (data) => {
        if (active) setState({ key: requestKey, data });
      },
      (error: unknown) => {
        if (active) {
          setState({
            key: requestKey,
            error: error instanceof Error ? error : new Error("Não foi possível carregar os dados."),
          });
        }
      },
    );
    return () => {
      active = false;
    };
  }, [requestKey]);

  const reload = useCallback(() => setNonce((n) => n + 1), []);
  const settled = state.key === requestKey;

  return {
    data: settled ? state.data : undefined,
    /** Últimos dados conhecidos, úteis para evitar "piscar" ao trocar de dia. */
    previousData: state.data,
    error: settled ? state.error : undefined,
    loading: !settled,
    reload,
  };
}
