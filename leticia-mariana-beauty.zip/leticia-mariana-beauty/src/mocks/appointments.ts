/**
 * DADOS DEMONSTRATIVOS — gerados relativos ao dia atual no fuso da empresa,
 * para que a agenda sempre tenha horários de hoje e dos próximos dias.
 */
import { calculateEndAt } from "@/features/appointments/rules";
import { shiftDateKey, todayKey, zonedDateTimeToUtc } from "@/lib/datetime";
import type { Appointment, AppointmentSource, AppointmentStatus } from "@/types/appointment";
import type { Client } from "@/types/client";
import type { Professional } from "@/types/professional";
import type { Service } from "@/types/service";
import { DEMO_TENANT_ID, OTHER_TENANT_ID } from "./tenants";

interface Seed {
  id: string;
  dayOffset: number;
  time: string;
  clientId: string;
  serviceId: string;
  professionalId?: string;
  status: AppointmentStatus;
  signalInCents?: number;
  source?: AppointmentSource;
  notes?: string;
  tenantId?: string;
}

const seeds: Seed[] = [
  // Hoje
  { id: "apt_hoje_1", dayOffset: 0, time: "08:30", clientId: "cli_ana", serviceId: "svc_manutencao", status: "completed", source: "whatsapp" },
  { id: "apt_hoje_2", dayOffset: 0, time: "10:00", clientId: "cli_larissa", serviceId: "svc_remocao", professionalId: "prof_parceira", status: "confirmed", source: "in_person" },
  { id: "apt_hoje_3", dayOffset: 0, time: "11:00", clientId: "cli_camila", serviceId: "svc_volume_russo", status: "in_progress", signalInCents: 7_000, source: "instagram" },
  { id: "apt_hoje_4", dayOffset: 0, time: "14:30", clientId: "cli_juliana", serviceId: "svc_fio_a_fio", status: "signal_pending", signalInCents: 5_000, source: "whatsapp", notes: "Enviar chave Pix para o sinal." },
  { id: "apt_hoje_5", dayOffset: 0, time: "15:00", clientId: "cli_patricia", serviceId: "svc_volume_hibrido", status: "cancelled_by_client", source: "whatsapp", notes: "Cancelou por imprevisto no trabalho." },
  { id: "apt_hoje_6", dayOffset: 0, time: "17:00", clientId: "cli_fernanda", serviceId: "svc_manutencao", status: "pending_confirmation", source: "phone" },
  // Próximos dias
  { id: "apt_d1_1", dayOffset: 1, time: "09:00", clientId: "cli_bianca", serviceId: "svc_volume_egipcio", status: "signal_paid", signalInCents: 6_000, source: "instagram" },
  { id: "apt_d1_2", dayOffset: 1, time: "13:00", clientId: "cli_renata", serviceId: "svc_mega_volume", status: "signal_paid", signalInCents: 8_000, source: "whatsapp", notes: "Remarcado a pedido da cliente." },
  { id: "apt_d1_3", dayOffset: 1, time: "16:30", clientId: "cli_sofia", serviceId: "svc_fio_a_fio", status: "pending_confirmation", source: "website", notes: "Primeira visita." },
  { id: "apt_d2_1", dayOffset: 2, time: "09:30", clientId: "cli_camila", serviceId: "svc_manutencao", status: "confirmed", source: "admin", notes: "Manutenção já combinada no atendimento." },
  { id: "apt_d3_1", dayOffset: 3, time: "14:00", clientId: "cli_juliana", serviceId: "svc_manutencao", status: "signal_pending", signalInCents: 3_000, source: "whatsapp" },
  { id: "apt_d5_1", dayOffset: 5, time: "10:00", clientId: "cli_patricia", serviceId: "svc_sirena", status: "pending_confirmation", source: "whatsapp" },
  // Histórico
  { id: "apt_p3_1", dayOffset: -3, time: "13:00", clientId: "cli_renata", serviceId: "svc_mega_volume", status: "rescheduled", source: "whatsapp" },
  { id: "apt_p10_1", dayOffset: -10, time: "15:00", clientId: "cli_fernanda", serviceId: "svc_manutencao", status: "no_show", source: "phone" },
  { id: "apt_p12_1", dayOffset: -12, time: "10:00", clientId: "cli_renata", serviceId: "svc_volume_brasileiro", status: "completed", source: "instagram" },
  { id: "apt_p14_1", dayOffset: -14, time: "09:00", clientId: "cli_ana", serviceId: "svc_volume_brasileiro", status: "completed", source: "instagram" },
  { id: "apt_p17_1", dayOffset: -17, time: "11:00", clientId: "cli_debora", serviceId: "svc_volume_brasileiro", status: "completed", source: "whatsapp" },
  { id: "apt_p18_1", dayOffset: -18, time: "14:00", clientId: "cli_patricia", serviceId: "svc_sirena", status: "cancelled_by_business", source: "admin", notes: "Studio fechado por manutenção elétrica." },
  { id: "apt_p20_1", dayOffset: -20, time: "10:30", clientId: "cli_camila", serviceId: "svc_volume_russo", status: "completed", source: "instagram" },
  { id: "apt_p21_1", dayOffset: -21, time: "09:00", clientId: "cli_bianca", serviceId: "svc_volume_egipcio", status: "completed", source: "instagram" },
  { id: "apt_p25_1", dayOffset: -25, time: "15:30", clientId: "cli_juliana", serviceId: "svc_fio_a_fio", status: "completed", source: "whatsapp" },
  { id: "apt_p26_1", dayOffset: -26, time: "13:30", clientId: "cli_tatiane", serviceId: "svc_fox_eyes", status: "completed", source: "instagram" },
  { id: "apt_p30_1", dayOffset: -30, time: "16:00", clientId: "cli_fernanda", serviceId: "svc_volume_hibrido", status: "completed", source: "website" },
  { id: "apt_p35_1", dayOffset: -35, time: "10:00", clientId: "cli_gabriela", serviceId: "svc_fio_a_fio", status: "completed", source: "admin" },
  { id: "apt_p40_1", dayOffset: -40, time: "11:00", clientId: "cli_larissa", serviceId: "svc_remocao", status: "completed", source: "in_person" },
  // Outra empresa: nunca pode aparecer para a empresa demo.
  { id: "apt_outra_1", dayOffset: 0, time: "10:00", clientId: "cli_outra_empresa", serviceId: "svc_outra_empresa", professionalId: "prof_outra", status: "confirmed", tenantId: OTHER_TENANT_ID },
];

export function buildDemoAppointments(
  now: number,
  timezone: string,
  clients: readonly Client[],
  services: readonly Service[],
  professionals: readonly Professional[],
): Appointment[] {
  const today = todayKey(timezone, now);

  return seeds.map((seed) => {
    const tenantId = seed.tenantId ?? DEMO_TENANT_ID;
    const client = clients.find((c) => c.id === seed.clientId);
    const service = services.find((s) => s.id === seed.serviceId);
    const professional = professionals.find((p) => p.id === (seed.professionalId ?? "prof_leticia"));
    if (!client || !service || !professional) {
      throw new Error(`Mock inconsistente: ${seed.id}`);
    }
    const startAt = zonedDateTimeToUtc(shiftDateKey(today, seed.dayOffset), seed.time, timezone);
    const createdAt = new Date(new Date(startAt).getTime() - 7 * 86_400_000).toISOString();
    return {
      id: seed.id,
      tenantId,
      clientId: client.id,
      clientName: client.fullName,
      serviceId: service.id,
      serviceName: service.name,
      professionalId: professional.id,
      professionalName: professional.name,
      startAt,
      endAt: calculateEndAt(startAt, service.durationMinutes, service.preparationIntervalMinutes),
      status: seed.status,
      priceInCents: service.priceInCents,
      signalInCents: seed.signalInCents ?? 0,
      notes: seed.notes,
      source: seed.source ?? "admin",
      createdAt,
      updatedAt: createdAt,
    };
  });
}
