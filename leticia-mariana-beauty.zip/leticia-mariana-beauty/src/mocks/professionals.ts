/** DADOS DEMONSTRATIVOS. */
import type { Professional } from "@/types/professional";
import { DEMO_TENANT_ID, OTHER_TENANT_ID } from "./tenants";

export const demoProfessionals: Professional[] = [
  { id: "prof_leticia", tenantId: DEMO_TENANT_ID, name: "Letícia Mariana", active: true },
  // Profissional parceira fictícia para demonstrar o filtro por profissional.
  { id: "prof_parceira", tenantId: DEMO_TENANT_ID, name: "Bruna Teixeira (demo)", active: true },
  { id: "prof_outra", tenantId: OTHER_TENANT_ID, name: "Profissional de outra empresa", active: true },
];
