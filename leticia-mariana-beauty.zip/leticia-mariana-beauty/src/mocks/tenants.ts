/**
 * DADOS DEMONSTRATIVOS — nenhum registro aqui é real.
 * A segunda empresa existe apenas para provar o isolamento entre salões.
 */
import type { Tenant } from "@/types/tenant";

export const DEMO_TENANT_ID = "tenant_demo_lmb";
export const OTHER_TENANT_ID = "tenant_demo_isolamento";

export const demoTenants: Tenant[] = [
  {
    id: DEMO_TENANT_ID,
    name: "Letícia Mariana Beauty",
    slug: "leticia-mariana-beauty",
    timezone: process.env.NEXT_PUBLIC_DEFAULT_TIMEZONE ?? "America/Sao_Paulo",
    currency: "BRL",
    active: true,
  },
  {
    id: OTHER_TENANT_ID,
    name: "Salão de outra empresa (teste de isolamento)",
    slug: "outra-empresa",
    timezone: "America/Sao_Paulo",
    currency: "BRL",
    active: true,
  },
];
