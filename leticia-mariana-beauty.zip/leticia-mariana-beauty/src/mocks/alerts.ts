/**
 * DADOS DEMONSTRATIVOS — alertas de módulos que ainda não existem
 * (estoque e lembretes pelo WhatsApp). Servem só para mostrar o layout.
 */
import { DEMO_TENANT_ID } from "./tenants";

export interface OperationalAlert {
  id: string;
  tenantId: string;
  kind: "stock_low" | "reminder_failed";
  title: string;
  description: string;
  /** Marca explícita de exemplo, exibida na interface. */
  isExample: true;
}

export const demoOperationalAlerts: OperationalAlert[] = [
  {
    id: "alert_estoque",
    tenantId: DEMO_TENANT_ID,
    kind: "stock_low",
    title: "Estoque baixo: cola para olhos sensíveis",
    description: "Restam 2 frascos. O mínimo configurado é 3.",
    isExample: true,
  },
  {
    id: "alert_lembrete",
    tenantId: DEMO_TENANT_ID,
    kind: "reminder_failed",
    title: "Lembrete não entregue",
    description: "A mensagem de lembrete de amanhã para Bianca Ferraz não chegou. Envie manualmente.",
    isExample: true,
  },
];
