/**
 * DADOS DEMONSTRATIVOS — nomes, telefones e perfis totalmente fictícios.
 * Telefones usam a faixa (21) 90000-xxxx, que não pertence a clientes reais.
 */
import type { Client } from "@/types/client";
import { DEMO_TENANT_ID, OTHER_TENANT_ID } from "./tenants";

const DAY_MS = 86_400_000;

interface Seed {
  id: string;
  fullName: string;
  phoneSuffix: string;
  createdDaysAgo: number;
  active?: boolean;
  extra?: Partial<Client>;
}

const seeds: Seed[] = [
  {
    id: "cli_ana",
    fullName: "Ana Beatriz Moura",
    phoneSuffix: "1001",
    createdDaysAgo: 240,
    extra: {
      instagram: "@anabeatriz.demo",
      preferredService: "svc_volume_brasileiro",
      source: "instagram",
      birthDate: "1994-03-12",
      notes: "Prefere horários pela manhã.",
    },
  },
  {
    id: "cli_camila",
    fullName: "Camila Duarte Reis",
    phoneSuffix: "1002",
    createdDaysAgo: 180,
    extra: {
      preferredService: "svc_volume_russo",
      source: "indicacao",
      emergencyContact: "Irmã — (21) 90000-2002",
      sensitivities: "Relatou sensibilidade a cola comum. Usar cola para olhos sensíveis.",
    },
  },
  {
    id: "cli_juliana",
    fullName: "Juliana Prado Lima",
    phoneSuffix: "1003",
    createdDaysAgo: 150,
    extra: { preferredService: "svc_fio_a_fio", source: "whatsapp", instagram: "@ju.prado.demo" },
  },
  {
    id: "cli_fernanda",
    fullName: "Fernanda Alves Costa",
    phoneSuffix: "1004",
    createdDaysAgo: 120,
    extra: { preferredService: "svc_volume_hibrido", source: "google" },
  },
  {
    id: "cli_larissa",
    fullName: "Larissa Monteiro",
    phoneSuffix: "1005",
    createdDaysAgo: 90,
    extra: { source: "passou_na_frente" },
  },
  {
    id: "cli_patricia",
    fullName: "Patrícia Nogueira",
    phoneSuffix: "1006",
    createdDaysAgo: 75,
    extra: {
      preferredService: "svc_sirena",
      source: "instagram",
      sensitivities: "Olhos lacrimejam com luz direta. Preferir luz indireta.",
    },
  },
  {
    id: "cli_bianca",
    fullName: "Bianca Ferraz",
    phoneSuffix: "1007",
    createdDaysAgo: 60,
    extra: { preferredService: "svc_volume_egipcio", source: "instagram" },
  },
  {
    id: "cli_renata",
    fullName: "Renata Siqueira",
    phoneSuffix: "1008",
    createdDaysAgo: 45,
    extra: { preferredService: "svc_mega_volume", source: "indicacao" },
  },
  {
    id: "cli_gabriela",
    fullName: "Gabriela Antunes",
    phoneSuffix: "1009",
    createdDaysAgo: 300,
    active: false,
    extra: { source: "outro", notes: "Mudou de cidade." },
  },
  {
    id: "cli_sofia",
    fullName: "Sofia Rangel",
    phoneSuffix: "1010",
    createdDaysAgo: 5,
    extra: { preferredService: "svc_fio_a_fio", source: "instagram", instagram: "@sofia.rangel.demo" },
  },
  {
    id: "cli_debora",
    fullName: "Débora Vasconcelos",
    phoneSuffix: "1011",
    createdDaysAgo: 110,
    extra: { preferredService: "svc_volume_brasileiro", source: "whatsapp" },
  },
  {
    id: "cli_tatiane",
    fullName: "Tatiane Rocha",
    phoneSuffix: "1012",
    createdDaysAgo: 200,
    extra: { preferredService: "svc_fox_eyes", source: "instagram" },
  },
];

export function buildDemoClients(now: number): Client[] {
  const demo = seeds.map<Client>((seed) => {
    const created = new Date(now - seed.createdDaysAgo * DAY_MS).toISOString();
    return {
      id: seed.id,
      tenantId: DEMO_TENANT_ID,
      fullName: seed.fullName,
      phone: `552190000${seed.phoneSuffix}`,
      createdAt: created,
      updatedAt: created,
      active: seed.active ?? true,
      ...seed.extra,
    };
  });

  const isolationProbe: Client = {
    id: "cli_outra_empresa",
    tenantId: OTHER_TENANT_ID,
    fullName: "Cliente de outra empresa",
    // Mesmo telefone de uma cliente demo: não pode gerar alerta de duplicidade entre empresas.
    phone: "5521900001001",
    createdAt: new Date(now - 10 * DAY_MS).toISOString(),
    updatedAt: new Date(now - 10 * DAY_MS).toISOString(),
    active: true,
  };

  return [...demo, isolationProbe];
}
