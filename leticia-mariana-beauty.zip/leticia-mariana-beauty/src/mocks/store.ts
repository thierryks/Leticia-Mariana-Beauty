/**
 * "Banco" em memória dos DADOS DEMONSTRATIVOS.
 *
 * - Vive apenas na memória da aba: recarregar a página restaura os dados.
 * - Não usa localStorage (os dados de cliente não devem ficar no navegador).
 * - Só é acessado pelos repositórios mock em `src/repositories/mock`.
 */
import type { Appointment } from "@/types/appointment";
import type { Client } from "@/types/client";
import type { Professional } from "@/types/professional";
import type { Service } from "@/types/service";
import type { Tenant } from "@/types/tenant";
import { demoOperationalAlerts, type OperationalAlert } from "./alerts";
import { buildDemoAppointments } from "./appointments";
import { buildDemoClients } from "./clients";
import { demoProfessionals } from "./professionals";
import { demoServices } from "./services";
import { DEMO_TENANT_ID, demoTenants } from "./tenants";

export interface MockDatabase {
  tenants: Tenant[];
  professionals: Professional[];
  services: Service[];
  clients: Client[];
  appointments: Appointment[];
  alerts: OperationalAlert[];
}

let database: MockDatabase | null = null;

export function createMockDatabase(now: number = Date.now()): MockDatabase {
  const tenants = demoTenants.map((t) => ({ ...t }));
  const timezone = tenants.find((t) => t.id === DEMO_TENANT_ID)?.timezone ?? "America/Sao_Paulo";
  const professionals = demoProfessionals.map((p) => ({ ...p }));
  const services = demoServices.map((s) => ({ ...s }));
  const clients = buildDemoClients(now);
  const appointments = buildDemoAppointments(now, timezone, clients, services, professionals);
  return { tenants, professionals, services, clients, appointments, alerts: [...demoOperationalAlerts] };
}

export function getMockDatabase(): MockDatabase {
  database ??= createMockDatabase();
  return database;
}

/** Usado nos testes para começar de um estado conhecido. */
export function resetMockDatabase(next?: MockDatabase): void {
  database = next ?? null;
}

/** Simula latência de rede para que estados de carregamento apareçam. */
export function simulateLatency(ms = 250): Promise<void> {
  if (process.env.NODE_ENV === "test") return Promise.resolve();
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/** Cópia defensiva: telas nunca recebem referência mutável do "banco". */
export function clone<T>(value: T): T {
  return structuredClone(value);
}
