import {
  ChartColumn,
  CalendarDays,
  LayoutDashboard,
  Settings,
  Sparkles,
  Users,
  Wallet,
  type LucideIcon,
} from "lucide-react";

export interface NavItem {
  label: string;
  href: string;
  icon: LucideIcon;
  /** Módulos ainda não liberados aparecem com "Em breve". */
  comingSoon?: boolean;
}

export const NAV_ITEMS: NavItem[] = [
  { label: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
  { label: "Agenda", href: "/agenda", icon: CalendarDays },
  { label: "Clientes", href: "/clientes", icon: Users },
  { label: "Serviços", href: "/servicos", icon: Sparkles },
  { label: "Financeiro", href: "/financeiro", icon: Wallet },
  { label: "Relatórios", href: "/relatorios", icon: ChartColumn, comingSoon: true },
  { label: "Configurações", href: "/configuracoes", icon: Settings },
];

export function isNavItemActive(pathname: string, href: string): boolean {
  return pathname === href || pathname.startsWith(`${href}/`);
}
