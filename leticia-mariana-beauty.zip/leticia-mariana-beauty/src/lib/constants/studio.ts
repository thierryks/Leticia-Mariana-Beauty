/**
 * Regras operacionais do studio (demonstrativas).
 * Na próxima etapa viram configurações por empresa (tabela tenant_settings).
 */
export const STUDIO_SETTINGS = {
  /** Expediente usado para indicar horários livres na agenda. */
  openingTime: "08:00",
  closingTime: "19:00",
  /** Segunda a sábado (0 = domingo). */
  workingWeekdays: [1, 2, 3, 4, 5, 6] as number[],
  /** Menor intervalo que vale a pena mostrar como horário livre. */
  minFreeSlotMinutes: 30,
  /** Política do brand book: manutenção recomendada entre 15 e 20 dias. */
  maintenanceWindowDays: { from: 15, to: 20 },
  /** Cliente é considerada "nova" até X dias após o cadastro. */
  newClientDays: 30,
  /** Passo do seletor de horário ao criar agendamento. */
  slotStepMinutes: 15,
} as const;
