import type { AppointmentSource, AppointmentStatus } from "@/types/appointment";
import type { ClientSource } from "@/types/client";
import type { ServiceCategory } from "@/types/service";

/** Tom visual do status. Todo status tem SEMPRE texto + cor + ícone. */
export type StatusTone = "sage" | "amber" | "clay" | "mauve" | "slate" | "gold";

export const APPOINTMENT_STATUS_META: Record<
  AppointmentStatus,
  { label: string; tone: StatusTone; description: string }
> = {
  pending_confirmation: {
    label: "Aguardando confirmação",
    tone: "amber",
    description: "A cliente ainda não confirmou o horário.",
  },
  confirmed: { label: "Confirmado", tone: "sage", description: "Horário confirmado pela cliente." },
  signal_pending: {
    label: "Sinal pendente",
    tone: "amber",
    description: "Aguardando o pagamento do sinal para garantir o horário.",
  },
  signal_paid: { label: "Sinal pago", tone: "sage", description: "Sinal recebido. Horário garantido." },
  in_progress: { label: "Em atendimento", tone: "mauve", description: "Atendimento acontecendo agora." },
  completed: { label: "Concluído", tone: "slate", description: "Atendimento finalizado." },
  cancelled_by_client: {
    label: "Cancelado pela cliente",
    tone: "clay",
    description: "Cancelado. O horário fica livre.",
  },
  cancelled_by_business: {
    label: "Cancelado pelo studio",
    tone: "clay",
    description: "Cancelado pelo studio. O horário fica livre.",
  },
  no_show: { label: "Não compareceu", tone: "clay", description: "A cliente faltou." },
  rescheduled: { label: "Remarcado", tone: "gold", description: "Foi remarcado para outro horário." },
};

export const APPOINTMENT_SOURCE_LABEL: Record<AppointmentSource, string> = {
  admin: "Studio",
  website: "Site",
  whatsapp: "WhatsApp",
  instagram: "Instagram",
  phone: "Telefone",
  in_person: "Presencial",
};

export const CLIENT_SOURCE_LABEL: Record<ClientSource, string> = {
  instagram: "Instagram",
  whatsapp: "WhatsApp",
  indicacao: "Indicação",
  google: "Google",
  passou_na_frente: "Passou na frente do studio",
  outro: "Outro",
};

export const SERVICE_CATEGORY_LABEL: Record<ServiceCategory, string> = {
  extensao: "Extensão de cílios",
  manutencao: "Manutenção",
  remocao: "Remoção",
  sobrancelhas: "Sobrancelhas",
};

/** Status que podem ser escolhidos ao criar um agendamento. */
export const INITIAL_STATUS_OPTIONS = [
  "pending_confirmation",
  "confirmed",
  "signal_pending",
  "signal_paid",
] as const satisfies readonly AppointmentStatus[];
