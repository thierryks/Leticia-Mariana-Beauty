import type { TenantScoped } from "@/types/tenant";

/**
 * Filtro obrigatório de empresa em TODA leitura da camada de dados.
 *
 * No mock, é a única barreira. No Supabase, isto vira redundância defensiva:
 * a barreira real será Row Level Security (policy por tenant_id) — nunca
 * confiar apenas no filtro feito no cliente.
 */
export function scopeToTenant<T extends TenantScoped>(records: readonly T[], tenantId: string): T[] {
  if (!tenantId) throw new Error("Empresa atual não definida.");
  return records.filter((record) => record.tenantId === tenantId);
}

export function assertSameTenant(record: TenantScoped | undefined, tenantId: string): void {
  if (!record || record.tenantId !== tenantId) {
    throw new Error("Registro não encontrado.");
  }
}
