import { TZDate } from "@date-fns/tz";
import { addDays, differenceInCalendarDays, format, parse, type Locale } from "date-fns";
import { ptBR } from "date-fns/locale";

/**
 * Datas e horários.
 *
 * - Instantes são persistidos em UTC (ISO 8601) — RN-02.
 * - A interface sempre exibe no fuso da empresa.
 * - "DateKey" é uma data civil no fuso da empresa, formato "yyyy-MM-dd".
 * - Semana começa na segunda-feira.
 */

export type DateKey = string;

export const LOCALE: Locale = ptBR;
export const WEEK_STARTS_ON = 1 as const;

const formatOptions = { locale: ptBR, weekStartsOn: WEEK_STARTS_ON } as const;

export function toZoned(iso: string | Date | number, timezone: string): TZDate {
  return new TZDate(new Date(iso).getTime(), timezone);
}

/** Formata um instante no fuso da empresa com padrões do date-fns. */
export function formatInTimezone(iso: string | Date | number, pattern: string, timezone: string): string {
  return format(toZoned(iso, timezone), pattern, formatOptions);
}

/** Hora "HH:mm" de um instante no fuso da empresa. */
export function formatTime(iso: string, timezone: string): string {
  return formatInTimezone(iso, "HH:mm", timezone);
}

/** "27/10/2026" */
export function formatShortDate(iso: string, timezone: string): string {
  return formatInTimezone(iso, "dd/MM/yyyy", timezone);
}

/** Data civil de hoje no fuso da empresa. */
export function todayKey(timezone: string, now: number = Date.now()): DateKey {
  return format(new TZDate(now, timezone), "yyyy-MM-dd");
}

/** Data civil (no fuso da empresa) de um instante. */
export function dateKeyOf(iso: string, timezone: string): DateKey {
  return format(toZoned(iso, timezone), "yyyy-MM-dd");
}

function parseKey(key: DateKey): Date {
  return parse(key, "yyyy-MM-dd", new Date(2000, 0, 1));
}

export function shiftDateKey(key: DateKey, days: number): DateKey {
  return format(addDays(parseKey(key), days), "yyyy-MM-dd");
}

/** Diferença em dias civis entre duas datas (b - a). */
export function daysBetweenKeys(a: DateKey, b: DateKey): number {
  return differenceInCalendarDays(parseKey(b), parseKey(a));
}

/** "terça-feira, 27 de outubro de 2026" */
export function formatDateKeyLong(key: DateKey): string {
  return format(parseKey(key), "EEEE, d 'de' MMMM 'de' yyyy", formatOptions);
}

/** "ter., 27 de out." */
export function formatDateKeyShort(key: DateKey): string {
  return format(parseKey(key), "EEE, d 'de' MMM", formatOptions);
}

/** "27/10/2026" a partir de "2026-10-27" */
export function formatDateKey(key: DateKey): string {
  return format(parseKey(key), "dd/MM/yyyy", formatOptions);
}

/**
 * Converte data civil + hora local da empresa em instante UTC (ISO).
 * Ex.: ("2026-10-27", "09:30", "America/Sao_Paulo") → "2026-10-27T12:30:00.000Z"
 */
export function zonedDateTimeToUtc(key: DateKey, time: string, timezone: string): string {
  const [y, m, d] = key.split("-").map(Number);
  const [hh, mm] = time.split(":").map(Number);
  if ([y, m, d, hh, mm].some((n) => n === undefined || Number.isNaN(n))) {
    throw new RangeError("Data ou horário inválido.");
  }
  const zoned = new TZDate(y!, m! - 1, d!, hh!, mm!, 0, timezone);
  return new Date(zoned.getTime()).toISOString();
}

/** Minutos desde 00:00 no fuso da empresa. */
export function minutesOfDay(iso: string, timezone: string): number {
  const zoned = toZoned(iso, timezone);
  return zoned.getHours() * 60 + zoned.getMinutes();
}

export function minutesToTime(minutes: number): string {
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
}

export function formatDuration(minutes: number): string {
  if (minutes < 60) return `${minutes} min`;
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return m === 0 ? `${h}h` : `${h}h${String(m).padStart(2, "0")}`;
}

/** Saudação neutra (sem inferir gênero) conforme a hora local. */
export function greetingFor(timezone: string, now: number = Date.now()): string {
  const hour = new TZDate(now, timezone).getHours();
  if (hour < 12) return "Bom dia";
  if (hour < 18) return "Boa tarde";
  return "Boa noite";
}
