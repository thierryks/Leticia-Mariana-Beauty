const brlFormatter = new Intl.NumberFormat("pt-BR", {
  style: "currency",
  currency: "BRL",
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
});

/**
 * Formata centavos inteiros como BRL ("R$ 1.234,56").
 * Valores monetários sempre trafegam em centavos inteiros (RN-08).
 */
export function formatCents(cents: number): string {
  if (!Number.isInteger(cents)) {
    throw new TypeError("Valor monetário deve estar em centavos inteiros.");
  }
  return brlFormatter.format(cents / 100);
}

/**
 * Converte texto digitado ("1.234,56", "R$ 80", "80,5") em centavos inteiros
 * sem passar por aritmética de ponto flutuante. Retorna null se inválido.
 */
export function parseBRLToCents(input: string): number | null {
  const cleaned = input.replace(/[R$\s ]/g, "").replace(/\./g, "");
  if (cleaned === "") return null;
  const match = /^(-?)(\d+)(?:,(\d{1,2}))?$/.exec(cleaned);
  if (!match) return null;
  const [, sign = "", reais = "0", centavos = ""] = match;
  const cents = Number(reais) * 100 + Number(centavos.padEnd(2, "0"));
  return sign === "-" ? -cents : cents;
}

/**
 * Para o campo monetário estilo "app de banco": cada dígito empurra
 * os anteriores para a esquerda. "1" → 1, "12" → 12, "1234" → 1234 centavos.
 */
export function digitsToCents(raw: string): number {
  const digits = raw.replace(/\D/g, "").replace(/^0+/, "").slice(0, 9);
  return digits === "" ? 0 : Number(digits);
}
