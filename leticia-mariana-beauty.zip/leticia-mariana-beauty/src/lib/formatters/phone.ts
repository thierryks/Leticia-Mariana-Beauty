/**
 * Telefones brasileiros.
 *
 * Formato canônico armazenado: apenas dígitos com DDI, ex. "5521987654321".
 * - celular: DDD + 9 dígitos começando por 9
 * - fixo: DDD + 8 dígitos começando de 2 a 5
 * O telefone normalizado é a chave de alerta de duplicidade dentro da empresa (RN-06).
 */

const DDD_PATTERN = /^[1-9][1-9]$/;

function toNationalDigits(input: string): string | null {
  let digits = input.replace(/\D/g, "");
  // Prefixo de discagem interurbana ("0 21 ...").
  digits = digits.replace(/^0+/, "");

  if ((digits.length === 12 || digits.length === 13) && digits.startsWith("55")) {
    return digits.slice(2);
  }
  if (digits.length === 10 || digits.length === 11) {
    return digits;
  }
  return null;
}

function isValidNational(national: string): boolean {
  const ddd = national.slice(0, 2);
  const subscriber = national.slice(2);
  if (!DDD_PATTERN.test(ddd)) return false;
  if (subscriber.length === 9) return subscriber.startsWith("9");
  if (subscriber.length === 8) return /^[2-5]/.test(subscriber);
  return false;
}

/** Retorna "55DDDNÚMERO" ou null quando o telefone não é brasileiro válido. */
export function normalizeBrazilianPhone(input: string): string | null {
  const national = toNationalDigits(input);
  if (!national || !isValidNational(national)) return null;
  return `55${national}`;
}

export function isValidBrazilianPhone(input: string): boolean {
  return normalizeBrazilianPhone(input) !== null;
}

/** "5521987654321" → "(21) 98765-4321". Valores inválidos voltam como vieram. */
export function formatPhone(value: string): string {
  const normalized = normalizeBrazilianPhone(value);
  if (!normalized) return value;
  const national = normalized.slice(2);
  const ddd = national.slice(0, 2);
  const subscriber = national.slice(2);
  const split = subscriber.length === 9 ? 5 : 4;
  return `(${ddd}) ${subscriber.slice(0, split)}-${subscriber.slice(split)}`;
}

/**
 * Máscara progressiva para digitação: aplica parênteses e hífen
 * conforme a pessoa digita, sem impedir apagar.
 */
export function maskPhoneInput(raw: string): string {
  let digits = raw.replace(/\D/g, "");
  if (digits.startsWith("55") && digits.length > 11) digits = digits.slice(2);
  digits = digits.slice(0, 11);
  if (digits.length === 0) return "";
  if (digits.length <= 2) return `(${digits}`;
  const ddd = digits.slice(0, 2);
  const rest = digits.slice(2);
  if (rest.length <= 4) return `(${ddd}) ${rest}`;
  const split = rest.length === 9 ? 5 : 4;
  return `(${ddd}) ${rest.slice(0, split)}-${rest.slice(split)}`;
}

/** Link de conversa no WhatsApp (sem mensagem pré-preenchida com dados pessoais). */
export function whatsappLink(normalizedPhone: string): string {
  return `https://wa.me/${normalizedPhone.replace(/\D/g, "")}`;
}
