import { z } from "zod";
import { isValidBrazilianPhone, normalizeBrazilianPhone } from "@/lib/formatters/phone";
import { CLIENT_SOURCES, type ClientInput } from "@/types/client";

const DATE_KEY = /^\d{4}-\d{2}-\d{2}$/;
const INSTAGRAM = /^@?[A-Za-z0-9._]{1,30}$/;

function isPlausibleBirthDate(value: string): boolean {
  if (value === "") return true;
  if (!DATE_KEY.test(value)) return false;
  const date = new Date(`${value}T12:00:00Z`);
  if (Number.isNaN(date.getTime())) return false;
  const year = date.getUTCFullYear();
  return year >= 1900 && date.getTime() <= Date.now();
}

/**
 * Formulário de cliente. Campos opcionais chegam como "" do formulário e
 * são convertidos em `undefined` por `toClientInput`.
 * Não coletamos CPF nesta etapa (minimização — LGPD).
 */
export const clientFormSchema = z.object({
  fullName: z
    .string()
    .trim()
    .min(3, "Informe o nome completo da cliente.")
    .max(120, "Use no máximo 120 caracteres."),
  phone: z
    .string()
    .trim()
    .min(1, "Informe o telefone da cliente.")
    .refine(isValidBrazilianPhone, "Telefone inválido. Use DDD + número, ex.: (21) 99999-0000."),
  birthDate: z.string().refine(isPlausibleBirthDate, "Informe uma data de nascimento válida."),
  instagram: z
    .string()
    .trim()
    .refine((v) => v === "" || INSTAGRAM.test(v), "Use apenas o @ do perfil, ex.: @perfil."),
  preferredService: z.string(),
  emergencyContact: z.string().trim().max(120, "Use no máximo 120 caracteres."),
  source: z.union([z.enum(CLIENT_SOURCES), z.literal("")]),
  notes: z.string().trim().max(1000, "Use no máximo 1000 caracteres."),
  sensitivities: z.string().trim().max(500, "Use no máximo 500 caracteres."),
});

export type ClientFormValues = z.infer<typeof clientFormSchema>;

export const EMPTY_CLIENT_FORM: ClientFormValues = {
  fullName: "",
  phone: "",
  birthDate: "",
  instagram: "",
  preferredService: "",
  emergencyContact: "",
  source: "",
  notes: "",
  sensitivities: "",
};

const blankToUndefined = (value: string): string | undefined => {
  const trimmed = value.trim();
  return trimmed === "" ? undefined : trimmed;
};

/** Converte valores validados do formulário no modelo persistido. */
export function toClientInput(values: ClientFormValues): ClientInput {
  const phone = normalizeBrazilianPhone(values.phone);
  if (!phone) throw new Error("Telefone inválido.");
  const instagram = blankToUndefined(values.instagram);
  return {
    fullName: values.fullName.trim().replace(/\s+/g, " "),
    phone,
    birthDate: blankToUndefined(values.birthDate),
    instagram: instagram ? `@${instagram.replace(/^@/, "")}` : undefined,
    preferredService: blankToUndefined(values.preferredService),
    emergencyContact: blankToUndefined(values.emergencyContact),
    source: values.source === "" ? undefined : values.source,
    notes: blankToUndefined(values.notes),
    sensitivities: blankToUndefined(values.sensitivities),
  };
}
