import { z } from "zod";
import { INITIAL_STATUS_OPTIONS } from "@/lib/constants/labels";

export const appointmentFormSchema = z.object({
  clientId: z.string().min(1, "Escolha a cliente."),
  serviceId: z.string().min(1, "Escolha o serviço."),
  professionalId: z.string().min(1, "Escolha a profissional."),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Escolha a data."),
  time: z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/, "Escolha o horário."),
  status: z.enum(INITIAL_STATUS_OPTIONS, { message: "Escolha o status inicial." }),
  signalInCents: z.number().int().min(0, "O sinal não pode ser negativo."),
  notes: z.string().trim().max(500, "Use no máximo 500 caracteres."),
});

export type AppointmentFormValues = z.infer<typeof appointmentFormSchema>;
