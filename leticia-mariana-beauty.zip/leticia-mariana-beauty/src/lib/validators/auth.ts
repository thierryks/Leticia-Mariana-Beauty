import { z } from "zod";
import { isValidBrazilianPhone } from "@/lib/formatters/phone";

export const loginSchema = z.object({
  phone: z
    .string()
    .trim()
    .min(1, "Informe seu telefone.")
    .refine(isValidBrazilianPhone, "Telefone inválido. Use DDD + número, ex.: (21) 99999-0000."),
  password: z
    .string()
    .min(1, "Informe sua senha.")
    .min(8, "A senha precisa ter pelo menos 8 caracteres."),
});

export type LoginFormValues = z.infer<typeof loginSchema>;
