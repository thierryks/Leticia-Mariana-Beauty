import { z } from "zod";
import { SERVICE_CATEGORIES } from "@/types/service";

export const serviceFormSchema = z.object({
  name: z.string().trim().min(2, "Informe o nome do serviço.").max(80, "Use no máximo 80 caracteres."),
  category: z.enum(SERVICE_CATEGORIES, { message: "Escolha uma categoria." }),
  durationMinutes: z
    .number({ message: "Informe a duração em minutos." })
    .int("Use minutos inteiros.")
    .min(5, "A duração mínima é de 5 minutos.")
    .max(480, "A duração máxima é de 8 horas."),
  preparationIntervalMinutes: z
    .number({ message: "Informe o intervalo em minutos (pode ser 0)." })
    .int("Use minutos inteiros.")
    .min(0, "O intervalo não pode ser negativo.")
    .max(120, "O intervalo máximo é de 2 horas."),
  priceInCents: z
    .number({ message: "Informe o preço." })
    .int()
    .min(0, "O preço não pode ser negativo.")
    .max(10_000_000, "Confira o valor informado."),
  description: z.string().trim().max(300, "Use no máximo 300 caracteres."),
  active: z.boolean(),
});

export type ServiceFormValues = z.infer<typeof serviceFormSchema>;
