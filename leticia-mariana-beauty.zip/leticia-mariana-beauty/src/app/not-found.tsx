import Link from "next/link";
import { Monogram } from "@/components/brand/logo";
import { buttonVariants } from "@/components/ui/button";

export default function NotFound() {
  return (
    <main className="flex min-h-dvh flex-col items-center justify-center gap-5 px-6 text-center">
      <Monogram className="size-16" />
      <h1 className="brand-title text-2xl text-brown">Página não encontrada</h1>
      <p className="max-w-sm text-sm text-muted">O endereço pode ter mudado. Volte ao início para continuar.</p>
      <Link href="/dashboard" className={buttonVariants()}>
        Ir para o início
      </Link>
    </main>
  );
}
