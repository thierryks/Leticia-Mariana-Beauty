import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "@fontsource-variable/montserrat";
import "@fontsource/cinzel/400.css";
import "@fontsource/cinzel/500.css";
import "@fontsource/cinzel/600.css";
import "@fontsource/allura/400.css";
import "./globals.css";

export const metadata: Metadata = {
  title: {
    default: "Letícia Mariana Beauty",
    template: "%s · Letícia Mariana Beauty",
  },
  description: "Gestão de agenda, clientes e serviços do studio Letícia Mariana Beauty.",
  robots: { index: false, follow: false },
};

export const viewport: Viewport = {
  themeColor: "#f9f8f4",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: Readonly<{ children: ReactNode }>) {
  return (
    <html lang="pt-BR">
      <body className="min-h-dvh">{children}</body>
    </html>
  );
}
