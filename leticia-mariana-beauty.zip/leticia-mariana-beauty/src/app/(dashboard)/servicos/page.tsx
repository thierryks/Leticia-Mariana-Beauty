import type { Metadata } from "next";
import { Suspense } from "react";
import { ServicesView } from "@/components/servicos/services-view";
import { LoadingState } from "@/components/shared/states";

export const metadata: Metadata = { title: "Serviços" };

export default function ServicosPage() {
  return (
    <Suspense fallback={<LoadingState rows={4} label="Carregando serviços…" />}>
      <ServicesView />
    </Suspense>
  );
}
