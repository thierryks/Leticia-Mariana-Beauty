import type { Metadata } from "next";
import { ClientProfile } from "@/components/clientes/client-profile";

export const metadata: Metadata = { title: "Perfil da cliente" };

export default async function ClientePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return <ClientProfile id={id} />;
}
