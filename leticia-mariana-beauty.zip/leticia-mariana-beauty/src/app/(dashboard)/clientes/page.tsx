import type { Metadata } from "next";
import { Suspense } from "react";
import { ClientsView } from "@/components/clientes/clients-view";
import { LoadingState } from "@/components/shared/states";

export const metadata: Metadata = { title: "Clientes" };

export default function ClientesPage() {
  return (
    <Suspense fallback={<LoadingState rows={5} label="Carregando clientes…" />}>
      <ClientsView />
    </Suspense>
  );
}
