import type { Metadata } from "next";
import { NewClientView } from "@/components/clientes/new-client-view";

export const metadata: Metadata = { title: "Nova cliente" };

export default function NovaClientePage() {
  return <NewClientView />;
}
