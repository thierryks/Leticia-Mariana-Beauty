import type { ReactNode } from "react";
import { AppShell } from "@/components/layout/app-shell";

/**
 * Área autenticada. Nesta etapa o acesso é verificado no cliente pelo
 * adapter de demonstração. Com Supabase, a verificação passa para o
 * servidor (proxy/middleware + cookies httpOnly), e o RLS protege os dados.
 */
export default function DashboardLayout({ children }: { children: ReactNode }) {
  return <AppShell>{children}</AppShell>;
}
