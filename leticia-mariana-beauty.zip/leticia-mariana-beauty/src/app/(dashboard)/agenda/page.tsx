import type { Metadata } from "next";
import { Suspense } from "react";
import { AgendaView } from "@/components/agenda/agenda-view";
import { LoadingState } from "@/components/shared/states";

export const metadata: Metadata = { title: "Agenda" };

export default function AgendaPage() {
  return (
    <Suspense fallback={<LoadingState rows={4} label="Carregando a agenda…" />}>
      <AgendaView />
    </Suspense>
  );
}
