import type { Metadata } from "next";
import { LoginForm } from "@/components/auth/login-form";
import { Monogram, Wordmark } from "@/components/brand/logo";

export const metadata: Metadata = { title: "Entrar" };

export default function LoginPage() {
  return (
    <main className="grid min-h-dvh lg:grid-cols-[1.05fr_1fr]">
      <section
        aria-hidden
        className="relative hidden flex-col items-center justify-center overflow-hidden bg-sand px-12 lg:flex"
      >
        <Monogram className="size-44" title="" />
        <p className="brand-title mt-6 text-2xl tracking-[0.22em] text-brown">Letícia Mariana</p>
        <div className="mt-3 flex items-center gap-4 text-gold-ink">
          <span className="h-px w-10 bg-gold/70" />
          <span className="text-xs tracking-[0.5em]">BEAUTY</span>
          <span className="h-px w-10 bg-gold/70" />
        </div>
        <p className="mt-12 font-script text-4xl text-brown/85">
          Mais do que cílios, é autoestima.
        </p>
        <svg viewBox="0 0 600 120" className="pointer-events-none absolute bottom-10 left-0 w-full text-gold/50" aria-hidden>
          <path d="M-10 90 C 150 30, 330 140, 610 40" fill="none" stroke="currentColor" strokeWidth="1.2" />
        </svg>
      </section>

      <section className="flex items-center justify-center px-5 py-10 sm:px-8">
        <div className="w-full max-w-sm">
          <Wordmark className="mb-10 lg:hidden" />
          <h1 className="brand-title text-2xl text-brown">Acesse sua conta</h1>
          <p className="mt-2 mb-8 text-sm text-muted">Entre com o telefone e a senha cadastrados.</p>
          <LoginForm />
          <p className="mt-10 border-t border-line pt-5 text-xs leading-relaxed text-muted">
            Ambiente de demonstração: todas as clientes e horários exibidos são fictícios.
          </p>
        </div>
      </section>
    </main>
  );
}
