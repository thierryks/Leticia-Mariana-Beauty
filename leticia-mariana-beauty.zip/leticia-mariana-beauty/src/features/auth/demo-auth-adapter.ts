/**
 * ⚠️ ADAPTER TEMPORÁRIO DE DESENVOLVIMENTO — NÃO É AUTENTICAÇÃO DE PRODUÇÃO.
 *
 * Simula login por telefone e senha somente no navegador, para navegar pelas
 * telas com dados demonstrativos. Em produção será substituído por Supabase
 * Auth (telefone + senha), com sessão em cookie httpOnly via @supabase/ssr,
 * bloqueio por tentativas no servidor (RF-001) e recuperação de acesso (RF-002).
 *
 * Regras seguidas mesmo no mock:
 * - a senha nunca é registrada em log nem guardada;
 * - a comparação é feita por hash, sem a senha em texto no código;
 * - a mensagem de erro não revela se o telefone existe;
 * - nenhum token é salvo em localStorage (só um marcador de sessão demo
 *   em sessionStorage, que some ao fechar a aba).
 */
import { normalizeBrazilianPhone } from "@/lib/formatters/phone";
import { DEMO_TENANT_ID } from "@/mocks/tenants";

export interface DemoSession {
  userName: string;
  tenantId: string;
  startedAt: string;
}

export class AuthError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "AuthError";
  }
}

/** Usuária demonstrativa. Telefone fictício. Senha documentada apenas no README. */
const DEMO_USER = {
  phone: "5521900000000",
  passwordSha256: "e9c90f996e3d431b9f3182a7ef688e2e993a3915252e0af61b7937e9e7ec184d",
  name: "Letícia Mariana",
  tenantId: DEMO_TENANT_ID,
};

const SESSION_KEY = "lmb.demo-session";
const MAX_ATTEMPTS = 5;
const LOCK_MS = 60_000;

let failedAttempts = 0;
/** Cópia em memória, para navegadores que bloqueiam o sessionStorage. */
let memorySession: DemoSession | null = null;
let lockedUntil = 0;

async function sha256Hex(value: string): Promise<string> {
  const bytes = new TextEncoder().encode(value);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

function wait(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function readStorage(): Storage | null {
  try {
    return typeof window === "undefined" ? null : window.sessionStorage;
  } catch {
    return null;
  }
}

export const demoAuthAdapter = {
  async signIn(phone: string, password: string): Promise<DemoSession> {
    if (Date.now() < lockedUntil) {
      throw new AuthError("Muitas tentativas. Aguarde um minuto e tente de novo.");
    }
    await wait(700);
    const normalized = normalizeBrazilianPhone(phone);
    const passwordOk = (await sha256Hex(password)) === DEMO_USER.passwordSha256;

    if (normalized !== DEMO_USER.phone || !passwordOk) {
      failedAttempts += 1;
      if (failedAttempts >= MAX_ATTEMPTS) {
        lockedUntil = Date.now() + LOCK_MS;
        failedAttempts = 0;
      }
      throw new AuthError("Telefone ou senha incorretos.");
    }

    failedAttempts = 0;
    const session: DemoSession = {
      userName: DEMO_USER.name,
      tenantId: DEMO_USER.tenantId,
      startedAt: new Date().toISOString(),
    };
    memorySession = session;
    try {
      readStorage()?.setItem(SESSION_KEY, JSON.stringify(session));
    } catch {
      // Armazenamento indisponível: a sessão demo fica só em memória.
    }
    return session;
  },

  getSession(): DemoSession | null {
    let raw: string | null | undefined;
    try {
      raw = readStorage()?.getItem(SESSION_KEY);
    } catch {
      raw = null;
    }
    if (!raw) return memorySession;
    try {
      const parsed = JSON.parse(raw) as Partial<DemoSession>;
      if (typeof parsed.tenantId !== "string" || typeof parsed.userName !== "string") return null;
      return parsed as DemoSession;
    } catch {
      return null;
    }
  },

  signOut(): void {
    memorySession = null;
    try {
      readStorage()?.removeItem(SESSION_KEY);
    } catch {
      // nada a limpar
    }
  },
};
