import { STUDIO_SETTINGS } from "@/lib/constants/studio";
import { dateKeyOf, minutesOfDay, minutesToTime, type DateKey } from "@/lib/datetime";
import type { Appointment, AppointmentStatus } from "@/types/appointment";
import { computeFreeSlots, timeToMinutes, type MinuteRange } from "./free-slots";
import { isBlockingStatus, sortByStart } from "./rules";

export type AgendaStatusFilter = "all" | "active" | "awaiting" | "signal_pending" | "confirmed" | "inactive";

export const AGENDA_STATUS_FILTERS: { value: AgendaStatusFilter; label: string }[] = [
  { value: "all", label: "Todos os status" },
  { value: "active", label: "Ativos (ocupam a agenda)" },
  { value: "awaiting", label: "Aguardando confirmação" },
  { value: "signal_pending", label: "Sinal pendente" },
  { value: "confirmed", label: "Confirmados" },
  { value: "inactive", label: "Cancelados, faltas e remarcados" },
];

const CONFIRMED: AppointmentStatus[] = ["confirmed", "signal_paid", "in_progress", "completed"];

export function matchesStatusFilter(status: AppointmentStatus, filter: AgendaStatusFilter): boolean {
  switch (filter) {
    case "all":
      return true;
    case "active":
      return isBlockingStatus(status);
    case "awaiting":
      return status === "pending_confirmation";
    case "signal_pending":
      return status === "signal_pending";
    case "confirmed":
      return CONFIRMED.includes(status);
    case "inactive":
      return !isBlockingStatus(status);
  }
}

export type TimelineItem =
  | { kind: "appointment"; key: string; startMinute: number; appointment: Appointment }
  | { kind: "free"; key: string; startMinute: number; range: MinuteRange; label: string };

export interface AgendaDay {
  items: TimelineItem[];
  /** Falso quando a profissional não foi escolhida ou o studio não abre no dia. */
  showsFreeSlots: boolean;
  closedDay: boolean;
  visibleCount: number;
}

/** Dia da semana de uma data civil (0 = domingo), sem depender do fuso do aparelho. */
export function weekdayOf(key: DateKey): number {
  const [y, m, d] = key.split("-").map(Number);
  return new Date(Date.UTC(y!, m! - 1, d!)).getUTCDay();
}

export function buildAgendaDay(params: {
  appointments: readonly Appointment[];
  dateKey: DateKey;
  todayKey: DateKey;
  timezone: string;
  professionalId: string | "all";
  statusFilter: AgendaStatusFilter;
  nowMinute: number;
}): AgendaDay {
  const { appointments, dateKey, todayKey, timezone, professionalId, statusFilter, nowMinute } = params;
  const byProfessional = appointments.filter((a) => professionalId === "all" || a.professionalId === professionalId);
  const visible = sortByStart(byProfessional.filter((a) => matchesStatusFilter(a.status, statusFilter)));

  const items: TimelineItem[] = visible.map((appointment) => ({
    kind: "appointment",
    key: appointment.id,
    startMinute: minutesOfDay(appointment.startAt, timezone),
    appointment,
  }));

  const closedDay = !STUDIO_SETTINGS.workingWeekdays.includes(weekdayOf(dateKey));
  const isPast = dateKey < todayKey;
  const showsFreeSlots = professionalId !== "all" && !closedDay && !isPast;

  if (showsFreeSlots) {
    const step = STUDIO_SETTINGS.slotStepMinutes;
    let opening = timeToMinutes(STUDIO_SETTINGS.openingTime);
    if (dateKey === todayKey) opening = Math.max(opening, Math.ceil(nowMinute / step) * step);
    const closing = timeToMinutes(STUDIO_SETTINGS.closingTime);
    const busy = byProfessional
      .filter((a) => isBlockingStatus(a.status))
      .map((a) => ({ start: minutesOfDay(a.startAt, timezone), end: minutesOfDay(a.endAt, timezone) || 24 * 60 }));
    for (const range of computeFreeSlots(busy, opening, closing, STUDIO_SETTINGS.minFreeSlotMinutes)) {
      items.push({
        kind: "free",
        key: `free-${range.start}`,
        startMinute: range.start,
        range,
        label: `${minutesToTime(range.start)} às ${minutesToTime(range.end)}`,
      });
    }
  }

  items.sort((a, b) => a.startMinute - b.startMinute || (a.kind === "free" ? 1 : -1));
  return { items, showsFreeSlots, closedDay, visibleCount: visible.length };
}

export interface BookableStartInput {
  /** Agendamentos de UMA profissional (qualquer data; a função filtra o dia). */
  appointments: readonly Appointment[];
  dateKey: DateKey;
  todayKey: DateKey;
  timezone: string;
  /** Duração do serviço + intervalo de preparo: quanto tempo o horário ocupa. */
  totalMinutes: number;
  /** Minuto atual do dia no fuso da empresa (usado só para hoje). */
  nowMinute: number;
}

/**
 * Horários de início em que um atendimento de `totalMinutes` cabe no expediente
 * sem encostar em nenhum agendamento que ocupa a agenda. Mesma regra de
 * `findConflicts`: intervalos semiabertos, cancelados e faltas não bloqueiam.
 * Horários já passados (hoje) e dias fechados não aparecem.
 */
export function bookableStartTimes(input: BookableStartInput): string[] {
  const { appointments, dateKey, todayKey, timezone, totalMinutes, nowMinute } = input;
  if (totalMinutes <= 0) return [];
  const closedDay = !STUDIO_SETTINGS.workingWeekdays.includes(weekdayOf(dateKey));
  if (closedDay || dateKey < todayKey) return [];

  const step = STUDIO_SETTINGS.slotStepMinutes;
  const opening = timeToMinutes(STUDIO_SETTINGS.openingTime);
  const closing = timeToMinutes(STUDIO_SETTINGS.closingTime);
  let earliest = opening;
  if (dateKey === todayKey) earliest = Math.max(earliest, Math.ceil(nowMinute / step) * step);

  const busy = appointments
    .filter((a) => isBlockingStatus(a.status) && dateKeyOf(a.startAt, timezone) === dateKey)
    .map((a) => ({
      start: minutesOfDay(a.startAt, timezone),
      end: dateKeyOf(a.endAt, timezone) === dateKey ? minutesOfDay(a.endAt, timezone) : 24 * 60,
    }));

  const times: string[] = [];
  for (let start = earliest; start + totalMinutes <= closing; start += step) {
    const end = start + totalMinutes;
    if (busy.some((range) => start < range.end && range.start < end)) continue;
    times.push(minutesToTime(start));
  }
  return times;
}
