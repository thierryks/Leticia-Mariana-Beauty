/**
 * Calcula janelas livres dentro do expediente, em minutos do dia.
 * Os intervalos ocupados devem chegar já convertidos para o fuso da empresa.
 */
export interface MinuteRange {
  start: number;
  end: number;
}

export function computeFreeSlots(
  busy: readonly MinuteRange[],
  opening: number,
  closing: number,
  minimumMinutes: number,
): MinuteRange[] {
  const sorted = busy
    .map((range) => ({ start: Math.max(range.start, opening), end: Math.min(range.end, closing) }))
    .filter((range) => range.end > range.start)
    .sort((a, b) => a.start - b.start);

  const free: MinuteRange[] = [];
  let cursor = opening;
  for (const range of sorted) {
    if (range.start - cursor >= minimumMinutes) free.push({ start: cursor, end: range.start });
    cursor = Math.max(cursor, range.end);
  }
  if (closing - cursor >= minimumMinutes) free.push({ start: cursor, end: closing });
  return free;
}

export function timeToMinutes(time: string): number {
  const [h = "0", m = "0"] = time.split(":");
  return Number(h) * 60 + Number(m);
}
