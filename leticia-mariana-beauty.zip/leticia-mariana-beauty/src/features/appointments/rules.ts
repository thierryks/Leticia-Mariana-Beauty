import type { Appointment, AppointmentStatus } from "@/types/appointment";

const MINUTE_MS = 60_000;

/**
 * Status que NÃO ocupam a agenda.
 * Hipótese registrada: além dos cancelados (exigência do briefing), "remarcado"
 * (o horário antigo foi substituído por um novo) e "não compareceu" também
 * liberam o horário.
 */
export const NON_BLOCKING_STATUSES: ReadonlySet<AppointmentStatus> = new Set<AppointmentStatus>([
  "cancelled_by_client",
  "cancelled_by_business",
  "rescheduled",
  "no_show",
]);

export function isBlockingStatus(status: AppointmentStatus): boolean {
  return !NON_BLOCKING_STATUSES.has(status);
}

export function isCancelledStatus(status: AppointmentStatus): boolean {
  return status === "cancelled_by_client" || status === "cancelled_by_business";
}

/**
 * RN-01: horário final = início + duração + intervalo de preparação.
 * Recebe e devolve instantes ISO em UTC.
 */
export function calculateEndAt(
  startAt: string,
  durationMinutes: number,
  preparationIntervalMinutes: number,
): string {
  const start = new Date(startAt).getTime();
  if (Number.isNaN(start)) throw new RangeError("Horário de início inválido.");
  if (durationMinutes <= 0) throw new RangeError("A duração precisa ser maior que zero.");
  if (preparationIntervalMinutes < 0) throw new RangeError("O intervalo não pode ser negativo.");
  return new Date(start + (durationMinutes + preparationIntervalMinutes) * MINUTE_MS).toISOString();
}

/** Intervalos semiabertos [início, fim): encostar no fim do outro não é conflito. */
export function intervalsOverlap(aStart: string, aEnd: string, bStart: string, bEnd: string): boolean {
  const as = new Date(aStart).getTime();
  const ae = new Date(aEnd).getTime();
  const bs = new Date(bStart).getTime();
  const be = new Date(bEnd).getTime();
  return as < be && bs < ae;
}

export interface ScheduleCandidate {
  /** Id do próprio agendamento, ao editar — para não conflitar consigo mesmo. */
  id?: string;
  tenantId: string;
  professionalId: string;
  startAt: string;
  endAt: string;
}

/**
 * Retorna os agendamentos que impedem o candidato.
 * Regra: mesma empresa, mesma profissional, status que bloqueia e
 * período sobreposto (o `endAt` já inclui o intervalo de preparação).
 *
 * Supabase: replicar no banco com uma exclusion constraint, ex.:
 *   EXCLUDE USING gist (tenant_id WITH =, professional_id WITH =,
 *     tstzrange(start_at, end_at, '[)') WITH &&)
 *   WHERE (status NOT IN ('cancelled_by_client','cancelled_by_business','rescheduled','no_show'));
 * Assim, dois pedidos simultâneos nunca ocupam o mesmo horário (RF-008).
 */
export function findConflicts(candidate: ScheduleCandidate, existing: readonly Appointment[]): Appointment[] {
  return existing.filter(
    (appointment) =>
      appointment.tenantId === candidate.tenantId &&
      appointment.professionalId === candidate.professionalId &&
      appointment.id !== candidate.id &&
      isBlockingStatus(appointment.status) &&
      intervalsOverlap(candidate.startAt, candidate.endAt, appointment.startAt, appointment.endAt),
  );
}

export function hasConflict(candidate: ScheduleCandidate, existing: readonly Appointment[]): boolean {
  return findConflicts(candidate, existing).length > 0;
}

export function sortByStart<T extends { startAt: string }>(items: readonly T[]): T[] {
  return [...items].sort((a, b) => new Date(a.startAt).getTime() - new Date(b.startAt).getTime());
}

export class AppointmentConflictError extends Error {
  readonly conflicts: Appointment[];

  constructor(conflicts: Appointment[]) {
    super("Este horário já está ocupado para esta profissional.");
    this.name = "AppointmentConflictError";
    this.conflicts = conflicts;
  }
}

/** Sinal: pago quando o status indica, pendente quando há valor e ainda não foi pago. */
export function signalState(appointment: Pick<Appointment, "status" | "signalInCents">): "none" | "paid" | "pending" {
  if (appointment.signalInCents <= 0) return "none";
  if (appointment.status === "signal_paid" || appointment.status === "completed" || appointment.status === "in_progress") {
    return "paid";
  }
  return "pending";
}
