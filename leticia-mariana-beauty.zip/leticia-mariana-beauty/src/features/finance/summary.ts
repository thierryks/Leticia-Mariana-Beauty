import { weekdayOf } from "@/features/appointments/agenda";
import { isBlockingStatus, signalState } from "@/features/appointments/rules";
import { dateKeyOf, shiftDateKey, type DateKey } from "@/lib/datetime";
import type { Appointment } from "@/types/appointment";

export const FINANCE_PERIODS = [
  { value: "day", label: "Hoje" },
  { value: "week", label: "Esta semana" },
  { value: "month", label: "Este mês" },
] as const;

export type FinancePeriod = (typeof FINANCE_PERIODS)[number]["value"];

/** Intervalo de datas civis: `startKey` inclusivo, `endKey` exclusivo. */
export interface PeriodRange {
  startKey: DateKey;
  endKey: DateKey;
}

/** Período a partir de hoje. A semana começa na segunda (RN de agenda). */
export function resolvePeriod(period: FinancePeriod, today: DateKey): PeriodRange {
  if (period === "day") return { startKey: today, endKey: shiftDateKey(today, 1) };
  if (period === "week") {
    const offsetFromMonday = (weekdayOf(today) + 6) % 7;
    const startKey = shiftDateKey(today, -offsetFromMonday);
    return { startKey, endKey: shiftDateKey(startKey, 7) };
  }
  const startKey = `${today.slice(0, 8)}01`;
  // 32 dias depois do dia 1 sempre cai no mês seguinte.
  const endKey = `${shiftDateKey(startKey, 32).slice(0, 8)}01`;
  return { startKey, endKey };
}

export interface FinanceDayRow {
  dateKey: DateKey;
  count: number;
  expectedInCents: number;
  signalsPaidInCents: number;
}

export interface FinanceSummary {
  /** Valor de tabela dos atendimentos que ocupam a agenda (sem cancelados, faltas e remarcados). */
  expectedInCents: number;
  activeCount: number;
  signalsPaidInCents: number;
  signalsPaidCount: number;
  signalsPendingInCents: number;
  signalsPendingCount: number;
  /** Atendimentos concluídos, pelo valor de tabela. */
  completedInCents: number;
  completedCount: number;
  /** Só os dias com movimento, em ordem. */
  days: FinanceDayRow[];
  /** Sinais ainda não pagos, do mais antigo ao mais novo. */
  pendingSignals: Appointment[];
}

/**
 * Resume o período. Não há registro de pagamentos nesta etapa: "recebido" aqui
 * significa sinal de status pago (ver `signalState`).
 */
export function buildFinanceSummary(
  appointments: readonly Appointment[],
  range: PeriodRange,
  timezone: string,
): FinanceSummary {
  const inRange = appointments.filter((a) => {
    const key = dateKeyOf(a.startAt, timezone);
    return key >= range.startKey && key < range.endKey;
  });
  const active = inRange.filter((a) => isBlockingStatus(a.status));
  const paid = active.filter((a) => signalState(a) === "paid");
  const pending = active.filter((a) => signalState(a) === "pending");
  const completed = inRange.filter((a) => a.status === "completed");

  const byDay = new Map<DateKey, FinanceDayRow>();
  for (const a of active) {
    const dateKey = dateKeyOf(a.startAt, timezone);
    const row = byDay.get(dateKey) ?? { dateKey, count: 0, expectedInCents: 0, signalsPaidInCents: 0 };
    row.count += 1;
    row.expectedInCents += a.priceInCents;
    if (signalState(a) === "paid") row.signalsPaidInCents += a.signalInCents;
    byDay.set(dateKey, row);
  }

  const sum = (items: readonly Appointment[], pick: (a: Appointment) => number) =>
    items.reduce((total, a) => total + pick(a), 0);

  return {
    expectedInCents: sum(active, (a) => a.priceInCents),
    activeCount: active.length,
    signalsPaidInCents: sum(paid, (a) => a.signalInCents),
    signalsPaidCount: paid.length,
    signalsPendingInCents: sum(pending, (a) => a.signalInCents),
    signalsPendingCount: pending.length,
    completedInCents: sum(completed, (a) => a.priceInCents),
    completedCount: completed.length,
    days: [...byDay.values()].sort((a, b) => a.dateKey.localeCompare(b.dateKey)),
    pendingSignals: [...pending].sort((a, b) => a.startAt.localeCompare(b.startAt)),
  };
}
