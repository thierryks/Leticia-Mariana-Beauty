"use client";

import { createContext, useContext, type ReactNode } from "react";
import type { DemoSession } from "@/features/auth/demo-auth-adapter";
import type { Tenant } from "@/types/tenant";

export interface AppSession {
  user: Pick<DemoSession, "userName">;
  /** Empresa atual. Toda leitura/escrita de dados usa `tenant.id`. */
  tenant: Tenant;
}

const SessionContext = createContext<AppSession | null>(null);

export function SessionProvider({ value, children }: { value: AppSession; children: ReactNode }) {
  return <SessionContext.Provider value={value}>{children}</SessionContext.Provider>;
}

export function useSession(): AppSession {
  const session = useContext(SessionContext);
  if (!session) throw new Error("useSession precisa estar dentro do SessionProvider.");
  return session;
}

export function useTenant(): Tenant {
  return useSession().tenant;
}
