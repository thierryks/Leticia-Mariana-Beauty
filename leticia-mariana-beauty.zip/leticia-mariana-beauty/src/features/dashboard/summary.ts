import { isBlockingStatus, signalState, sortByStart } from "@/features/appointments/rules";
import { buildClientOverviews } from "@/features/clients/overview";
import { isMaintenancePending } from "@/features/clients/rules";
import { dateKeyOf, type DateKey } from "@/lib/datetime";
import type { Appointment } from "@/types/appointment";
import type { Client } from "@/types/client";
import type { Service } from "@/types/service";

export interface DashboardSummary {
  today: Appointment[];
  todayActiveCount: number;
  awaitingConfirmation: Appointment[];
  expectedRevenueTodayInCents: number;
  maintenanceDueCount: number;
  /** Sinais combinados e ainda não pagos (hoje em diante). */
  pendingSignals: Appointment[];
  pendingSignalsInCents: number;
}

/**
 * Indicadores do dashboard. Hipóteses registradas:
 * - "Receita prevista do dia" soma os atendimentos de hoje que seguem ativos
 *   (exclui cancelados, faltas e remarcados).
 * - "Pagamentos pendentes" = sinais pendentes de hoje em diante, já que o
 *   módulo financeiro ainda não existe.
 */
export function buildDashboardSummary(
  appointments: readonly Appointment[],
  clients: readonly Client[],
  services: readonly Service[],
  todayKey: DateKey,
  timezone: string,
  now: number = Date.now(),
): DashboardSummary {
  const today = sortByStart(appointments.filter((a) => dateKeyOf(a.startAt, timezone) === todayKey));
  const activeToday = today.filter((a) => isBlockingStatus(a.status));
  const upcoming = appointments.filter((a) => new Date(a.endAt).getTime() >= now || dateKeyOf(a.startAt, timezone) === todayKey);

  const awaitingConfirmation = sortByStart(upcoming.filter((a) => a.status === "pending_confirmation"));
  const pendingSignals = sortByStart(
    upcoming.filter((a) => isBlockingStatus(a.status) && signalState(a) === "pending"),
  );

  const overviews = buildClientOverviews(
    clients.filter((c) => c.active),
    appointments,
    services,
    now,
  );

  return {
    today,
    todayActiveCount: activeToday.length,
    awaitingConfirmation,
    expectedRevenueTodayInCents: activeToday.reduce((sum, a) => sum + a.priceInCents, 0),
    maintenanceDueCount: overviews.filter((o) => isMaintenancePending(o.maintenance)).length,
    pendingSignals,
    pendingSignalsInCents: pendingSignals.reduce((sum, a) => sum + a.signalInCents, 0),
  };
}
