import { isBlockingStatus } from "@/features/appointments/rules";
import { STUDIO_SETTINGS } from "@/lib/constants/studio";
import { normalizeSearchText } from "@/lib/utils";
import type { Appointment } from "@/types/appointment";
import type { Client, ClientStatusFilter } from "@/types/client";

const DAY_MS = 86_400_000;

export interface ClientTimeline {
  lastCompleted?: Appointment;
  /** Último atendimento concluído que gera manutenção (extensão ou manutenção; remoção não). */
  lastMaintainable?: Appointment;
  nextActive?: Appointment;
  cancellations: number;
  noShows: number;
}

export function buildClientTimeline(
  clientId: string,
  appointments: readonly Appointment[],
  now: number = Date.now(),
  maintainableServiceIds?: ReadonlySet<string>,
): ClientTimeline {
  const own = appointments.filter((a) => a.clientId === clientId);
  const completed = own
    .filter((a) => a.status === "completed")
    .sort((a, b) => new Date(b.startAt).getTime() - new Date(a.startAt).getTime());
  const upcoming = own
    .filter((a) => isBlockingStatus(a.status) && a.status !== "completed" && new Date(a.endAt).getTime() >= now)
    .sort((a, b) => new Date(a.startAt).getTime() - new Date(b.startAt).getTime());
  return {
    lastCompleted: completed[0],
    lastMaintainable: maintainableServiceIds
      ? completed.find((a) => maintainableServiceIds.has(a.serviceId))
      : completed[0],
    nextActive: upcoming[0],
    cancellations: own.filter((a) => a.status === "cancelled_by_client" || a.status === "cancelled_by_business").length,
    noShows: own.filter((a) => a.status === "no_show").length,
  };
}

export type MaintenanceState =
  | { kind: "none" }
  | { kind: "scheduled"; appointment: Appointment }
  | { kind: "upcoming"; dueFrom: number; dueTo: number }
  | { kind: "due"; dueFrom: number; dueTo: number }
  | { kind: "overdue"; dueTo: number; daysLate: number };

/**
 * Política do studio: manutenção recomendada entre 15 e 20 dias após o
 * último atendimento concluído. Se já existe horário futuro, está agendada.
 */
export function maintenanceStateFor(timeline: ClientTimeline, now: number = Date.now()): MaintenanceState {
  if (timeline.nextActive) return { kind: "scheduled", appointment: timeline.nextActive };
  if (!timeline.lastMaintainable) return { kind: "none" };
  const last = new Date(timeline.lastMaintainable.startAt).getTime();
  const dueFrom = last + STUDIO_SETTINGS.maintenanceWindowDays.from * DAY_MS;
  const dueTo = last + STUDIO_SETTINGS.maintenanceWindowDays.to * DAY_MS;
  if (now < dueFrom) return { kind: "upcoming", dueFrom, dueTo };
  if (now <= dueTo) return { kind: "due", dueFrom, dueTo };
  return { kind: "overdue", dueTo, daysLate: Math.floor((now - dueTo) / DAY_MS) };
}

export function isMaintenancePending(state: MaintenanceState): boolean {
  return state.kind === "due" || state.kind === "overdue";
}

export function isNewClient(client: Client, now: number = Date.now()): boolean {
  return now - new Date(client.createdAt).getTime() <= STUDIO_SETTINGS.newClientDays * DAY_MS;
}

/** Busca por nome (sem acento/caixa) ou por dígitos do telefone. */
export function matchesClientSearch(client: Client, query: string): boolean {
  const trimmed = query.trim();
  if (trimmed === "") return true;
  const digits = trimmed.replace(/\D/g, "");
  if (digits.length >= 3 && client.phone.includes(digits)) return true;
  return normalizeSearchText(client.fullName).includes(normalizeSearchText(trimmed));
}

export function matchesClientStatus(
  client: Client,
  filter: ClientStatusFilter,
  maintenance: MaintenanceState,
  now: number = Date.now(),
): boolean {
  switch (filter) {
    case "all":
      return true;
    case "active":
      return client.active;
    case "inactive":
      return !client.active;
    case "new":
      return client.active && isNewClient(client, now);
    case "maintenance_due":
      return client.active && isMaintenancePending(maintenance);
  }
}

/** Alerta de duplicidade por telefone, sempre dentro da mesma empresa (RN-06). */
export function findDuplicateByPhone(
  clients: readonly Client[],
  tenantId: string,
  normalizedPhone: string,
  ignoreId?: string,
): Client | undefined {
  return clients.find(
    (client) => client.tenantId === tenantId && client.phone === normalizedPhone && client.id !== ignoreId,
  );
}
