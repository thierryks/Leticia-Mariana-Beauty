import { buildClientTimeline, isNewClient, maintenanceStateFor, type ClientTimeline, type MaintenanceState } from "./rules";
import type { Appointment } from "@/types/appointment";
import type { Client } from "@/types/client";
import type { Service } from "@/types/service";

const MAINTAINABLE_CATEGORIES = new Set<Service["category"]>(["extensao", "manutencao"]);

/** Serviços cujo atendimento concluído gera recomendação de manutenção. */
export function maintainableServiceIds(services: readonly Service[]): Set<string> {
  return new Set(services.filter((s) => MAINTAINABLE_CATEGORIES.has(s.category)).map((s) => s.id));
}

export interface ClientOverview {
  client: Client;
  timeline: ClientTimeline;
  maintenance: MaintenanceState;
  isNew: boolean;
}

/** Junta cada cliente ao seu histórico. Recebe dados já filtrados pela empresa. */
export function buildClientOverviews(
  clients: readonly Client[],
  appointments: readonly Appointment[],
  services: readonly Service[],
  now: number = Date.now(),
): ClientOverview[] {
  const maintainable = maintainableServiceIds(services);
  return clients.map((client) => {
    const timeline = buildClientTimeline(client.id, appointments, now, maintainable);
    return {
      client,
      timeline,
      maintenance: maintenanceStateFor(timeline, now),
      isNew: isNewClient(client, now),
    };
  });
}
