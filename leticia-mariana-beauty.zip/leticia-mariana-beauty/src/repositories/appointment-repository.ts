import type { Appointment, NewAppointmentInput } from "@/types/appointment";

export interface AvailabilityQuery {
  professionalId: string;
  serviceId: string;
  startAt: string;
  ignoreAppointmentId?: string;
}

export interface AvailabilityResult {
  endAt: string;
  conflicts: Appointment[];
}

/**
 * Contrato da agenda. A implementação mock vive em `./mock`; a futura
 * implementação Supabase deve respeitar exatamente esta interface, para
 * que as telas não precisem mudar.
 *
 * Supabase/RLS: tabela `appointments` com policy de SELECT/INSERT/UPDATE
 * restrita ao tenant do usuário autenticado; a verificação de conflito deve
 * rodar no banco (exclusion constraint ou função RPC em transação).
 */
export interface AppointmentRepository {
  /** Agendamentos cujo início está entre `fromIso` (inclusivo) e `toIso` (exclusivo). */
  listBetween(tenantId: string, fromIso: string, toIso: string): Promise<Appointment[]>;
  listByClient(tenantId: string, clientId: string): Promise<Appointment[]>;
  listAll(tenantId: string): Promise<Appointment[]>;
  getById(tenantId: string, id: string): Promise<Appointment | null>;
  checkAvailability(tenantId: string, query: AvailabilityQuery): Promise<AvailabilityResult>;
  /** Lança `AppointmentConflictError` se o horário estiver ocupado. */
  create(tenantId: string, input: NewAppointmentInput): Promise<Appointment>;
}
