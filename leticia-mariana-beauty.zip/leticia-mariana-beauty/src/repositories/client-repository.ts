import type { Client, ClientInput } from "@/types/client";

/**
 * Supabase/RLS: tabela `clients` com policy por tenant_id. A coluna
 * `sensitivities` deve ficar em tabela separada (`client_restricted_notes`)
 * com policy só para a proprietária e auditoria de leitura (RN-07).
 * Não existe exclusão física: apenas `active = false` (soft delete).
 */
export interface ClientRepository {
  list(tenantId: string): Promise<Client[]>;
  getById(tenantId: string, id: string): Promise<Client | null>;
  findByPhone(tenantId: string, normalizedPhone: string, ignoreId?: string): Promise<Client | null>;
  /** Lança `DuplicatePhoneError` se o telefone já existir na empresa e `allowDuplicatePhone` for falso. */
  create(tenantId: string, input: ClientInput, options?: { allowDuplicatePhone?: boolean }): Promise<Client>;
  update(tenantId: string, id: string, input: ClientInput): Promise<Client>;
  setActive(tenantId: string, id: string, active: boolean): Promise<Client>;
}
