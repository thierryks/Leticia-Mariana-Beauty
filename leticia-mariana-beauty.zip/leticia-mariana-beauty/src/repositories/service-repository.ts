import type { Service, ServiceInput } from "@/types/service";

/** Supabase/RLS: tabela `services` com policy por tenant_id. Leitura pública futura só de serviços ativos (portal). */
export interface ServiceRepository {
  list(tenantId: string): Promise<Service[]>;
  getById(tenantId: string, id: string): Promise<Service | null>;
  create(tenantId: string, input: ServiceInput): Promise<Service>;
  update(tenantId: string, id: string, input: ServiceInput): Promise<Service>;
}
