/**
 * Ponto único de troca da camada de dados.
 *
 * Para migrar ao Supabase: criar `./supabase/*` implementando as mesmas
 * interfaces e trocar as atribuições abaixo. Nenhuma tela importa os mocks
 * diretamente.
 */
import type { AppointmentRepository } from "./appointment-repository";
import type { ClientRepository } from "./client-repository";
import type { ServiceRepository } from "./service-repository";
import type { AlertRepository, ProfessionalRepository, TenantRepository } from "./support-repositories";
import { mockAppointmentRepository } from "./mock/mock-appointment-repository";
import { mockClientRepository } from "./mock/mock-client-repository";
import { mockServiceRepository } from "./mock/mock-service-repository";
import {
  mockAlertRepository,
  mockProfessionalRepository,
  mockTenantRepository,
} from "./mock/mock-support-repositories";

export interface Repositories {
  appointments: AppointmentRepository;
  clients: ClientRepository;
  services: ServiceRepository;
  professionals: ProfessionalRepository;
  tenants: TenantRepository;
  alerts: AlertRepository;
}

export const repositories: Repositories = {
  appointments: mockAppointmentRepository,
  clients: mockClientRepository,
  services: mockServiceRepository,
  professionals: mockProfessionalRepository,
  tenants: mockTenantRepository,
  alerts: mockAlertRepository,
};

export * from "./errors";
export type { AppointmentRepository, ClientRepository, ServiceRepository };
