import { clone, getMockDatabase, simulateLatency } from "@/mocks/store";
import { scopeToTenant } from "@/lib/tenant-scope";
import type { AlertRepository, ProfessionalRepository, TenantRepository } from "../support-repositories";

/** ADAPTERS DE DESENVOLVIMENTO — dados demonstrativos em memória. */
export const mockTenantRepository: TenantRepository = {
  async getById(tenantId) {
    const tenant = getMockDatabase().tenants.find((t) => t.id === tenantId && t.active);
    return tenant ? clone(tenant) : null;
  },
};

export const mockProfessionalRepository: ProfessionalRepository = {
  async list(tenantId) {
    await simulateLatency(150);
    return clone(scopeToTenant(getMockDatabase().professionals, tenantId));
  },
};

export const mockAlertRepository: AlertRepository = {
  async listOperational(tenantId) {
    await simulateLatency(150);
    return clone(scopeToTenant(getMockDatabase().alerts, tenantId));
  },
};
