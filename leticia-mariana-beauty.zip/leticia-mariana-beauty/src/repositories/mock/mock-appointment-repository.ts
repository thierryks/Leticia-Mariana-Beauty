import { calculateEndAt, findConflicts, AppointmentConflictError, sortByStart } from "@/features/appointments/rules";
import { clone, getMockDatabase, simulateLatency } from "@/mocks/store";
import { scopeToTenant } from "@/lib/tenant-scope";
import { createId } from "@/lib/utils";
import type { Appointment, NewAppointmentInput } from "@/types/appointment";
import type { AppointmentRepository, AvailabilityQuery, AvailabilityResult } from "../appointment-repository";
import { NotFoundError, ValidationError } from "../errors";

/** ADAPTER DE DESENVOLVIMENTO — dados demonstrativos em memória. */
export const mockAppointmentRepository: AppointmentRepository = {
  async listBetween(tenantId, fromIso, toIso) {
    await simulateLatency();
    const from = new Date(fromIso).getTime();
    const to = new Date(toIso).getTime();
    const rows = scopeToTenant(getMockDatabase().appointments, tenantId).filter((a) => {
      const start = new Date(a.startAt).getTime();
      return start >= from && start < to;
    });
    return clone(sortByStart(rows));
  },

  async listByClient(tenantId, clientId) {
    await simulateLatency();
    const rows = scopeToTenant(getMockDatabase().appointments, tenantId).filter((a) => a.clientId === clientId);
    return clone(sortByStart(rows));
  },

  async listAll(tenantId) {
    await simulateLatency();
    return clone(sortByStart(scopeToTenant(getMockDatabase().appointments, tenantId)));
  },

  async getById(tenantId, id) {
    await simulateLatency();
    const row = scopeToTenant(getMockDatabase().appointments, tenantId).find((a) => a.id === id);
    return row ? clone(row) : null;
  },

  async checkAvailability(tenantId, query: AvailabilityQuery): Promise<AvailabilityResult> {
    const db = getMockDatabase();
    const service = scopeToTenant(db.services, tenantId).find((s) => s.id === query.serviceId);
    if (!service) throw new NotFoundError("Serviço");
    const endAt = calculateEndAt(query.startAt, service.durationMinutes, service.preparationIntervalMinutes);
    const conflicts = findConflicts(
      {
        id: query.ignoreAppointmentId,
        tenantId,
        professionalId: query.professionalId,
        startAt: query.startAt,
        endAt,
      },
      scopeToTenant(db.appointments, tenantId),
    );
    return { endAt, conflicts: clone(conflicts) };
  },

  async create(tenantId, input: NewAppointmentInput) {
    await simulateLatency(400);
    const db = getMockDatabase();
    const client = scopeToTenant(db.clients, tenantId).find((c) => c.id === input.clientId);
    const service = scopeToTenant(db.services, tenantId).find((s) => s.id === input.serviceId);
    const professional = scopeToTenant(db.professionals, tenantId).find((p) => p.id === input.professionalId);
    if (!client || !client.active) throw new ValidationError("Escolha uma cliente ativa.");
    if (!service || !service.active) throw new ValidationError("Escolha um serviço ativo.");
    if (!professional || !professional.active) throw new ValidationError("Escolha uma profissional ativa.");
    if (input.signalInCents > service.priceInCents) {
      throw new ValidationError("O sinal não pode ser maior que o valor do serviço.");
    }

    const endAt = calculateEndAt(input.startAt, service.durationMinutes, service.preparationIntervalMinutes);

    // A regra é reaplicada aqui, no momento de salvar — nunca confiar só na tela.
    // No Supabase isto será garantido pelo banco, dentro da mesma transação.
    const conflicts = findConflicts(
      { tenantId, professionalId: professional.id, startAt: input.startAt, endAt },
      scopeToTenant(db.appointments, tenantId),
    );
    if (conflicts.length > 0) throw new AppointmentConflictError(clone(conflicts));

    const now = new Date().toISOString();
    const appointment: Appointment = {
      id: createId("apt"),
      tenantId,
      clientId: client.id,
      clientName: client.fullName,
      serviceId: service.id,
      serviceName: service.name,
      professionalId: professional.id,
      professionalName: professional.name,
      startAt: input.startAt,
      endAt,
      status: input.status,
      // RN-03: preço copiado do catálogo no momento da criação.
      priceInCents: service.priceInCents,
      signalInCents: input.signalInCents,
      notes: input.notes,
      source: input.source,
      createdAt: now,
      updatedAt: now,
    };
    db.appointments.push(appointment);
    return clone(appointment);
  },
};
