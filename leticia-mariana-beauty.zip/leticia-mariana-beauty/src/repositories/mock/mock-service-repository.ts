import { clone, getMockDatabase, simulateLatency } from "@/mocks/store";
import { scopeToTenant } from "@/lib/tenant-scope";
import { createId } from "@/lib/utils";
import type { Service, ServiceInput } from "@/types/service";
import type { ServiceRepository } from "../service-repository";
import { NotFoundError, ValidationError } from "../errors";

function assertValid(input: ServiceInput) {
  if (!Number.isInteger(input.priceInCents) || input.priceInCents < 0) {
    throw new ValidationError("Preço inválido.");
  }
  if (input.durationMinutes <= 0) throw new ValidationError("Duração inválida.");
}

/** ADAPTER DE DESENVOLVIMENTO — dados demonstrativos em memória. */
export const mockServiceRepository: ServiceRepository = {
  async list(tenantId) {
    await simulateLatency();
    return clone(scopeToTenant(getMockDatabase().services, tenantId));
  },

  async getById(tenantId, id) {
    await simulateLatency();
    const row = scopeToTenant(getMockDatabase().services, tenantId).find((s) => s.id === id);
    return row ? clone(row) : null;
  },

  async create(tenantId, input) {
    await simulateLatency(400);
    assertValid(input);
    const service: Service = { ...input, id: createId("svc"), tenantId };
    getMockDatabase().services.push(service);
    return clone(service);
  },

  async update(tenantId, id, input) {
    await simulateLatency(400);
    assertValid(input);
    const service = scopeToTenant(getMockDatabase().services, tenantId).find((s) => s.id === id);
    if (!service) throw new NotFoundError("Serviço");
    // Agendamentos existentes guardam o próprio preço (RN-03): mudar o catálogo não altera o passado.
    Object.assign(service, input);
    return clone(service);
  },
};
