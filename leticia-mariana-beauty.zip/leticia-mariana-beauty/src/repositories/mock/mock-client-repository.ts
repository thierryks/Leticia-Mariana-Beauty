import { findDuplicateByPhone } from "@/features/clients/rules";
import { clone, getMockDatabase, simulateLatency } from "@/mocks/store";
import { scopeToTenant } from "@/lib/tenant-scope";
import { createId } from "@/lib/utils";
import type { Client, ClientInput } from "@/types/client";
import type { ClientRepository } from "../client-repository";
import { DuplicatePhoneError, NotFoundError } from "../errors";

function findOwn(tenantId: string, id: string): Client {
  const client = scopeToTenant(getMockDatabase().clients, tenantId).find((c) => c.id === id);
  if (!client) throw new NotFoundError("Cliente");
  return client;
}

/** ADAPTER DE DESENVOLVIMENTO — dados demonstrativos em memória. */
export const mockClientRepository: ClientRepository = {
  async list(tenantId) {
    await simulateLatency();
    const rows = scopeToTenant(getMockDatabase().clients, tenantId).sort((a, b) =>
      a.fullName.localeCompare(b.fullName, "pt-BR"),
    );
    return clone(rows);
  },

  async getById(tenantId, id) {
    await simulateLatency();
    const row = scopeToTenant(getMockDatabase().clients, tenantId).find((c) => c.id === id);
    return row ? clone(row) : null;
  },

  async findByPhone(tenantId, normalizedPhone, ignoreId) {
    const match = findDuplicateByPhone(getMockDatabase().clients, tenantId, normalizedPhone, ignoreId);
    return match ? clone(match) : null;
  },

  async create(tenantId, input: ClientInput, options) {
    await simulateLatency(400);
    const db = getMockDatabase();
    const duplicate = findDuplicateByPhone(db.clients, tenantId, input.phone);
    if (duplicate && !options?.allowDuplicatePhone) {
      throw new DuplicatePhoneError({ id: duplicate.id, fullName: duplicate.fullName });
    }
    const now = new Date().toISOString();
    const client: Client = { ...input, id: createId("cli"), tenantId, createdAt: now, updatedAt: now, active: true };
    db.clients.push(client);
    return clone(client);
  },

  async update(tenantId, id, input) {
    await simulateLatency(400);
    const client = findOwn(tenantId, id);
    Object.assign(client, input, { updatedAt: new Date().toISOString() });
    return clone(client);
  },

  /** Desativação lógica. Não existe exclusão física de clientes. */
  async setActive(tenantId, id, active) {
    await simulateLatency(300);
    const client = findOwn(tenantId, id);
    client.active = active;
    client.updatedAt = new Date().toISOString();
    return clone(client);
  },
};
