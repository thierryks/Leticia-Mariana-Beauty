import type { Client } from "@/types/client";

export { AppointmentConflictError } from "@/features/appointments/rules";

export class NotFoundError extends Error {
  constructor(entity: string) {
    super(`${entity} não encontrado(a).`);
    this.name = "NotFoundError";
  }
}

export class ValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ValidationError";
  }
}

export class DuplicatePhoneError extends Error {
  readonly existing: Pick<Client, "id" | "fullName">;

  constructor(existing: Pick<Client, "id" | "fullName">) {
    super("Já existe uma cliente com este telefone.");
    this.name = "DuplicatePhoneError";
    this.existing = existing;
  }
}
