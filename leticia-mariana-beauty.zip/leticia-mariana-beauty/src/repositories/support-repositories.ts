import type { OperationalAlert } from "@/mocks/alerts";
import type { Professional } from "@/types/professional";
import type { Tenant } from "@/types/tenant";

export type { OperationalAlert };

export interface TenantRepository {
  getById(tenantId: string): Promise<Tenant | null>;
}

/** Supabase/RLS: tabela `professionals` com policy por tenant_id. */
export interface ProfessionalRepository {
  list(tenantId: string): Promise<Professional[]>;
}

/** Alertas de estoque e mensagens. Nesta etapa, apenas exemplos. */
export interface AlertRepository {
  listOperational(tenantId: string): Promise<OperationalAlert[]>;
}
