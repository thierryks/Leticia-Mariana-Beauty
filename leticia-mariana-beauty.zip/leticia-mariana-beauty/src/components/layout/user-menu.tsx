"use client";

import { ChevronDown, LogOut, Settings } from "lucide-react";
import { useRouter } from "next/navigation";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { demoAuthAdapter } from "@/features/auth/demo-auth-adapter";
import { useSession } from "@/features/tenant/session-context";

function initials(name: string) {
  return name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join("");
}

export function UserMenu() {
  const router = useRouter();
  const { user, tenant } = useSession();

  return (
    <DropdownMenu>
      <DropdownMenuTrigger
        aria-label={`Menu da usuária ${user.userName}`}
        className="inline-flex h-11 items-center gap-2 rounded-full py-1 pr-2 pl-1 text-sm text-brown hover:bg-sand/70"
      >
        <span className="brand-title inline-flex size-9 items-center justify-center rounded-full bg-brown text-[0.8rem] tracking-[0.08em] text-background">
          {initials(user.userName)}
        </span>
        <span className="hidden font-medium lg:inline">{user.userName.split(" ")[0]}</span>
        <ChevronDown aria-hidden className="hidden size-4 text-muted lg:block" />
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuLabel>
          <p className="font-semibold text-brown">{user.userName}</p>
          <p className="text-xs text-muted">{tenant.name}</p>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuItem onSelect={() => router.push("/configuracoes")}>
          <Settings aria-hidden />
          Configurações
        </DropdownMenuItem>
        <DropdownMenuItem
          onSelect={() => {
            demoAuthAdapter.signOut();
            router.replace("/login");
          }}
        >
          <LogOut aria-hidden />
          Sair
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
