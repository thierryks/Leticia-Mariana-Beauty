"use client";

import { Search } from "lucide-react";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

/** Busca de clientes por nome ou telefone, de qualquer tela. */
export function GlobalSearch({ className }: { className?: string }) {
  const router = useRouter();
  const [query, setQuery] = useState("");

  return (
    <form
      role="search"
      className={cn("relative", className)}
      onSubmit={(event) => {
        event.preventDefault();
        const term = query.trim();
        router.push(term ? `/clientes?busca=${encodeURIComponent(term)}` : "/clientes");
      }}
    >
      <Search aria-hidden className="pointer-events-none absolute top-1/2 left-3.5 size-4 -translate-y-1/2 text-muted" />
      <Input
        type="search"
        aria-label="Buscar cliente por nome ou telefone"
        placeholder="Buscar cliente por nome ou telefone"
        value={query}
        onChange={(event) => setQuery(event.target.value)}
        className="h-10 rounded-full bg-background pl-10"
      />
    </form>
  );
}
