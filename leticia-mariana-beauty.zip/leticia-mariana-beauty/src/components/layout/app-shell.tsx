"use client";

import { Menu, Plus } from "lucide-react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState, useSyncExternalStore, type ReactNode } from "react";
import { Monogram, Wordmark } from "@/components/brand/logo";
import { ErrorState } from "@/components/shared/states";
import { Button, buttonVariants } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { TooltipProvider } from "@/components/ui/tooltip";
import { demoAuthAdapter } from "@/features/auth/demo-auth-adapter";
import { SessionProvider } from "@/features/tenant/session-context";
import { useAsyncData } from "@/hooks/use-async-data";
import { cn } from "@/lib/utils";
import { repositories } from "@/repositories";
import { GlobalSearch } from "./global-search";
import { SidebarNav } from "./sidebar-nav";
import { UserMenu } from "./user-menu";

const SERVER_SNAPSHOT = "__server__";

function useStoredSession() {
  // sessionStorage não dispara eventos na mesma aba; a leitura acontece na montagem.
  const raw = useSyncExternalStore(
    () => () => {},
    () => JSON.stringify(demoAuthAdapter.getSession()),
    () => SERVER_SNAPSHOT,
  );
  if (raw === SERVER_SNAPSHOT) return { checked: false as const };
  return { checked: true as const, session: demoAuthAdapter.getSession() };
}

function Splash() {
  return (
    <div role="status" aria-live="polite" className="flex min-h-dvh flex-col items-center justify-center gap-3">
      <Monogram className="size-14 animate-pulse" title="" />
      <span className="text-sm text-muted">Carregando…</span>
    </div>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  const stored = useStoredSession();
  const tenantId = stored.checked ? stored.session?.tenantId : undefined;
  const [drawerOpen, setDrawerOpen] = useState(false);

  const tenantQuery = useAsyncData(`tenant:${tenantId ?? "-"}`, async () =>
    tenantId ? repositories.tenants.getById(tenantId) : null,
  );

  useEffect(() => {
    if (stored.checked && !stored.session) router.replace("/login");
  }, [stored.checked, stored.session, router]);

  if (!stored.checked || !stored.session || tenantQuery.loading) return <Splash />;
  if (tenantQuery.error || !tenantQuery.data) {
    return (
      <div className="mx-auto max-w-md p-6 pt-24">
        <ErrorState message="Não encontramos a empresa vinculada a esta conta. Entre novamente." />
        <Button className="mt-4" onClick={() => router.replace("/login")}>
          Voltar para o login
        </Button>
      </div>
    );
  }

  const tenant = tenantQuery.data;
  // O botão flutuante some na agenda (que tem o seu) e nos formulários, para não cobrir campos.
  const showFab = !pathname.startsWith("/agenda") && pathname !== "/clientes/novo";

  return (
    <SessionProvider value={{ user: { userName: stored.session.userName }, tenant }}>
      <TooltipProvider>
        <a
          href="#conteudo"
          className="sr-only z-50 rounded-full bg-brown px-4 py-2 text-background focus:not-sr-only focus:fixed focus:top-3 focus:left-3"
        >
          Pular para o conteúdo
        </a>

        {/* Menu lateral fixo — desktop */}
        <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 border-r border-sand-strong/70 bg-sand lg:block">
          <SidebarNav />
        </aside>

        {/* Drawer — celular e tablet */}
        <Dialog open={drawerOpen} onOpenChange={setDrawerOpen}>
          <DialogContent side="left" className="bg-sand p-0">
            <DialogTitle className="sr-only">Menu</DialogTitle>
            <DialogDescription className="sr-only">Navegação principal do sistema</DialogDescription>
            <SidebarNav onNavigate={() => setDrawerOpen(false)} />
          </DialogContent>
        </Dialog>

        <div className="lg:pl-64">
          <header className="sticky top-0 z-20 border-b border-line bg-background/90 backdrop-blur supports-[backdrop-filter]:bg-background/75">
            <div className="flex h-16 items-center gap-2 px-3 sm:px-6 lg:px-10">
              <Button
                variant="ghost"
                size="icon"
                className="lg:hidden"
                aria-label="Abrir menu"
                onClick={() => setDrawerOpen(true)}
              >
                <Menu className="size-5" />
              </Button>
              <Link href="/dashboard" className="lg:hidden" aria-label="Início">
                <Wordmark compact className="[&_p:last-child]:hidden sm:[&_p:last-child]:block" />
              </Link>

              <div className="hidden min-w-0 lg:block">
                <p className="text-xs text-muted">Unidade</p>
                <p className="truncate text-sm font-semibold text-brown">{tenant.name}</p>
              </div>

              <div className="ml-auto flex items-center gap-2">
                <GlobalSearch className="hidden md:block md:w-56 lg:w-72 xl:w-96" />
                <Link
                  href="/agenda?novo=1"
                  className={cn(buttonVariants({ size: "sm" }), "hidden md:inline-flex")}
                >
                  <Plus aria-hidden />
                  Novo agendamento
                </Link>
                <UserMenu />
              </div>
            </div>
            <div className="px-3 pb-3 sm:px-6 md:hidden">
              <GlobalSearch />
            </div>
          </header>

          <main id="conteudo" className="mx-auto w-full max-w-6xl px-4 pt-6 pb-28 sm:px-6 lg:px-10 lg:pt-10 lg:pb-16">
            {children}
          </main>
        </div>

        {/* Ação principal sempre à mão no celular */}
        {showFab && (
          <Link
            href="/agenda?novo=1"
            className={cn(
              buttonVariants({ size: "lg" }),
              "fixed right-4 bottom-[max(1rem,env(safe-area-inset-bottom))] z-30 shadow-[0_12px_30px_-10px_rgb(68_55_43/0.6)] md:hidden",
            )}
          >
            <Plus aria-hidden />
            Novo agendamento
          </Link>
        )}
      </TooltipProvider>
    </SessionProvider>
  );
}
