"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Wordmark } from "@/components/brand/logo";
import { NAV_ITEMS, isNavItemActive } from "@/lib/constants/navigation";
import { cn } from "@/lib/utils";

/** Conteúdo do menu lateral, usado no desktop (fixo) e no drawer (mobile). */
export function SidebarNav({ onNavigate }: { onNavigate?: () => void }) {
  const pathname = usePathname();

  return (
    <div className="flex h-full flex-col">
      <div className="px-6 pt-7 pb-8">
        <Link href="/dashboard" onClick={onNavigate} aria-label="Letícia Mariana Beauty — início" className="inline-block rounded-lg">
          <Wordmark />
        </Link>
      </div>

      <nav aria-label="Menu principal" className="flex-1 px-3">
        <ul className="space-y-1">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            if (item.comingSoon) {
              return (
                <li key={item.href}>
                  <span
                    aria-disabled="true"
                    className="flex h-11 items-center gap-3 rounded-xl px-3.5 text-sm text-muted/80"
                  >
                    <Icon aria-hidden className="size-4.5" />
                    <span className="flex-1">{item.label}</span>
                    <span className="rounded-full border border-sand-strong px-2 py-0.5 text-[0.68rem] whitespace-nowrap text-muted">
                      Em breve
                    </span>
                  </span>
                </li>
              );
            }
            const active = isNavItemActive(pathname, item.href);
            return (
              <li key={item.href}>
                <Link
                  href={item.href}
                  onClick={onNavigate}
                  aria-current={active ? "page" : undefined}
                  className={cn(
                    "relative flex h-11 items-center gap-3 rounded-xl px-3.5 text-sm transition-colors",
                    active
                      ? "bg-surface font-semibold text-brown shadow-[0_1px_2px_rgb(91_74_59/0.08)]"
                      : "text-ink/80 hover:bg-surface/60 hover:text-brown",
                  )}
                >
                  {active && <span aria-hidden className="absolute top-2.5 bottom-2.5 left-0 w-[3px] rounded-full bg-gold" />}
                  <Icon aria-hidden className={cn("size-4.5", active ? "text-gold-ink" : "text-muted")} />
                  {item.label}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>

      <div className="px-6 pt-6 pb-7">
        <div aria-hidden className="mb-4 h-px bg-linear-to-r from-gold/60 to-transparent" />
        <p className="font-script text-xl leading-tight text-brown/75">Voltado para a beleza na naturalidade.</p>
      </div>
    </div>
  );
}
