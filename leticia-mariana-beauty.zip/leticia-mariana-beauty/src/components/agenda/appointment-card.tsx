"use client";

import { isBlockingStatus } from "@/features/appointments/rules";
import { StatusBadge } from "@/components/shared/status-badge";
import { APPOINTMENT_SOURCE_LABEL } from "@/lib/constants/labels";
import { formatTime } from "@/lib/datetime";
import { formatCents } from "@/lib/formatters/currency";
import { cn } from "@/lib/utils";
import type { Appointment } from "@/types/appointment";
import { SignalTag } from "./signal-tag";

export function AppointmentCard({
  appointment,
  timezone,
  onOpen,
}: {
  appointment: Appointment;
  timezone: string;
  onOpen: () => void;
}) {
  const start = formatTime(appointment.startAt, timezone);
  const end = formatTime(appointment.endAt, timezone);
  const inactive = !isBlockingStatus(appointment.status);

  return (
    <button
      type="button"
      onClick={onOpen}
      aria-label={`${start} às ${end}, ${appointment.clientName}, ${appointment.serviceName}. Ver detalhes.`}
      className={cn(
        "group w-full rounded-[var(--radius-card)] border bg-surface p-4 text-left shadow-[var(--shadow-soft)] transition-colors hover:border-gold/60 sm:p-5",
        inactive ? "border-dashed border-sand-strong bg-surface/60 shadow-none" : "border-line",
      )}
    >
      <div className="flex flex-wrap items-start justify-between gap-x-4 gap-y-2">
        <div className="min-w-0">
          <p className="tabular text-sm text-muted">
            <span className={cn("font-semibold text-brown", inactive && "text-muted line-through decoration-1")}>{start}</span>
            {" – "}
            {end}
          </p>
          <p className={cn("mt-1 truncate text-base font-semibold text-ink", inactive && "text-ink/60")}>
            {appointment.clientName}
          </p>
          <p className="truncate text-sm text-ink/75">{appointment.serviceName}</p>
        </div>
        <StatusBadge status={appointment.status} />
      </div>

      <div className="mt-3.5 flex flex-wrap items-center gap-x-4 gap-y-1.5 border-t border-line pt-3 text-xs text-muted">
        <span>{appointment.professionalName}</span>
        <span className="tabular font-medium text-ink">{formatCents(appointment.priceInCents)}</span>
        <span>Origem: {APPOINTMENT_SOURCE_LABEL[appointment.source]}</span>
        <SignalTag appointment={appointment} />
      </div>
    </button>
  );
}
