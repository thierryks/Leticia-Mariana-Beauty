"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { CalendarCheck2, LoaderCircle } from "lucide-react";
import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { Controller, useForm, useWatch } from "react-hook-form";
import { DateField } from "@/components/shared/date-field";
import { FormField } from "@/components/shared/form-field";
import { MoneyInput } from "@/components/shared/money-input";
import { ResponsiveDialog } from "@/components/shared/responsive-dialog";
import { FormAlert, LoadingState } from "@/components/shared/states";
import { Button } from "@/components/ui/button";
import { DialogBody, DialogFooter } from "@/components/ui/dialog";
import { NativeSelect } from "@/components/ui/native-select";
import { Textarea } from "@/components/ui/textarea";
import { bookableStartTimes } from "@/features/appointments/agenda";
import { useTenant } from "@/features/tenant/session-context";
import { useAsyncData } from "@/hooks/use-async-data";
import { useNow } from "@/hooks/use-now";
import {
  APPOINTMENT_SOURCE_LABEL,
  APPOINTMENT_STATUS_META,
  INITIAL_STATUS_OPTIONS,
} from "@/lib/constants/labels";
import {
  formatDuration,
  formatTime,
  minutesOfDay,
  shiftDateKey,
  todayKey,
  zonedDateTimeToUtc,
  type DateKey,
} from "@/lib/datetime";
import { formatCents } from "@/lib/formatters/currency";
import { appointmentFormSchema, type AppointmentFormValues } from "@/lib/validators/appointment";
import { AppointmentConflictError, repositories } from "@/repositories";
import { APPOINTMENT_SOURCES, type Appointment, type AppointmentSource } from "@/types/appointment";
import type { Client } from "@/types/client";
import type { Professional } from "@/types/professional";
import type { Service } from "@/types/service";

export interface NewAppointmentDefaults {
  date: DateKey;
  time?: string;
  professionalId?: string;
  clientId?: string;
}

interface DialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  defaults: NewAppointmentDefaults;
  onCreated: (appointment: Appointment) => void;
}

export function NewAppointmentDialog({ open, onOpenChange, defaults, onCreated }: DialogProps) {
  return (
    <ResponsiveDialog
      open={open}
      onOpenChange={onOpenChange}
      title="Novo agendamento"
      description="O horário final é calculado pela duração do serviço mais o tempo de preparo."
      desktop="drawer"
      rawContent
    >
      {open && <NewAppointmentLoader defaults={defaults} onCancel={() => onOpenChange(false)} onCreated={onCreated} />}
    </ResponsiveDialog>
  );
}

function NewAppointmentLoader({
  defaults,
  onCancel,
  onCreated,
}: {
  defaults: NewAppointmentDefaults;
  onCancel: () => void;
  onCreated: (appointment: Appointment) => void;
}) {
  const tenant = useTenant();
  const options = useAsyncData(`new-appointment-options:${tenant.id}`, async () => {
    const [clients, services, professionals] = await Promise.all([
      repositories.clients.list(tenant.id),
      repositories.services.list(tenant.id),
      repositories.professionals.list(tenant.id),
    ]);
    return {
      clients: clients.filter((c) => c.active),
      services: services.filter((s) => s.active),
      professionals: professionals.filter((p) => p.active),
    };
  });

  if (!options.data) {
    return (
      <DialogBody>
        {options.error ? <FormAlert title="Não foi possível carregar clientes e serviços." /> : <LoadingState rows={3} />}
      </DialogBody>
    );
  }

  return <NewAppointmentForm {...options.data} defaults={defaults} onCancel={onCancel} onCreated={onCreated} />;
}

function NewAppointmentForm({
  clients,
  services,
  professionals,
  defaults,
  onCancel,
  onCreated,
}: {
  clients: Client[];
  services: Service[];
  professionals: Professional[];
  defaults: NewAppointmentDefaults;
  onCancel: () => void;
  onCreated: (appointment: Appointment) => void;
}) {
  const tenant = useTenant();
  const tz = tenant.timezone;
  const [source, setSource] = useState<AppointmentSource>("whatsapp");
  const [saveError, setSaveError] = useState<{ title: string; detail?: string } | null>(null);

  const {
    control,
    register,
    handleSubmit,
    setError,
    setValue,
    formState: { errors, isSubmitting },
  } = useForm<AppointmentFormValues>({
    resolver: zodResolver(appointmentFormSchema),
    defaultValues: {
      clientId: defaults.clientId ?? "",
      serviceId: "",
      professionalId: defaults.professionalId ?? professionals[0]?.id ?? "",
      date: defaults.date,
      time: defaults.time ?? "",
      status: "pending_confirmation",
      signalInCents: 0,
      notes: "",
    },
  });

  const [serviceId, professionalId, date, time] = useWatch({
    control,
    name: ["serviceId", "professionalId", "date", "time"],
  });
  const service = services.find((s) => s.id === serviceId);
  const ready = Boolean(service && professionalId && /^\d{4}-\d{2}-\d{2}$/.test(date) && time);

  // Verificação ao vivo, para orientar. A regra é reaplicada no momento de salvar.
  const availability = useAsyncData(`availability:${serviceId}:${professionalId}:${date}:${time}`, async () => {
    if (!ready) return null;
    return repositories.appointments.checkAvailability(tenant.id, {
      serviceId,
      professionalId,
      startAt: zonedDateTimeToUtc(date, time, tz),
    });
  });
  const conflicts = availability.data?.conflicts ?? [];

  // Horários livres: só entram os que cabem sem encostar em nenhum agendamento ativo da profissional.
  const dayKey = /^\d{4}-\d{2}-\d{2}$/.test(date) ? date : "";
  const timeReady = Boolean(service && professionalId && dayKey);
  const dayAppointments = useAsyncData(`day-appointments:${tenant.id}:${professionalId}:${dayKey}`, async () => {
    if (!dayKey || !professionalId) return null;
    const from = zonedDateTimeToUtc(dayKey, "00:00", tz);
    const to = zonedDateTimeToUtc(shiftDateKey(dayKey, 1), "00:00", tz);
    const rows = await repositories.appointments.listBetween(tenant.id, from, to);
    return rows.filter((a) => a.professionalId === professionalId);
  });
  const nowInstant = useNow();
  const startTimes = useMemo<string[] | null>(() => {
    if (!service || !timeReady || !dayAppointments.data) return null;
    return bookableStartTimes({
      appointments: dayAppointments.data,
      dateKey: dayKey,
      todayKey: todayKey(tz, nowInstant),
      timezone: tz,
      totalMinutes: service.durationMinutes + service.preparationIntervalMinutes,
      nowMinute: minutesOfDay(new Date(nowInstant).toISOString(), tz),
    });
  }, [service, timeReady, dayAppointments.data, dayKey, tz, nowInstant]);

  // Se o horário escolhido deixou de estar livre (outro serviço, outra data), limpa a escolha.
  useEffect(() => {
    if (startTimes && time && !startTimes.includes(time)) setValue("time", "");
  }, [startTimes, time, setValue]);

  const timePlaceholder = !timeReady
    ? "--:--"
    : startTimes === null
      ? "Carregando…"
      : startTimes.length === 0
        ? "Sem vagas"
        : "Escolha o horário";
  const timeHint = !timeReady
    ? "Escolha serviço, profissional e data para ver os horários livres."
    : startTimes === null
      ? "Carregando horários livres…"
      : startTimes.length === 0
        ? "Sem horários livres neste dia para este serviço."
        : `${startTimes.length} ${startTimes.length === 1 ? "horário livre" : "horários livres"} neste dia.`;

  const onSubmit = handleSubmit(async (values) => {
    setSaveError(null);
    const chosen = services.find((s) => s.id === values.serviceId);
    if (values.status === "signal_pending" && values.signalInCents === 0) {
      setError("signalInCents", { message: "Informe o valor do sinal pendente." });
      return;
    }
    if (chosen && values.signalInCents > chosen.priceInCents) {
      setError("signalInCents", { message: "O sinal não pode ser maior que o valor do serviço." });
      return;
    }
    try {
      const created = await repositories.appointments.create(tenant.id, {
        clientId: values.clientId,
        serviceId: values.serviceId,
        professionalId: values.professionalId,
        startAt: zonedDateTimeToUtc(values.date, values.time, tz),
        status: values.status,
        signalInCents: values.signalInCents,
        notes: values.notes.trim() || undefined,
        source,
      });
      onCreated(created);
    } catch (error) {
      if (error instanceof AppointmentConflictError) {
        const first = error.conflicts[0];
        setSaveError({
          title: "Este horário já está ocupado. O agendamento não foi salvo.",
          detail: first
            ? `${first.clientName} está das ${formatTime(first.startAt, tz)} às ${formatTime(first.endAt, tz)} com ${first.professionalName}. Escolha outro horário ou outra profissional.`
            : undefined,
        });
        availability.reload();
        return;
      }
      setSaveError({ title: error instanceof Error ? error.message : "Não foi possível salvar o agendamento." });
    }
  });

  return (
    <form onSubmit={onSubmit} noValidate className="flex min-h-0 flex-1 flex-col">
      <DialogBody className="space-y-5">
        {saveError && (
          <FormAlert title={saveError.title}>{saveError.detail && <p>{saveError.detail}</p>}</FormAlert>
        )}

        <FormField
          label="Cliente"
          error={errors.clientId?.message}
          hint={
            <Link href="/clientes/novo" className="text-gold-ink underline-offset-4 hover:underline">
              Cadastrar nova cliente
            </Link>
          }
        >
          <NativeSelect {...register("clientId")} disabled={isSubmitting}>
            <option value="">Escolha a cliente</option>
            {clients.map((client) => (
              <option key={client.id} value={client.id}>
                {client.fullName}
              </option>
            ))}
          </NativeSelect>
        </FormField>

        <FormField label="Serviço" error={errors.serviceId?.message}>
          <NativeSelect {...register("serviceId")} disabled={isSubmitting}>
            <option value="">Escolha o serviço</option>
            {services.map((s) => (
              <option key={s.id} value={s.id}>
                {`${s.name} · ${formatDuration(s.durationMinutes)} · ${formatCents(s.priceInCents)}`}
              </option>
            ))}
          </NativeSelect>
        </FormField>

        <FormField label="Profissional" error={errors.professionalId?.message}>
          <NativeSelect {...register("professionalId")} disabled={isSubmitting}>
            <option value="">Escolha a profissional</option>
            {professionals.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </NativeSelect>
        </FormField>

        <div className="grid grid-cols-2 gap-3">
          <FormField label="Data" error={errors.date?.message}>
            <DateField {...register("date")} disabled={isSubmitting} />
          </FormField>
          <FormField label="Horário" error={errors.time?.message} hint={timeHint}>
            <NativeSelect {...register("time")} disabled={isSubmitting || !startTimes} className="tabular">
              <option value="">{timePlaceholder}</option>
              {(startTimes ?? []).map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </NativeSelect>
          </FormField>
        </div>

        <div aria-live="polite">
          {ready && service && availability.data && conflicts.length === 0 && (
            <div className="flex gap-3 rounded-xl border border-sage/30 bg-sage-soft/60 p-3.5 text-sm">
              <CalendarCheck2 aria-hidden className="mt-0.5 size-4 shrink-0 text-sage" />
              <p className="text-ink/85">
                <span className="font-semibold text-sage">Horário livre.</span> Termina às{" "}
                <span className="tabular font-semibold">{formatTime(availability.data.endAt, tz)}</span> (
                {formatDuration(service.durationMinutes)} + {service.preparationIntervalMinutes} min de preparo).
                Valor: <span className="tabular">{formatCents(service.priceInCents)}</span>.
              </p>
            </div>
          )}
          {ready && conflicts.length > 0 && (
            <FormAlert title="Conflito de horário">
              {conflicts.map((c) => (
                <p key={c.id}>
                  {`${c.clientName} — ${c.serviceName}, das ${formatTime(c.startAt, tz)} às ${formatTime(c.endAt, tz)} (inclui preparo).`}
                </p>
              ))}
            </FormAlert>
          )}
        </div>

        <div className="grid gap-5">
          <FormField label="Status inicial" error={errors.status?.message}>
            <NativeSelect {...register("status")} disabled={isSubmitting}>
              {INITIAL_STATUS_OPTIONS.map((status) => (
                <option key={status} value={status}>
                  {APPOINTMENT_STATUS_META[status].label}
                </option>
              ))}
            </NativeSelect>
          </FormField>
          <Controller
            control={control}
            name="signalInCents"
            render={({ field }) => (
              <FormField label="Sinal" optional error={errors.signalInCents?.message}>
                <MoneyInput
                  name={field.name}
                  value={field.value}
                  onChange={field.onChange}
                  onBlur={field.onBlur}
                  ref={field.ref}
                  disabled={isSubmitting}
                />
              </FormField>
            )}
          />
        </div>

        <FormField label="Como a cliente marcou">
          <NativeSelect value={source} onChange={(e) => setSource(e.target.value as AppointmentSource)} disabled={isSubmitting}>
            {APPOINTMENT_SOURCES.map((s) => (
              <option key={s} value={s}>
                {APPOINTMENT_SOURCE_LABEL[s]}
              </option>
            ))}
          </NativeSelect>
        </FormField>

        <FormField label="Observações" optional error={errors.notes?.message}>
          <Textarea {...register("notes")} disabled={isSubmitting} placeholder="Ex.: prefere fios mais curtos no canto interno." />
        </FormField>
      </DialogBody>

      <DialogFooter>
        <Button variant="secondary" onClick={onCancel} disabled={isSubmitting}>
          Cancelar
        </Button>
        <Button type="submit" disabled={isSubmitting || conflicts.length > 0}>
          {isSubmitting ? (
            <>
              <LoaderCircle aria-hidden className="animate-spin" />
              Salvando…
            </>
          ) : (
            "Salvar agendamento"
          )}
        </Button>
      </DialogFooter>
    </form>
  );
}
