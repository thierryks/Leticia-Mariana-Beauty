"use client";

import { CalendarX2, Moon, Plus } from "lucide-react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useMemo, useState } from "react";
import { PageHeader } from "@/components/shared/page-header";
import { EmptyState, ErrorState, LoadingState } from "@/components/shared/states";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { NativeSelect } from "@/components/ui/native-select";
import { AGENDA_STATUS_FILTERS, buildAgendaDay, type AgendaStatusFilter } from "@/features/appointments/agenda";
import { useTenant } from "@/features/tenant/session-context";
import { useAsyncData } from "@/hooks/use-async-data";
import { useNow } from "@/hooks/use-now";
import { dateKeyOf, minutesOfDay, shiftDateKey, todayKey, zonedDateTimeToUtc, type DateKey } from "@/lib/datetime";
import { repositories } from "@/repositories";
import type { Appointment } from "@/types/appointment";
import { AgendaTimeline } from "./agenda-timeline";
import { AppointmentDetailsDialog } from "./appointment-details";
import { DayNavigator } from "./day-navigator";
import { NewAppointmentDialog, type NewAppointmentDefaults } from "./new-appointment-dialog";

const DATE_PARAM = /^\d{4}-\d{2}-\d{2}$/;

export function AgendaView() {
  const tenant = useTenant();
  const tz = tenant.timezone;
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const now = useNow();
  const today = todayKey(tz, now);
  const initialDate = searchParams.get("data");
  const [date, setDate] = useState<DateKey>(initialDate && DATE_PARAM.test(initialDate) ? initialDate : today);
  const [statusFilter, setStatusFilter] = useState<AgendaStatusFilter>("all");
  const [professionalId, setProfessionalId] = useState<string>("");
  const [selected, setSelected] = useState<Appointment | null>(null);
  const [creating, setCreating] = useState<NewAppointmentDefaults | null>(null);

  const professionals = useAsyncData(`professionals:${tenant.id}`, () => repositories.professionals.list(tenant.id));
  // Profissional padrão: a primeira ativa (a dona do studio). "all" mostra todas.
  const effectiveProfessional = professionalId || professionals.data?.find((p) => p.active)?.id || "all";

  const day = useAsyncData(`agenda:${tenant.id}:${date}`, () =>
    repositories.appointments.listBetween(
      tenant.id,
      zonedDateTimeToUtc(date, "00:00", tz),
      zonedDateTimeToUtc(shiftDateKey(date, 1), "00:00", tz),
    ),
  );

  const agenda = useMemo(
    () =>
      day.data
        ? buildAgendaDay({
            appointments: day.data,
            dateKey: date,
            todayKey: today,
            timezone: tz,
            professionalId: effectiveProfessional,
            statusFilter,
            nowMinute: minutesOfDay(new Date(now).toISOString(), tz),
          })
        : null,
    [day.data, date, today, tz, effectiveProfessional, statusFilter, now],
  );

  const paramOpen = searchParams.get("novo") === "1";
  const dialogDefaults: NewAppointmentDefaults | null =
    creating ??
    (paramOpen
      ? {
          date,
          professionalId: effectiveProfessional === "all" ? undefined : effectiveProfessional,
          clientId: searchParams.get("cliente") ?? undefined,
        }
      : null);

  function closeCreate() {
    setCreating(null);
    if (paramOpen) router.replace(pathname);
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Agenda"
        description="Horários do dia em ordem, com os intervalos livres da profissional escolhida."
        actions={
          <Button
            onClick={() =>
              setCreating({ date, professionalId: effectiveProfessional === "all" ? undefined : effectiveProfessional })
            }
          >
            <Plus aria-hidden />
            Novo agendamento
          </Button>
        }
      />

      <div className="space-y-4 rounded-[var(--radius-card)] border border-line bg-surface p-4 sm:p-5">
        <DayNavigator value={date} today={today} onChange={setDate} />
        <div className="grid gap-3 border-t border-line pt-4 sm:grid-cols-2">
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="filtro-profissional">Profissional</Label>
            <NativeSelect
              id="filtro-profissional"
              value={effectiveProfessional}
              onChange={(e) => setProfessionalId(e.target.value)}
            >
              <option value="all">Todas as profissionais</option>
              {(professionals.data ?? []).map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </NativeSelect>
          </div>
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="filtro-status">Status</Label>
            <NativeSelect
              id="filtro-status"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as AgendaStatusFilter)}
            >
              {AGENDA_STATUS_FILTERS.map((f) => (
                <option key={f.value} value={f.value}>
                  {f.label}
                </option>
              ))}
            </NativeSelect>
          </div>
        </div>
      </div>

      {day.error ? (
        <ErrorState message="Não foi possível carregar a agenda deste dia." onRetry={day.reload} />
      ) : !agenda ? (
        <LoadingState rows={4} label="Carregando a agenda…" />
      ) : (
        <section aria-label="Agenda do dia" className="space-y-4">
          {agenda.closedDay && (
            <p className="flex items-center gap-2 rounded-xl bg-sand/70 px-4 py-3 text-sm text-ink/80">
              <Moon aria-hidden className="size-4 text-gold-ink" />
              O studio não atende neste dia da semana. Horários livres não são exibidos.
            </p>
          )}
          {!agenda.showsFreeSlots && !agenda.closedDay && effectiveProfessional === "all" && (
            <p className="text-sm text-muted">Escolha uma profissional para ver os horários livres.</p>
          )}
          {agenda.items.length === 0 ? (
            <EmptyState
              icon={CalendarX2}
              title={statusFilter === "all" ? "Nenhum horário neste dia" : "Nenhum horário com este filtro"}
              description={
                statusFilter === "all"
                  ? "Use o botão abaixo para marcar um atendimento."
                  : "Mude o filtro de status para ver os outros horários do dia."
              }
              action={
                statusFilter === "all" ? (
                  <Button onClick={() => setCreating({ date })}>
                    <Plus aria-hidden />
                    Novo agendamento
                  </Button>
                ) : (
                  <Button variant="secondary" onClick={() => setStatusFilter("all")}>
                    Ver todos os status
                  </Button>
                )
              }
            />
          ) : (
            <AgendaTimeline
              items={agenda.items}
              timezone={tz}
              onOpen={setSelected}
              onBookFreeSlot={(time) =>
                setCreating({
                  date,
                  time,
                  professionalId: effectiveProfessional === "all" ? undefined : effectiveProfessional,
                })
              }
            />
          )}
        </section>
      )}

      {/* Ação principal fixa no celular */}
      <Button
        size="lg"
        className="fixed right-4 bottom-[max(1rem,env(safe-area-inset-bottom))] z-30 shadow-[0_12px_30px_-10px_rgb(68_55_43/0.6)] md:hidden"
        onClick={() => setCreating({ date, professionalId: effectiveProfessional === "all" ? undefined : effectiveProfessional })}
      >
        <Plus aria-hidden />
        Novo agendamento
      </Button>

      <AppointmentDetailsDialog appointment={selected} onOpenChange={(open) => !open && setSelected(null)} />
      <NewAppointmentDialog
        open={dialogDefaults !== null}
        defaults={dialogDefaults ?? { date }}
        onOpenChange={(open) => !open && closeCreate()}
        onCreated={(appointment) => {
          closeCreate();
          setDate(dateKeyOf(appointment.startAt, tz));
          day.reload();
          setSelected(appointment);
        }}
      />
    </div>
  );
}
