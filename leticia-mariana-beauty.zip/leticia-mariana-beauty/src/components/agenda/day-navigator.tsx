"use client";

import { ChevronLeft, ChevronRight } from "lucide-react";
import { DateField } from "@/components/shared/date-field";
import { Button } from "@/components/ui/button";
import { formatDateKeyLong, shiftDateKey, type DateKey } from "@/lib/datetime";

export function DayNavigator({
  value,
  today,
  onChange,
}: {
  value: DateKey;
  today: DateKey;
  onChange: (key: DateKey) => void;
}) {
  return (
    <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
      <div className="flex items-start justify-between gap-3">
        <p aria-live="polite" className="brand-title text-lg text-brown first-letter:uppercase">
          {formatDateKeyLong(value)}
        </p>
        <Button
          variant="secondary"
          size="sm"
          className="md:hidden"
          onClick={() => onChange(today)}
          disabled={value === today}
        >
          Hoje
        </Button>
      </div>
      <div className="flex items-center gap-2">
        <Button variant="secondary" size="icon" aria-label="Dia anterior" onClick={() => onChange(shiftDateKey(value, -1))}>
          <ChevronLeft className="size-5" />
        </Button>
        <div className="min-w-0 flex-1 md:w-44 md:flex-none">
          <DateField
            aria-label="Escolher data"
            value={value}
            onChange={(event) => event.target.value && onChange(event.target.value)}
          />
        </div>
        <Button variant="secondary" size="icon" aria-label="Próximo dia" onClick={() => onChange(shiftDateKey(value, 1))}>
          <ChevronRight className="size-5" />
        </Button>
        <Button
          variant="secondary"
          className="hidden md:inline-flex"
          onClick={() => onChange(today)}
          disabled={value === today}
        >
          Hoje
        </Button>
      </div>
    </div>
  );
}
