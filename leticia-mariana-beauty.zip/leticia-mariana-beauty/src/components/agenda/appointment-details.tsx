"use client";

import { CalendarDays, Clock, MessageCircle, User } from "lucide-react";
import Link from "next/link";
import type { ReactNode } from "react";
import { ResponsiveDialog } from "@/components/shared/responsive-dialog";
import { StatusBadge } from "@/components/shared/status-badge";
import { buttonVariants } from "@/components/ui/button";
import { useTenant } from "@/features/tenant/session-context";
import { APPOINTMENT_SOURCE_LABEL, APPOINTMENT_STATUS_META } from "@/lib/constants/labels";
import { dateKeyOf, formatDateKeyLong, formatTime } from "@/lib/datetime";
import { formatCents } from "@/lib/formatters/currency";
import type { Appointment } from "@/types/appointment";
import { SignalTag } from "./signal-tag";

function Row({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-4 py-3">
      <dt className="text-sm text-muted">{label}</dt>
      <dd className="text-right text-sm font-medium text-ink">{children}</dd>
    </div>
  );
}

export function AppointmentDetailsDialog({
  appointment,
  onOpenChange,
}: {
  appointment: Appointment | null;
  onOpenChange: (open: boolean) => void;
}) {
  const tenant = useTenant();
  const tz = tenant.timezone;

  return (
    <ResponsiveDialog
      open={appointment !== null}
      onOpenChange={onOpenChange}
      title={appointment ? appointment.serviceName : "Agendamento"}
      description={appointment ? APPOINTMENT_STATUS_META[appointment.status].description : undefined}
      desktop="drawer"
      footer={
        appointment && (
          <Link href={`/clientes/${appointment.clientId}`} className={buttonVariants({ variant: "secondary" })}>
            <User aria-hidden />
            Ver perfil da cliente
          </Link>
        )
      }
    >
      {appointment && (
        <div className="space-y-5">
          <div className="rounded-[var(--radius-card)] bg-sand/60 p-4">
            <StatusBadge status={appointment.status} />
            <p className="mt-3 text-lg font-semibold text-brown">{appointment.clientName}</p>
            <p className="mt-1 flex items-center gap-2 text-sm text-ink/80">
              <CalendarDays aria-hidden className="size-4 text-gold-ink" />
              {formatDateKeyLong(dateKeyOf(appointment.startAt, tz))}
            </p>
            <p className="mt-1 flex items-center gap-2 text-sm text-ink/80 tabular">
              <Clock aria-hidden className="size-4 text-gold-ink" />
              {formatTime(appointment.startAt, tz)} às {formatTime(appointment.endAt, tz)}
              <span className="text-muted">(inclui preparo)</span>
            </p>
          </div>

          <dl className="divide-y divide-line">
            <Row label="Profissional">{appointment.professionalName}</Row>
            <Row label="Valor">
              <span className="tabular">{formatCents(appointment.priceInCents)}</span>
            </Row>
            <Row label="Sinal">
              <SignalTag appointment={appointment} />
            </Row>
            <Row label="Origem">{APPOINTMENT_SOURCE_LABEL[appointment.source]}</Row>
          </dl>

          {appointment.notes && (
            <div>
              <p className="mb-1.5 flex items-center gap-2 text-sm text-muted">
                <MessageCircle aria-hidden className="size-4" />
                Observações
              </p>
              <p className="rounded-xl border border-line bg-surface p-3.5 text-sm">{appointment.notes}</p>
            </div>
          )}

          <p className="text-xs text-muted">
            Confirmar, iniciar e concluir atendimentos chega na próxima etapa, junto com o histórico de alterações.
          </p>
        </div>
      )}
    </ResponsiveDialog>
  );
}
