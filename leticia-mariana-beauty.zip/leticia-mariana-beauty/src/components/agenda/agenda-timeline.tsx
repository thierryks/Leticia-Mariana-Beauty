"use client";

import { CalendarPlus } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { TimelineItem } from "@/features/appointments/agenda";
import { formatDuration, minutesToTime } from "@/lib/datetime";
import type { Appointment } from "@/types/appointment";
import { AppointmentCard } from "./appointment-card";

/**
 * Lista cronológica do dia. O filete dourado vertical liga os horários
 * como um fio — elemento de assinatura da agenda.
 */
export function AgendaTimeline({
  items,
  timezone,
  onOpen,
  onBookFreeSlot,
}: {
  items: TimelineItem[];
  timezone: string;
  onOpen: (appointment: Appointment) => void;
  onBookFreeSlot: (time: string) => void;
}) {
  return (
    <ol className="relative" aria-label="Horários do dia">
      <span aria-hidden className="absolute top-3 bottom-3 left-[3.6rem] w-px bg-linear-to-b from-gold/70 via-gold/40 to-gold/10 sm:left-[4.72rem]" />
      {items.map((item) => (
        <li key={item.key} className="relative grid grid-cols-[3.1rem_1fr] gap-x-4 pb-4 last:pb-0 sm:grid-cols-[4.1rem_1fr] sm:gap-x-5">
          <p className="tabular pt-4 text-right text-sm font-semibold text-brown sm:pt-5">{minutesToTime(item.startMinute)}</p>
          <span
            aria-hidden
            className={
              item.kind === "appointment"
                ? "absolute top-[1.35rem] left-[3.29rem] size-2.5 rounded-full bg-gold ring-4 ring-background sm:top-[1.6rem] sm:left-[4.41rem]"
                : "absolute top-[1.35rem] left-[3.29rem] size-2.5 rounded-full border border-gold bg-background ring-4 ring-background sm:top-[1.6rem] sm:left-[4.41rem]"
            }
          />
          <div className="min-w-0 pl-2">
            {item.kind === "appointment" ? (
              <AppointmentCard appointment={item.appointment} timezone={timezone} onOpen={() => onOpen(item.appointment)} />
            ) : (
              <div className="flex flex-wrap items-center justify-between gap-3 rounded-[var(--radius-card)] border border-dashed border-sage/40 bg-sage-soft/40 px-4 py-3">
                <p className="text-sm text-ink/80">
                  <span className="font-semibold text-sage">Horário livre</span>
                  <span className="tabular"> · {item.label}</span>
                  <span className="text-muted"> ({formatDuration(item.range.end - item.range.start)})</span>
                </p>
                <Button size="sm" variant="secondary" onClick={() => onBookFreeSlot(minutesToTime(item.range.start))}>
                  <CalendarPlus aria-hidden />
                  Agendar
                </Button>
              </div>
            )}
          </div>
        </li>
      ))}
    </ol>
  );
}
