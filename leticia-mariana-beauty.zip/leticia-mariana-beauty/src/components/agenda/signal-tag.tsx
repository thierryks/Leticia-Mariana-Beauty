import { CircleCheck, Clock } from "lucide-react";
import { signalState } from "@/features/appointments/rules";
import { formatCents } from "@/lib/formatters/currency";
import type { Appointment } from "@/types/appointment";

/** "Sinal pago" / "Sinal pendente" com valor, ou nada quando não há sinal. */
export function SignalTag({ appointment }: { appointment: Pick<Appointment, "status" | "signalInCents"> }) {
  const state = signalState(appointment);
  if (state === "none") return <span className="text-xs text-muted">Sem sinal</span>;
  const paid = state === "paid";
  const Icon = paid ? CircleCheck : Clock;
  return (
    <span className={`inline-flex items-center gap-1 text-xs font-medium ${paid ? "text-sage" : "text-amber"}`}>
      <Icon aria-hidden className="size-3.5" />
      {paid ? "Sinal pago" : "Sinal pendente"} · <span className="tabular">{formatCents(appointment.signalInCents)}</span>
    </span>
  );
}
