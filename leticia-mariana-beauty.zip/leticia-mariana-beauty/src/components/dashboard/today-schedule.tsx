"use client";

import { CalendarHeart, ChevronRight } from "lucide-react";
import Link from "next/link";
import { EmptyState, LoadingState } from "@/components/shared/states";
import { StatusBadge } from "@/components/shared/status-badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { buttonVariants } from "@/components/ui/button";
import { isBlockingStatus } from "@/features/appointments/rules";
import { formatDuration, formatTime } from "@/lib/datetime";
import { formatCents } from "@/lib/formatters/currency";
import { cn } from "@/lib/utils";
import type { Appointment } from "@/types/appointment";

const MINUTE = 60_000;

export function TodaySchedule({
  appointments,
  loading,
  timezone,
  onView,
}: {
  appointments: Appointment[];
  loading: boolean;
  timezone: string;
  onView: (appointment: Appointment) => void;
}) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Agenda de hoje</CardTitle>
        <Link href="/agenda" className={cn(buttonVariants({ variant: "link" }), "text-sm")}>
          Abrir agenda
        </Link>
      </CardHeader>
      <CardContent>
        {loading ? (
          <LoadingState rows={3} />
        ) : appointments.length === 0 ? (
          <EmptyState
            icon={CalendarHeart}
            title="Nenhum horário hoje"
            description="Aproveite para organizar a semana ou abrir novos horários."
            action={
              <Link href="/agenda?novo=1" className={buttonVariants({ size: "sm" })}>
                Novo agendamento
              </Link>
            }
          />
        ) : (
          <ol className="divide-y divide-line">
            {appointments.map((appointment) => {
              const duration = Math.round(
                (new Date(appointment.endAt).getTime() - new Date(appointment.startAt).getTime()) / MINUTE,
              );
              const inactive = !isBlockingStatus(appointment.status);
              return (
                <li key={appointment.id} className="flex items-start gap-3 py-3.5 first:pt-0 last:pb-0 sm:items-center sm:gap-4">
                  <p className={cn("tabular w-12 shrink-0 text-lg font-semibold text-brown sm:w-14", inactive && "text-muted line-through decoration-1")}>
                    {formatTime(appointment.startAt, timezone)}
                  </p>
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-medium text-ink">{appointment.clientName}</p>
                    <p className="truncate text-sm text-muted">
                      {appointment.serviceName} · {formatDuration(duration)}
                      <span className="tabular sm:hidden"> · {formatCents(appointment.priceInCents)}</span>
                    </p>
                    <StatusBadge status={appointment.status} className="mt-2 sm:hidden" />
                  </div>
                  <p className="tabular hidden text-sm text-ink sm:block">{formatCents(appointment.priceInCents)}</p>
                  <StatusBadge status={appointment.status} className="hidden sm:inline-flex" />
                  <button
                    type="button"
                    onClick={() => onView(appointment)}
                    aria-label={`Ver agendamento de ${appointment.clientName} às ${formatTime(appointment.startAt, timezone)}`}
                    className="inline-flex size-10 items-center justify-center rounded-full text-muted hover:bg-sand hover:text-brown"
                  >
                    <ChevronRight aria-hidden className="size-5" />
                  </button>
                </li>
              );
            })}
          </ol>
        )}
      </CardContent>
    </Card>
  );
}
