"use client";

import { BellOff, CircleDollarSign, MessageCircleWarning, PackageOpen, type LucideIcon } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { formatDateKeyShort, dateKeyOf, formatTime } from "@/lib/datetime";
import { formatCents } from "@/lib/formatters/currency";
import type { OperationalAlert } from "@/repositories/support-repositories";
import type { Appointment } from "@/types/appointment";

interface AlertItem {
  id: string;
  icon: LucideIcon;
  title: string;
  description: string;
  example?: boolean;
  onClick?: () => void;
}

export function AlertsPanel({
  pendingSignals,
  awaitingConfirmation,
  operational,
  timezone,
  loading,
  onView,
}: {
  pendingSignals: Appointment[];
  awaitingConfirmation: Appointment[];
  operational: OperationalAlert[];
  timezone: string;
  loading: boolean;
  onView: (appointment: Appointment) => void;
}) {
  const when = (a: Appointment) => `${formatDateKeyShort(dateKeyOf(a.startAt, timezone))}, ${formatTime(a.startAt, timezone)}`;

  const items: AlertItem[] = [
    ...pendingSignals.map((a) => ({
      id: `signal-${a.id}`,
      icon: CircleDollarSign,
      title: `Sinal pendente · ${a.clientName}`,
      description: `${formatCents(a.signalInCents)} para ${a.serviceName} em ${when(a)}.`,
      onClick: () => onView(a),
    })),
    ...awaitingConfirmation.map((a) => ({
      id: `confirm-${a.id}`,
      icon: MessageCircleWarning,
      title: `Aguardando confirmação · ${a.clientName}`,
      description: `${a.serviceName} em ${when(a)}.`,
      onClick: () => onView(a),
    })),
    ...operational.map((alert) => ({
      id: alert.id,
      icon: alert.kind === "stock_low" ? PackageOpen : BellOff,
      title: alert.title,
      description: alert.description,
      example: alert.isExample,
    })),
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle>Alertas</CardTitle>
        {!loading && <span className="tabular text-sm text-muted">{items.length}</span>}
      </CardHeader>
      <CardContent className="pt-3">
        {loading ? (
          <div className="space-y-3">
            <Skeleton className="h-14" />
            <Skeleton className="h-14" />
          </div>
        ) : items.length === 0 ? (
          <p className="text-sm text-muted">Tudo em dia por aqui.</p>
        ) : (
          <ul className="space-y-1">
            {items.map((item) => {
              const Icon = item.icon;
              const body = (
                <>
                  <Icon aria-hidden className="mt-0.5 size-4.5 shrink-0 text-gold-ink" />
                  <span className="min-w-0 flex-1">
                    <span className="block text-sm font-medium text-ink">
                      {item.title}
                      {item.example && (
                        <span className="ml-2 rounded-full bg-sand px-2 py-0.5 align-middle text-[0.68rem] font-normal text-muted">
                          exemplo
                        </span>
                      )}
                    </span>
                    <span className="mt-0.5 block text-[0.8125rem] text-muted">{item.description}</span>
                  </span>
                </>
              );
              return (
                <li key={item.id}>
                  {item.onClick ? (
                    <button
                      type="button"
                      onClick={item.onClick}
                      className="-mx-2 flex w-[calc(100%+1rem)] gap-3 rounded-xl px-2 py-2.5 text-left hover:bg-sand/50"
                    >
                      {body}
                    </button>
                  ) : (
                    <div className="-mx-2 flex gap-3 px-2 py-2.5">{body}</div>
                  )}
                </li>
              );
            })}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}
