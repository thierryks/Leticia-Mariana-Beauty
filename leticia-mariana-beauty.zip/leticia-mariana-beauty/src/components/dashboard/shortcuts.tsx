import { CalendarPlus, Lock, Sparkles, UserPlus, type LucideIcon } from "lucide-react";
import Link from "next/link";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface Shortcut {
  label: string;
  href?: string;
  icon: LucideIcon;
  note?: string;
}

const SHORTCUTS: Shortcut[] = [
  { label: "Novo agendamento", href: "/agenda?novo=1", icon: CalendarPlus },
  { label: "Nova cliente", href: "/clientes/novo", icon: UserPlus },
  { label: "Novo serviço", href: "/servicos?novo=1", icon: Sparkles },
  { label: "Bloquear horário", icon: Lock, note: "Em breve" },
];

const tile =
  "flex min-h-24 flex-col justify-between gap-3 rounded-xl border border-line bg-background p-3.5 text-sm font-medium text-brown";

export function Shortcuts() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Atalhos</CardTitle>
      </CardHeader>
      <CardContent className="grid grid-cols-2 gap-2.5 pt-3">
        {SHORTCUTS.map(({ label, href, icon: Icon, note }) =>
          href ? (
            <Link key={label} href={href} className={`${tile} transition-colors hover:border-gold/60 hover:bg-surface`}>
              <Icon aria-hidden className="size-5 text-gold-ink" />
              {label}
            </Link>
          ) : (
            <div key={label} aria-disabled="true" className={`${tile} text-muted`}>
              <Icon aria-hidden className="size-5" />
              <span>
                {label}
                <span className="mt-0.5 block text-xs font-normal">{note}</span>
              </span>
            </div>
          ),
        )}
      </CardContent>
    </Card>
  );
}
