"use client";

import { CalendarCheck, CircleDollarSign, Hourglass, Plus, RefreshCcw, Wallet } from "lucide-react";
import Link from "next/link";
import { useMemo, useState } from "react";
import { AppointmentDetailsDialog } from "@/components/agenda/appointment-details";
import { AlertsPanel } from "@/components/dashboard/alerts-panel";
import { Shortcuts } from "@/components/dashboard/shortcuts";
import { TodaySchedule } from "@/components/dashboard/today-schedule";
import { PageHeader } from "@/components/shared/page-header";
import { StatCard } from "@/components/shared/stat-card";
import { ErrorState } from "@/components/shared/states";
import { buttonVariants } from "@/components/ui/button";
import { buildDashboardSummary } from "@/features/dashboard/summary";
import { useSession } from "@/features/tenant/session-context";
import { useAsyncData } from "@/hooks/use-async-data";
import { useNow } from "@/hooks/use-now";
import { formatDateKeyLong, greetingFor, todayKey } from "@/lib/datetime";
import { formatCents } from "@/lib/formatters/currency";
import { repositories } from "@/repositories";
import type { Appointment } from "@/types/appointment";

export function DashboardView() {
  const { tenant, user } = useSession();
  const tz = tenant.timezone;
  const now = useNow();
  const today = todayKey(tz, now);
  const [selected, setSelected] = useState<Appointment | null>(null);

  const query = useAsyncData(`dashboard:${tenant.id}`, async () => {
    const [appointments, clients, services, alerts] = await Promise.all([
      repositories.appointments.listAll(tenant.id),
      repositories.clients.list(tenant.id),
      repositories.services.list(tenant.id),
      repositories.alerts.listOperational(tenant.id),
    ]);
    return { appointments, clients, services, alerts };
  });

  const summary = useMemo(
    () => (query.data ? buildDashboardSummary(query.data.appointments, query.data.clients, query.data.services, today, tz, now) : null),
    [query.data, today, tz, now],
  );

  const loading = query.loading;
  const firstName = user.userName.split(" ")[0];

  return (
    <div className="space-y-8">
      <PageHeader
        title={`${greetingFor(tz, now)}, ${firstName}`}
        description={<span className="first-letter:uppercase">{formatDateKeyLong(today)}</span>}
        actions={
          <Link href="/agenda?novo=1" className={buttonVariants()}>
            <Plus aria-hidden />
            Novo agendamento
          </Link>
        }
      />

      {query.error && <ErrorState message="Não foi possível carregar o resumo do dia." onRetry={query.reload} />}

      <section aria-label="Indicadores do dia" className="grid grid-cols-2 gap-3 lg:grid-cols-5 [&>*:last-child]:col-span-2 lg:[&>*:last-child]:col-span-1">
        <StatCard
          label="Atendimentos hoje"
          icon={CalendarCheck}
          loading={loading}
          value={summary?.todayActiveCount ?? 0}
          hint="Sem contar cancelados"
        />
        <StatCard
          label="Aguardando confirmação"
          icon={Hourglass}
          loading={loading}
          value={summary?.awaitingConfirmation.length ?? 0}
          attention={(summary?.awaitingConfirmation.length ?? 0) > 0}
          hint="Hoje e próximos dias"
        />
        <StatCard
          label="Receita prevista hoje"
          icon={Wallet}
          loading={loading}
          value={formatCents(summary?.expectedRevenueTodayInCents ?? 0)}
          hint="Valor dos atendimentos ativos"
        />
        <StatCard
          label="Clientes para manutenção"
          icon={RefreshCcw}
          loading={loading}
          value={summary?.maintenanceDueCount ?? 0}
          hint={
            <Link href="/clientes?filtro=manutencao" className="text-gold-ink underline-offset-4 hover:underline">
              Ver quem está no prazo
            </Link>
          }
        />
        <StatCard
          label="Pagamentos pendentes"
          icon={CircleDollarSign}
          loading={loading}
          value={summary?.pendingSignals.length ?? 0}
          attention={(summary?.pendingSignals.length ?? 0) > 0}
          hint={`Sinais em aberto: ${formatCents(summary?.pendingSignalsInCents ?? 0)}`}
        />
      </section>

      <div className="grid gap-6 lg:grid-cols-[minmax(0,1.7fr)_minmax(0,1fr)]">
        <TodaySchedule appointments={summary?.today ?? []} loading={loading} timezone={tz} onView={setSelected} />
        <div className="space-y-6">
          <AlertsPanel
            loading={loading}
            timezone={tz}
            pendingSignals={summary?.pendingSignals ?? []}
            awaitingConfirmation={summary?.awaitingConfirmation ?? []}
            operational={query.data?.alerts ?? []}
            onView={setSelected}
          />
          <Shortcuts />
        </div>
      </div>

      <AppointmentDetailsDialog appointment={selected} onOpenChange={(open) => !open && setSelected(null)} />
    </div>
  );
}
