"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { LoaderCircle } from "lucide-react";
import { useState } from "react";
import { Controller, useForm, useWatch } from "react-hook-form";
import { FormField } from "@/components/shared/form-field";
import { MoneyInput } from "@/components/shared/money-input";
import { FormAlert } from "@/components/shared/states";
import { Button } from "@/components/ui/button";
import { DialogBody, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { NativeSelect } from "@/components/ui/native-select";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { useTenant } from "@/features/tenant/session-context";
import { SERVICE_CATEGORY_LABEL } from "@/lib/constants/labels";
import { formatDuration } from "@/lib/datetime";
import { serviceFormSchema, type ServiceFormValues } from "@/lib/validators/service";
import { repositories } from "@/repositories";
import { SERVICE_CATEGORIES, type Service } from "@/types/service";

const EMPTY: ServiceFormValues = {
  name: "",
  category: "extensao",
  durationMinutes: 120,
  preparationIntervalMinutes: 15,
  priceInCents: 0,
  description: "",
  active: true,
};

export function ServiceForm({
  service,
  onSaved,
  onCancel,
}: {
  service?: Service;
  onSaved: (service: Service) => void;
  onCancel: () => void;
}) {
  const tenant = useTenant();
  const [saveError, setSaveError] = useState<string | null>(null);

  const {
    control,
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<ServiceFormValues>({
    resolver: zodResolver(serviceFormSchema),
    defaultValues: service
      ? {
          name: service.name,
          category: service.category,
          durationMinutes: service.durationMinutes,
          preparationIntervalMinutes: service.preparationIntervalMinutes,
          priceInCents: service.priceInCents,
          description: service.description ?? "",
          active: service.active,
        }
      : EMPTY,
  });

  const [duration, prep] = useWatch({ control, name: ["durationMinutes", "preparationIntervalMinutes"] });
  const blocked = Number.isFinite(duration) && Number.isFinite(prep) ? duration + prep : null;

  const onSubmit = handleSubmit(async (values) => {
    setSaveError(null);
    const input = { ...values, description: values.description.trim() || undefined };
    try {
      const saved = service
        ? await repositories.services.update(tenant.id, service.id, input)
        : await repositories.services.create(tenant.id, input);
      onSaved(saved);
    } catch {
      setSaveError("Não foi possível salvar o serviço. Confira os dados e tente de novo.");
    }
  });

  return (
    <form onSubmit={onSubmit} noValidate className="flex min-h-0 flex-1 flex-col">
      <DialogBody className="space-y-5">
        {saveError && <FormAlert title={saveError} />}
        <FormField label="Nome do serviço" error={errors.name?.message}>
          <Input autoComplete="off" {...register("name")} />
        </FormField>
        <FormField label="Categoria" error={errors.category?.message}>
          <NativeSelect {...register("category")}>
            {SERVICE_CATEGORIES.map((c) => (
              <option key={c} value={c}>
                {SERVICE_CATEGORY_LABEL[c]}
              </option>
            ))}
          </NativeSelect>
        </FormField>
        <div className="grid grid-cols-2 gap-3">
          <FormField label="Duração (min)" error={errors.durationMinutes?.message}>
            <Input type="number" inputMode="numeric" min={5} step={5} className="tabular" {...register("durationMinutes", { valueAsNumber: true })} />
          </FormField>
          <FormField label="Preparo (min)" error={errors.preparationIntervalMinutes?.message}>
            <Input
              type="number"
              inputMode="numeric"
              min={0}
              step={5}
              className="tabular"
              {...register("preparationIntervalMinutes", { valueAsNumber: true })}
            />
          </FormField>
        </div>
        {blocked !== null && blocked > 0 && (
          <p className="-mt-2 text-[0.8125rem] text-muted">
            Ocupa <span className="tabular font-medium text-ink">{formatDuration(blocked)}</span> da agenda, contando o
            preparo.
          </p>
        )}
        <Controller
          control={control}
          name="priceInCents"
          render={({ field }) => (
            <FormField label="Preço" error={errors.priceInCents?.message}>
              <MoneyInput name={field.name} value={field.value} onChange={field.onChange} onBlur={field.onBlur} ref={field.ref} />
            </FormField>
          )}
        />
        <FormField label="Descrição" optional error={errors.description?.message}>
          <Textarea {...register("description")} placeholder="Como o serviço aparece para a cliente." />
        </FormField>
        <Controller
          control={control}
          name="active"
          render={({ field }) => (
            <div className="flex items-center justify-between gap-4 rounded-xl border border-line bg-surface px-4 py-3">
              <div>
                <label htmlFor="servico-ativo" className="text-sm font-medium text-ink">
                  Serviço ativo
                </label>
                <p className="text-[0.8125rem] text-muted">Serviços inativos não aparecem em novos agendamentos.</p>
              </div>
              <Switch id="servico-ativo" checked={field.value} onCheckedChange={field.onChange} />
            </div>
          )}
        />
      </DialogBody>
      <DialogFooter>
        <Button variant="secondary" onClick={onCancel} disabled={isSubmitting}>
          Cancelar
        </Button>
        <Button type="submit" disabled={isSubmitting}>
          {isSubmitting ? (
            <>
              <LoaderCircle aria-hidden className="animate-spin" />
              Salvando…
            </>
          ) : service ? (
            "Salvar alterações"
          ) : (
            "Cadastrar serviço"
          )}
        </Button>
      </DialogFooter>
    </form>
  );
}
