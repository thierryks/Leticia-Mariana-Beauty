"use client";

import { Clock, Pencil, Plus, Sparkles } from "lucide-react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useMemo, useState } from "react";
import { FilterChips, SearchField, type FilterOption } from "@/components/shared/filters";
import { PageHeader } from "@/components/shared/page-header";
import { ResponsiveDialog } from "@/components/shared/responsive-dialog";
import { EmptyState, ErrorState, LoadingState } from "@/components/shared/states";
import { ToneBadge } from "@/components/shared/status-badge";
import { Button } from "@/components/ui/button";
import { useTenant } from "@/features/tenant/session-context";
import { useAsyncData } from "@/hooks/use-async-data";
import { SERVICE_CATEGORY_LABEL } from "@/lib/constants/labels";
import { formatDuration } from "@/lib/datetime";
import { formatCents } from "@/lib/formatters/currency";
import { cn, normalizeSearchText } from "@/lib/utils";
import { repositories } from "@/repositories";
import type { Service } from "@/types/service";
import { ServiceForm } from "./service-form";

type ActiveFilter = "active" | "inactive" | "all";

export function ServicesView() {
  const tenant = useTenant();
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<ActiveFilter>("active");
  const [editing, setEditing] = useState<Service | "new" | null>(null);

  const query = useAsyncData(`services:${tenant.id}`, () => repositories.services.list(tenant.id));

  const paramOpen = searchParams.get("novo") === "1";
  const dialogTarget = editing ?? (paramOpen ? "new" : null);

  function closeDialog() {
    setEditing(null);
    if (paramOpen) router.replace(pathname);
  }

  const searched = useMemo(() => {
    const term = normalizeSearchText(search);
    return (query.data ?? []).filter(
      (s) => !term || normalizeSearchText(s.name).includes(term) || normalizeSearchText(SERVICE_CATEGORY_LABEL[s.category]).includes(term),
    );
  }, [query.data, search]);

  const byFilter = (s: Service, f: ActiveFilter) => f === "all" || (f === "active" ? s.active : !s.active);
  const visible = searched.filter((s) => byFilter(s, filter));
  const filterOptions: FilterOption<ActiveFilter>[] = (
    [
      ["active", "Ativos"],
      ["inactive", "Inativos"],
      ["all", "Todos"],
    ] as const
  ).map(([value, label]) => ({
    value,
    label,
    count: query.data ? searched.filter((s) => byFilter(s, value)).length : undefined,
  }));

  return (
    <div className="space-y-6">
      <PageHeader
        title="Serviços"
        description="Preço, duração e tempo de preparo de cada técnica. O preparo também bloqueia a agenda."
        actions={
          <Button onClick={() => setEditing("new")}>
            <Plus aria-hidden />
            Novo serviço
          </Button>
        }
      />

      <div className="space-y-3">
        <SearchField
          label="Buscar serviço"
          placeholder="Buscar por nome ou categoria"
          value={search}
          onValueChange={setSearch}
          className="max-w-md"
        />
        <FilterChips label="Filtrar serviços" options={filterOptions} value={filter} onChange={setFilter} />
      </div>

      {query.error ? (
        <ErrorState message="Não foi possível carregar os serviços." onRetry={query.reload} />
      ) : query.loading ? (
        <LoadingState rows={4} label="Carregando serviços…" />
      ) : visible.length === 0 ? (
        <EmptyState
          icon={Sparkles}
          title={search ? "Nenhum serviço encontrado" : "Nenhum serviço neste filtro"}
          description={search ? "Tente outro nome ou categoria." : "Cadastre um serviço para usar na agenda."}
          action={
            <Button variant="secondary" onClick={() => setEditing("new")}>
              <Plus aria-hidden />
              Novo serviço
            </Button>
          }
        />
      ) : (
        <ul className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {visible.map((service) => (
            <li key={service.id}>
              <article
                className={cn(
                  "flex h-full flex-col rounded-[var(--radius-card)] border bg-surface p-5",
                  service.active ? "border-line shadow-[var(--shadow-soft)]" : "border-dashed border-sand-strong",
                )}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="text-xs text-gold-ink">{SERVICE_CATEGORY_LABEL[service.category]}</p>
                    <h2 className="mt-0.5 text-base font-semibold text-ink">{service.name}</h2>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon-sm"
                    aria-label={`Editar ${service.name}`}
                    onClick={() => setEditing(service)}
                  >
                    <Pencil />
                  </Button>
                </div>
                {service.description && <p className="mt-2 text-sm text-muted">{service.description}</p>}
                <div className="mt-auto flex flex-wrap items-end justify-between gap-3 pt-5">
                  <div>
                    <p className="tabular text-xl font-semibold text-brown">{formatCents(service.priceInCents)}</p>
                    <p className="mt-1 flex items-center gap-1.5 text-xs text-muted">
                      <Clock aria-hidden className="size-3.5" />
                      <span className="tabular">
                        {formatDuration(service.durationMinutes)} + {service.preparationIntervalMinutes} min de preparo
                      </span>
                    </p>
                  </div>
                  {service.active ? <ToneBadge tone="sage">Ativo</ToneBadge> : <ToneBadge tone="slate">Inativo</ToneBadge>}
                </div>
              </article>
            </li>
          ))}
        </ul>
      )}

      <p className="text-xs text-muted">Valores de demonstração. Ajuste para a tabela real do studio.</p>

      <ResponsiveDialog
        open={dialogTarget !== null}
        onOpenChange={(open) => !open && closeDialog()}
        title={dialogTarget && dialogTarget !== "new" ? "Editar serviço" : "Novo serviço"}
        desktop="drawer"
        rawContent
      >
        {dialogTarget !== null && (
          <ServiceForm
            key={dialogTarget === "new" ? "new" : dialogTarget.id}
            service={dialogTarget === "new" ? undefined : dialogTarget}
            onCancel={closeDialog}
            onSaved={() => {
              closeDialog();
              query.reload();
            }}
          />
        )}
      </ResponsiveDialog>
    </div>
  );
}
