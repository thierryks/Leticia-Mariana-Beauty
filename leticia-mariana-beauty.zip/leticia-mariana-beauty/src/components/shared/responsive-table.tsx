"use client";

import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export interface Column<T> {
  key: string;
  header: string;
  cell: (row: T) => ReactNode;
  className?: string;
  /** Esconde a coluna até a largura indicada (as informações seguem no cartão mobile). */
  hideBelow?: "lg" | "xl";
}

interface ResponsiveTableProps<T> {
  caption: string;
  columns: Column<T>[];
  rows: T[];
  rowKey: (row: T) => string;
  /** Cartão usado abaixo de 768 px. */
  renderCard: (row: T) => ReactNode;
}

/** Tabela no desktop, lista de cartões no celular. */
export function ResponsiveTable<T>({ caption, columns, rows, rowKey, renderCard }: ResponsiveTableProps<T>) {
  return (
    <>
      <ul className="space-y-3 md:hidden" aria-label={caption}>
        {rows.map((row) => (
          <li key={rowKey(row)}>{renderCard(row)}</li>
        ))}
      </ul>

      <div className="hidden overflow-hidden rounded-[var(--radius-card)] border border-line bg-surface md:block">
        <table className="w-full text-left text-sm">
          <caption className="sr-only">{caption}</caption>
          <thead className="bg-sand/45 text-xs text-muted">
            <tr>
              {columns.map((column) => (
                <th
                  key={column.key}
                  scope="col"
                  className={cn(
                    "px-4 py-3 font-medium",
                    column.hideBelow === "lg" && "hidden lg:table-cell",
                    column.hideBelow === "xl" && "hidden xl:table-cell",
                    column.className,
                  )}
                >
                  {column.header}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {rows.map((row) => (
              <tr key={rowKey(row)} className="transition-colors hover:bg-background">
                {columns.map((column) => (
                  <td
                    key={column.key}
                    className={cn(
                      "px-4 py-3.5 align-middle",
                      column.hideBelow === "lg" && "hidden lg:table-cell",
                      column.hideBelow === "xl" && "hidden xl:table-cell",
                      column.className,
                    )}
                  >
                    {column.cell(row)}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}

/** Paginação visual simples. */
export function Pagination({
  page,
  pageCount,
  total,
  onPageChange,
  itemLabel,
}: {
  page: number;
  pageCount: number;
  total: number;
  onPageChange: (page: number) => void;
  itemLabel: string;
}) {
  if (pageCount <= 1) {
    return <p className="text-sm text-muted">{`${total} ${itemLabel}`}</p>;
  }
  return (
    <nav aria-label="Paginação" className="flex flex-wrap items-center justify-between gap-3">
      <p className="text-sm text-muted">{`${total} ${itemLabel} · página ${page} de ${pageCount}`}</p>
      <div className="flex gap-1.5">
        <button
          type="button"
          disabled={page <= 1}
          onClick={() => onPageChange(page - 1)}
          className="h-9 rounded-full border border-sand-strong px-3.5 text-sm text-brown hover:bg-sand/60 disabled:opacity-40"
        >
          Anterior
        </button>
        {Array.from({ length: pageCount }, (_, i) => i + 1).map((n) => (
          <button
            key={n}
            type="button"
            aria-current={n === page ? "page" : undefined}
            onClick={() => onPageChange(n)}
            className={cn(
              "tabular size-9 rounded-full text-sm",
              n === page ? "bg-brown text-background" : "text-brown hover:bg-sand/60",
            )}
          >
            {n}
          </button>
        ))}
        <button
          type="button"
          disabled={page >= pageCount}
          onClick={() => onPageChange(page + 1)}
          className="h-9 rounded-full border border-sand-strong px-3.5 text-sm text-brown hover:bg-sand/60 disabled:opacity-40"
        >
          Próxima
        </button>
      </div>
    </nav>
  );
}
