import { CircleAlert, type LucideIcon } from "lucide-react";
import type { ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";

export function EmptyState({
  icon: Icon,
  title,
  description,
  action,
  className,
}: {
  icon: LucideIcon;
  title: string;
  description?: ReactNode;
  action?: ReactNode;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "flex flex-col items-center rounded-[var(--radius-card)] border border-dashed border-sand-strong bg-surface/60 px-6 py-12 text-center",
        className,
      )}
    >
      <span className="mb-4 inline-flex size-12 items-center justify-center rounded-full bg-sand text-gold-ink">
        <Icon aria-hidden className="size-5" />
      </span>
      <h2 className="text-base font-semibold text-brown">{title}</h2>
      {description && <p className="mt-1.5 max-w-sm text-sm text-muted">{description}</p>}
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

export function LoadingState({ rows = 4, label = "Carregando…" }: { rows?: number; label?: string }) {
  return (
    <div role="status" aria-live="polite" className="space-y-3">
      <span className="sr-only">{label}</span>
      {Array.from({ length: rows }, (_, i) => (
        <div key={i} className="flex items-center gap-4 rounded-[var(--radius-card)] border border-line bg-surface p-4">
          <Skeleton className="h-10 w-14" />
          <div className="flex-1 space-y-2">
            <Skeleton className="h-4 w-1/2" />
            <Skeleton className="h-3 w-1/3" />
          </div>
          <Skeleton className="hidden h-7 w-28 rounded-full sm:block" />
        </div>
      ))}
    </div>
  );
}

/** Erro de bloco (falha ao carregar). Explica o que houve e como seguir. */
export function ErrorState({ message, onRetry }: { message?: string; onRetry?: () => void }) {
  return (
    <div role="alert" className="flex flex-col items-start gap-3 rounded-[var(--radius-card)] border border-clay/30 bg-clay-soft p-5 text-clay sm:flex-row sm:items-center">
      <CircleAlert aria-hidden className="size-5 shrink-0" />
      <p className="flex-1 text-sm">{message ?? "Não foi possível carregar os dados."}</p>
      {onRetry && (
        <Button variant="secondary" size="sm" onClick={onRetry}>
          Tentar de novo
        </Button>
      )}
    </div>
  );
}

/** Mensagem de erro em linha, ligada ao campo por `id`. */
export function FieldError({ id, message }: { id: string; message?: string }) {
  if (!message) return null;
  return (
    <p id={id} className="flex items-center gap-1.5 text-[0.8125rem] text-clay">
      <CircleAlert aria-hidden className="size-3.5 shrink-0" />
      {message}
    </p>
  );
}

/** Mensagem de erro de formulário (ex.: conflito de horário ao salvar). */
export function FormAlert({ title, children, tone = "error" }: { title: string; children?: ReactNode; tone?: "error" | "warning" }) {
  return (
    <div
      role="alert"
      className={cn(
        "flex gap-3 rounded-xl border p-3.5 text-sm",
        tone === "error" ? "border-clay/30 bg-clay-soft text-clay" : "border-amber/30 bg-amber-soft text-amber",
      )}
    >
      <CircleAlert aria-hidden className="mt-0.5 size-4 shrink-0" />
      <div className="space-y-1">
        <p className="font-semibold">{title}</p>
        {children && <div className="text-ink/80">{children}</div>}
      </div>
    </div>
  );
}
