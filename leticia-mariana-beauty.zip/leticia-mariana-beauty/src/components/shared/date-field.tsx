"use client";

import type { ComponentProps } from "react";
import { Input } from "@/components/ui/input";

/**
 * Seletor de data nativo (abre o calendário do sistema, em pt-BR quando o
 * aparelho está em português). Trabalha com "yyyy-MM-dd".
 */
export function DateField(props: Omit<ComponentProps<"input">, "type">) {
  return <Input {...props} type="date" lang="pt-BR" className="tabular" />;
}
