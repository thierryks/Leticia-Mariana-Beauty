"use client";

import type { ComponentProps } from "react";
import { Input } from "@/components/ui/input";
import { maskPhoneInput } from "@/lib/formatters/phone";

type PhoneInputProps = Omit<ComponentProps<"input">, "type" | "onChange" | "value"> & {
  value: string;
  onChange: (masked: string) => void;
};

/** Telefone brasileiro com máscara "(21) 99999-0000". A normalização acontece ao salvar. */
export function PhoneInput({ value, onChange, ...props }: PhoneInputProps) {
  return (
    <Input
      {...props}
      type="tel"
      inputMode="tel"
      autoComplete={props.autoComplete ?? "tel-national"}
      placeholder={props.placeholder ?? "(21) 99999-0000"}
      value={value}
      onChange={(event) => onChange(maskPhoneInput(event.target.value))}
    />
  );
}
