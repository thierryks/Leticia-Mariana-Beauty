import type { LucideIcon } from "lucide-react";
import type { ReactNode } from "react";
import { cn } from "@/lib/utils";
import { Skeleton } from "@/components/ui/skeleton";

interface StatCardProps {
  label: string;
  value: ReactNode;
  hint?: ReactNode;
  icon: LucideIcon;
  loading?: boolean;
  /** Destaca o indicador quando pede ação (ex.: pendências). */
  attention?: boolean;
}

export function StatCard({ label, value, hint, icon: Icon, loading, attention }: StatCardProps) {
  return (
    <div
      className={cn(
        "relative flex flex-col gap-3 rounded-[var(--radius-card)] border border-line bg-surface p-4 sm:p-5",
        attention && "border-gold/60",
      )}
    >
      <div className="flex items-center justify-between gap-2">
        <p className="text-sm text-muted">{label}</p>
        <Icon aria-hidden className={cn("size-4.5 text-gold-ink", attention && "text-amber")} />
      </div>
      {loading ? (
        <Skeleton className="h-8 w-20" />
      ) : (
        <p className="tabular text-[1.65rem] leading-none font-semibold text-brown">{value}</p>
      )}
      {hint && !loading && <p className="text-xs text-muted">{hint}</p>}
    </div>
  );
}
