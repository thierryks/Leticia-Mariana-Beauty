"use client";

import type { ComponentProps } from "react";
import { Input } from "@/components/ui/input";
import { digitsToCents, formatCents } from "@/lib/formatters/currency";

type MoneyInputProps = Omit<ComponentProps<"input">, "value" | "onChange" | "type"> & {
  /** Valor em centavos inteiros. */
  value: number;
  onChange: (cents: number) => void;
};

/**
 * Campo monetário em BRL. Cada dígito digitado entra pela direita
 * (como em apps de banco), então o valor é sempre centavos inteiros.
 */
export function MoneyInput({ value, onChange, ...props }: MoneyInputProps) {
  return (
    <Input
      {...props}
      inputMode="numeric"
      autoComplete="off"
      className="tabular"
      value={formatCents(Number.isInteger(value) ? value : 0)}
      onChange={(event) => onChange(digitsToCents(event.target.value))}
      onFocus={(event) => {
        const el = event.currentTarget;
        requestAnimationFrame(() => el.setSelectionRange(el.value.length, el.value.length));
        props.onFocus?.(event);
      }}
    />
  );
}
