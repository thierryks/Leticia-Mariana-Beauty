"use client";

import {
  cloneElement,
  isValidElement,
  useId,
  type AriaAttributes,
  type ReactElement,
  type ReactNode,
} from "react";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";
import { FieldError } from "./states";

interface FormFieldProps {
  label: string;
  error?: string;
  hint?: ReactNode;
  optional?: boolean;
  className?: string;
  /** Um único controle (input, select, textarea…). Recebe id e atributos ARIA. */
  children: ReactElement<ControlProps>;
}

type ControlProps = { id?: string } & Pick<AriaAttributes, "aria-invalid" | "aria-describedby">;

/**
 * Label visível + controle + dica + erro, com `htmlFor`, `aria-invalid`
 * e `aria-describedby` ligados automaticamente.
 */
export function FormField({ label, error, hint, optional, className, children }: FormFieldProps) {
  const baseId = useId();
  const id = children.props.id ?? `${baseId}-field`;
  const hintId = hint ? `${baseId}-hint` : undefined;
  const errorId = error ? `${baseId}-error` : undefined;
  const describedBy = [hintId, errorId].filter(Boolean).join(" ") || undefined;

  const control = isValidElement(children)
    ? cloneElement(children, {
        id,
        "aria-invalid": error ? true : undefined,
        "aria-describedby": describedBy,
      })
    : children;

  return (
    <div className={cn("flex flex-col gap-1.5", className)}>
      <Label htmlFor={id}>
        {label}
        {optional && <span className="ml-1 font-normal text-muted">(opcional)</span>}
      </Label>
      {control}
      {hint && (
        <p id={hintId} className="text-[0.8125rem] text-muted">
          {hint}
        </p>
      )}
      <FieldError id={errorId ?? `${baseId}-error`} message={error} />
    </div>
  );
}
