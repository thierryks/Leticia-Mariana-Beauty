"use client";

import type { ReactNode } from "react";
import {
  Dialog,
  DialogBody,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useIsDesktop } from "@/hooks/use-media-query";
import { cn } from "@/lib/utils";

interface ResponsiveDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  description?: ReactNode;
  children: ReactNode;
  footer?: ReactNode;
  /** "drawer" abre pela lateral no desktop; "dialog" abre centralizado. */
  desktop?: "dialog" | "drawer";
  /** Quando verdadeiro, `children` já traz DialogBody/DialogFooter (ex.: um <form> que envolve ambos). */
  rawContent?: boolean;
  className?: string;
}

/**
 * Drawer vindo de baixo no celular; dialog centralizado ou lateral no desktop.
 * Foco preso, Esc para fechar e título anunciado por leitores de tela (Radix).
 */
export function ResponsiveDialog({
  open,
  onOpenChange,
  title,
  description,
  children,
  footer,
  desktop = "dialog",
  rawContent = false,
  className,
}: ResponsiveDialogProps) {
  const isDesktop = useIsDesktop();
  const side = isDesktop ? (desktop === "drawer" ? "right" : "center") : "bottom";

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent side={side} className={cn(side === "center" && "max-w-xl", className)}>
        {side === "bottom" && <div aria-hidden className="mx-auto mt-2.5 h-1 w-10 rounded-full bg-sand-strong" />}
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          {description ? (
            <DialogDescription>{description}</DialogDescription>
          ) : (
            <DialogDescription className="sr-only">{title}</DialogDescription>
          )}
        </DialogHeader>
        {rawContent ? (
          children
        ) : (
          <>
            <DialogBody>{children}</DialogBody>
            {footer && <DialogFooter>{footer}</DialogFooter>}
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
