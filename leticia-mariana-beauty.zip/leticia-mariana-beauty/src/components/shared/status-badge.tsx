import {
  CalendarClock,
  CircleCheck,
  CircleDashed,
  CircleSlash,
  Clock,
  Sparkles,
  type LucideIcon,
} from "lucide-react";
import type { ReactNode } from "react";
import { APPOINTMENT_STATUS_META, type StatusTone } from "@/lib/constants/labels";
import { cn } from "@/lib/utils";
import type { AppointmentStatus } from "@/types/appointment";

const toneClasses: Record<StatusTone, string> = {
  sage: "bg-sage-soft text-sage",
  amber: "bg-amber-soft text-amber",
  clay: "bg-clay-soft text-clay",
  mauve: "bg-mauve-soft text-mauve",
  slate: "bg-slate-soft text-slate",
  gold: "bg-sand text-gold-ink",
};

const toneIcon: Record<StatusTone, LucideIcon> = {
  sage: CircleCheck,
  amber: Clock,
  clay: CircleSlash,
  mauve: Sparkles,
  slate: CircleDashed,
  gold: CalendarClock,
};

interface ToneBadgeProps {
  tone: StatusTone;
  children: ReactNode;
  icon?: LucideIcon;
  className?: string;
}

/** Selo com texto + ícone + cor: o status nunca depende só da cor. */
export function ToneBadge({ tone, children, icon, className }: ToneBadgeProps) {
  const Icon = icon ?? toneIcon[tone];
  return (
    <span
      className={cn(
        "inline-flex h-7 shrink-0 items-center gap-1.5 rounded-full px-2.5 text-xs font-medium whitespace-nowrap",
        toneClasses[tone],
        className,
      )}
    >
      <Icon aria-hidden className="size-3.5" />
      {children}
    </span>
  );
}

export function StatusBadge({ status, className }: { status: AppointmentStatus; className?: string }) {
  const meta = APPOINTMENT_STATUS_META[status];
  return (
    <ToneBadge tone={meta.tone} className={className}>
      {meta.label}
    </ToneBadge>
  );
}
