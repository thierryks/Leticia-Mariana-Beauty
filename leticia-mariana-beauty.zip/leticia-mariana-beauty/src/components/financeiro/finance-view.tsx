"use client";

import { CalendarDays, CircleCheck, Clock, HandCoins, Wallet } from "lucide-react";
import { useMemo, useState } from "react";
import { FilterChips } from "@/components/shared/filters";
import { PageHeader } from "@/components/shared/page-header";
import { StatCard } from "@/components/shared/stat-card";
import { EmptyState, ErrorState, LoadingState } from "@/components/shared/states";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { FINANCE_PERIODS, buildFinanceSummary, resolvePeriod, type FinancePeriod } from "@/features/finance/summary";
import { useTenant } from "@/features/tenant/session-context";
import { useAsyncData } from "@/hooks/use-async-data";
import { useNow } from "@/hooks/use-now";
import {
  dateKeyOf,
  formatDateKey,
  formatDateKeyShort,
  formatTime,
  shiftDateKey,
  todayKey,
  zonedDateTimeToUtc,
} from "@/lib/datetime";
import { formatCents } from "@/lib/formatters/currency";
import { repositories } from "@/repositories";

const PERIOD_OPTIONS = FINANCE_PERIODS.map((p) => ({ value: p.value, label: p.label }));

function plural(count: number, one: string, many: string) {
  return `${count} ${count === 1 ? one : many}`;
}

export function FinanceView() {
  const tenant = useTenant();
  const tz = tenant.timezone;
  const now = useNow();
  const [period, setPeriod] = useState<FinancePeriod>("month");

  const today = todayKey(tz, now);
  const range = useMemo(() => resolvePeriod(period, today), [period, today]);

  const query = useAsyncData(`finance:${tenant.id}:${range.startKey}:${range.endKey}`, () =>
    repositories.appointments.listBetween(
      tenant.id,
      zonedDateTimeToUtc(range.startKey, "00:00", tz),
      zonedDateTimeToUtc(range.endKey, "00:00", tz),
    ),
  );

  const summary = useMemo(
    () => (query.data ? buildFinanceSummary(query.data, range, tz) : null),
    [query.data, range, tz],
  );

  const lastDay = shiftDateKey(range.endKey, -1);
  const rangeLabel = `${formatDateKey(range.startKey)} a ${formatDateKey(lastDay)}`;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Financeiro"
        description="Valores da tabela de serviços e sinais combinados. Pagamentos e recibos chegam na próxima etapa."
      />

      <div className="space-y-3">
        <FilterChips label="Período" options={PERIOD_OPTIONS} value={period} onChange={setPeriod} />
        <p className="text-sm text-muted">Período: {rangeLabel}</p>
      </div>

      {query.error && <ErrorState onRetry={query.reload} />}
      {!query.error && !summary && <LoadingState rows={4} label="Carregando o financeiro…" />}

      {summary && (
        <>
          <section aria-label="Indicadores do período" className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            <StatCard
              label="Previsto"
              value={formatCents(summary.expectedInCents)}
              hint={plural(summary.activeCount, "atendimento ativo", "atendimentos ativos")}
              icon={Wallet}
            />
            <StatCard
              label="Sinais recebidos"
              value={formatCents(summary.signalsPaidInCents)}
              hint={plural(summary.signalsPaidCount, "sinal pago", "sinais pagos")}
              icon={HandCoins}
            />
            <StatCard
              label="Sinais pendentes"
              value={formatCents(summary.signalsPendingInCents)}
              hint={plural(summary.signalsPendingCount, "sinal a receber", "sinais a receber")}
              icon={Clock}
              attention={summary.signalsPendingCount > 0}
            />
            <StatCard
              label="Concluídos"
              value={formatCents(summary.completedInCents)}
              hint={plural(summary.completedCount, "atendimento", "atendimentos")}
              icon={CircleCheck}
            />
          </section>

          <div className="grid gap-6 lg:grid-cols-[1.4fr_1fr]">
            <Card>
              <CardHeader>
                <div>
                  <CardTitle>Movimento por dia</CardTitle>
                  <CardDescription>Só os dias com atendimentos ativos.</CardDescription>
                </div>
              </CardHeader>
              <CardContent>
                {summary.days.length === 0 ? (
                  <EmptyState
                    icon={CalendarDays}
                    title="Nada agendado neste período"
                    description="Quando houver atendimentos ativos, o valor de cada dia aparece aqui."
                  />
                ) : (
                  <ul className="divide-y divide-line">
                    {summary.days.map((day) => (
                      <li key={day.dateKey} className="grid grid-cols-[1fr_auto] gap-x-4 gap-y-1 py-3 text-sm first:pt-0 last:pb-0">
                        <p className="font-medium text-brown capitalize">{formatDateKeyShort(day.dateKey)}</p>
                        <p className="tabular font-semibold text-brown">{formatCents(day.expectedInCents)}</p>
                        <p className="text-xs text-muted">{plural(day.count, "atendimento", "atendimentos")}</p>
                        <p className="tabular text-xs text-muted">
                          Sinais recebidos {formatCents(day.signalsPaidInCents)}
                        </p>
                      </li>
                    ))}
                  </ul>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div>
                  <CardTitle>Sinais a receber</CardTitle>
                  <CardDescription>Combinados e ainda não pagos.</CardDescription>
                </div>
              </CardHeader>
              <CardContent>
                {summary.pendingSignals.length === 0 ? (
                  <EmptyState
                    icon={HandCoins}
                    title="Nenhum sinal pendente"
                    description="Sinais combinados que ainda não foram pagos aparecem aqui."
                  />
                ) : (
                  <ul className="divide-y divide-line">
                    {summary.pendingSignals.map((a) => (
                      <li key={a.id} className="flex items-start justify-between gap-3 py-3 first:pt-0 last:pb-0">
                        <div className="min-w-0">
                          <p className="truncate text-sm font-medium text-brown">{a.clientName}</p>
                          <p className="text-xs text-muted">
                            {formatDateKey(dateKeyOf(a.startAt, tz))} · {formatTime(a.startAt, tz)} · {a.serviceName}
                          </p>
                        </div>
                        <p className="tabular shrink-0 text-sm font-semibold text-amber">{formatCents(a.signalInCents)}</p>
                      </li>
                    ))}
                  </ul>
                )}
              </CardContent>
            </Card>
          </div>

          <p className="text-xs text-muted">
            Valores de tabela e sinais combinados. Não há registro de pagamentos nesta etapa, então &ldquo;recebido&rdquo; significa sinal marcado como pago.
          </p>
        </>
      )}
    </div>
  );
}
