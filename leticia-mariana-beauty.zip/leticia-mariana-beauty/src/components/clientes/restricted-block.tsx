import { LockKeyhole } from "lucide-react";
import type { ReactNode } from "react";

/**
 * Moldura visual para informação RESTRITA (alergias e sensibilidades — RN-07).
 * Deixa claro que o dado é sensível e não deve sair do atendimento.
 */
export function RestrictedBlock({ children, title = "Informação restrita" }: { children: ReactNode; title?: string }) {
  return (
    <section
      aria-label={title}
      className="rounded-[var(--radius-card)] border border-mauve/30 bg-mauve-soft/50 p-4 sm:p-5"
    >
      <div className="mb-3 flex items-start gap-3">
        <span className="inline-flex size-8 shrink-0 items-center justify-center rounded-full bg-mauve-soft text-mauve">
          <LockKeyhole aria-hidden className="size-4" />
        </span>
        <div>
          <h3 className="text-sm font-semibold text-mauve">{title}</h3>
          <p className="text-[0.8125rem] text-ink/70">
            Só para cuidar do atendimento. Não aparece em relatórios nem em mensagens.
          </p>
        </div>
      </div>
      {children}
    </section>
  );
}
