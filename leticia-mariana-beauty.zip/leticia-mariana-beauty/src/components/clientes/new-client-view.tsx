"use client";

import { ArrowLeft } from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { PageHeader } from "@/components/shared/page-header";
import { ErrorState, LoadingState } from "@/components/shared/states";
import { useTenant } from "@/features/tenant/session-context";
import { useAsyncData } from "@/hooks/use-async-data";
import { repositories } from "@/repositories";
import { ClientForm } from "./client-form";

export function NewClientView() {
  const tenant = useTenant();
  const router = useRouter();
  const services = useAsyncData(`services:${tenant.id}`, () => repositories.services.list(tenant.id));

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <Link href="/clientes" className="inline-flex items-center gap-1.5 text-sm text-muted hover:text-brown">
        <ArrowLeft aria-hidden className="size-4" />
        Clientes
      </Link>
      <PageHeader title="Nova cliente" description="Só nome e telefone são obrigatórios. O resto pode ser completado depois." />
      <div className="rounded-[var(--radius-card)] border border-line bg-surface p-5 sm:p-7">
        {services.error ? (
          <ErrorState onRetry={services.reload} />
        ) : !services.data ? (
          <LoadingState rows={3} />
        ) : (
          <ClientForm
            services={services.data}
            variant="page"
            onCancel={() => router.push("/clientes")}
            onSaved={(client) => router.push(`/clientes/${client.id}`)}
          />
        )}
      </div>
    </div>
  );
}
