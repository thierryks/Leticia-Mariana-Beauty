import { StatusBadge } from "@/components/shared/status-badge";
import { dateKeyOf, formatDateKeyShort, formatTime } from "@/lib/datetime";
import { formatCents } from "@/lib/formatters/currency";
import type { Appointment } from "@/types/appointment";

export function ClientAppointmentsList({
  appointments,
  timezone,
  emptyText,
}: {
  appointments: Appointment[];
  timezone: string;
  emptyText: string;
}) {
  if (appointments.length === 0) {
    return <p className="rounded-xl border border-dashed border-sand-strong p-4 text-sm text-muted">{emptyText}</p>;
  }
  return (
    <ul className="divide-y divide-line rounded-[var(--radius-card)] border border-line bg-surface">
      {appointments.map((a) => (
        <li key={a.id} className="flex flex-wrap items-center gap-x-4 gap-y-2 px-4 py-3.5">
          <div className="w-32 shrink-0">
            <p className="text-sm font-medium text-ink first-letter:uppercase">
              {formatDateKeyShort(dateKeyOf(a.startAt, timezone))}
            </p>
            <p className="tabular text-xs text-muted">
              {formatTime(a.startAt, timezone)} – {formatTime(a.endAt, timezone)}
            </p>
          </div>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-medium text-ink">{a.serviceName}</p>
            <p className="truncate text-xs text-muted">
              {a.professionalName} · <span className="tabular">{formatCents(a.priceInCents)}</span>
            </p>
          </div>
          <StatusBadge status={a.status} />
        </li>
      ))}
    </ul>
  );
}
