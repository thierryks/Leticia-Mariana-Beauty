"use client";

import { CalendarPlus, Eye, Ellipsis, UserPlus, UserRoundSearch, UserX, UserCheck } from "lucide-react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useMemo, useState } from "react";
import { ConfirmDialog } from "@/components/shared/confirm-dialog";
import { FilterChips, SearchField, type FilterOption } from "@/components/shared/filters";
import { PageHeader } from "@/components/shared/page-header";
import { Pagination, ResponsiveTable, type Column } from "@/components/shared/responsive-table";
import { EmptyState, ErrorState, LoadingState } from "@/components/shared/states";
import { buttonVariants } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { buildClientOverviews, type ClientOverview } from "@/features/clients/overview";
import { matchesClientSearch, matchesClientStatus } from "@/features/clients/rules";
import { useTenant } from "@/features/tenant/session-context";
import { useAsyncData } from "@/hooks/use-async-data";
import { useNow } from "@/hooks/use-now";
import { formatShortDate, formatTime } from "@/lib/datetime";
import { formatPhone } from "@/lib/formatters/phone";
import { repositories } from "@/repositories";
import type { ClientStatusFilter } from "@/types/client";
import { ClientStatusBadges } from "./client-status";

const PAGE_SIZE = 8;

const FILTER_PARAM: Record<string, ClientStatusFilter> = {
  ativas: "active",
  inativas: "inactive",
  novas: "new",
  manutencao: "maintenance_due",
};

export function ClientsView() {
  const tenant = useTenant();
  const tz = tenant.timezone;
  const router = useRouter();
  const searchParams = useSearchParams();

  const now = useNow();
  const [search, setSearch] = useState(searchParams.get("busca") ?? "");
  const [filter, setFilter] = useState<ClientStatusFilter>(FILTER_PARAM[searchParams.get("filtro") ?? ""] ?? "active");
  const [page, setPage] = useState(1);
  const [toToggle, setToToggle] = useState<ClientOverview | null>(null);

  // A busca global do topo atualiza ?busca=; quando muda, a lista acompanha.
  const urlSearch = searchParams.get("busca") ?? "";
  const [lastUrlSearch, setLastUrlSearch] = useState(urlSearch);
  if (urlSearch !== lastUrlSearch) {
    setLastUrlSearch(urlSearch);
    setSearch(urlSearch);
    setPage(1);
  }

  const query = useAsyncData(`clients:${tenant.id}`, async () => {
    const [clients, appointments, services] = await Promise.all([
      repositories.clients.list(tenant.id),
      repositories.appointments.listAll(tenant.id),
      repositories.services.list(tenant.id),
    ]);
    return { overviews: buildClientOverviews(clients, appointments, services, now), services };
  });

  const serviceName = useMemo(() => {
    const map = new Map((query.data?.services ?? []).map((s) => [s.id, s.name]));
    return (id?: string) => (id ? (map.get(id) ?? "—") : "—");
  }, [query.data?.services]);

  const searched = useMemo(
    () => (query.data?.overviews ?? []).filter((o) => matchesClientSearch(o.client, search)),
    [query.data, search],
  );

  const filterOptions: FilterOption<ClientStatusFilter>[] = (
    [
      ["all", "Todas"],
      ["active", "Ativas"],
      ["inactive", "Inativas"],
      ["new", "Novas"],
      ["maintenance_due", "Manutenção pendente"],
    ] as const
  ).map(([value, label]) => ({
    value,
    label,
    count: query.data ? searched.filter((o) => matchesClientStatus(o.client, value, o.maintenance, now)).length : undefined,
  }));

  const filtered = searched.filter((o) => matchesClientStatus(o.client, filter, o.maintenance, now));
  const pageCount = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const currentPage = Math.min(page, pageCount);
  const rows = filtered.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);

  const lastVisit = (o: ClientOverview) =>
    o.timeline.lastCompleted ? formatShortDate(o.timeline.lastCompleted.startAt, tz) : "—";
  const nextVisit = (o: ClientOverview) =>
    o.timeline.nextActive
      ? `${formatShortDate(o.timeline.nextActive.startAt, tz)} às ${formatTime(o.timeline.nextActive.startAt, tz)}`
      : "—";

  const actions = (o: ClientOverview) => (
    <DropdownMenu>
      <DropdownMenuTrigger
        aria-label={`Ações para ${o.client.fullName}`}
        className="inline-flex size-10 items-center justify-center rounded-full text-muted hover:bg-sand hover:text-brown"
      >
        <Ellipsis aria-hidden className="size-5" />
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem onSelect={() => router.push(`/clientes/${o.client.id}`)}>
          <Eye aria-hidden />
          Ver perfil
        </DropdownMenuItem>
        <DropdownMenuItem
          disabled={!o.client.active}
          onSelect={() => router.push(`/agenda?novo=1&cliente=${o.client.id}`)}
        >
          <CalendarPlus aria-hidden />
          Novo agendamento
        </DropdownMenuItem>
        <DropdownMenuItem onSelect={() => setToToggle(o)}>
          {o.client.active ? <UserX aria-hidden /> : <UserCheck aria-hidden />}
          {o.client.active ? "Desativar" : "Reativar"}
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );

  const columns: Column<ClientOverview>[] = [
    {
      key: "name",
      header: "Nome",
      cell: (o) => (
        <Link href={`/clientes/${o.client.id}`} className="font-medium text-ink hover:text-gold-ink hover:underline">
          {o.client.fullName}
        </Link>
      ),
    },
    { key: "phone", header: "Telefone", cell: (o) => <span className="tabular whitespace-nowrap">{formatPhone(o.client.phone)}</span> },
    { key: "last", header: "Último atendimento", cell: (o) => <span className="tabular">{lastVisit(o)}</span>, hideBelow: "lg" },
    { key: "next", header: "Próximo atendimento", cell: (o) => <span className="tabular">{nextVisit(o)}</span> },
    { key: "service", header: "Serviço preferido", cell: (o) => serviceName(o.client.preferredService), hideBelow: "xl" },
    { key: "status", header: "Situação", cell: (o) => <ClientStatusBadges overview={o} /> },
    { key: "actions", header: "Ações", cell: actions, className: "w-14 text-right" },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Clientes"
        description="Busque por nome ou telefone. Clientes desativadas continuam no histórico."
        actions={
          <Link href="/clientes/novo" className={buttonVariants()}>
            <UserPlus aria-hidden />
            Nova cliente
          </Link>
        }
      />

      <div className="space-y-3">
        <SearchField
          label="Buscar cliente por nome ou telefone"
          placeholder="Buscar por nome ou telefone"
          value={search}
          onValueChange={(value) => {
            setSearch(value);
            setPage(1);
          }}
          className="max-w-md"
        />
        <FilterChips
          label="Filtrar clientes"
          options={filterOptions}
          value={filter}
          onChange={(value) => {
            setFilter(value);
            setPage(1);
          }}
        />
      </div>

      {query.error ? (
        <ErrorState message="Não foi possível carregar as clientes." onRetry={query.reload} />
      ) : query.loading ? (
        <LoadingState rows={5} label="Carregando clientes…" />
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={UserRoundSearch}
          title={search ? "Nenhuma cliente encontrada" : "Nenhuma cliente neste filtro"}
          description={search ? `Não achamos “${search}”. Confira a grafia ou busque pelo telefone.` : "Escolha outro filtro ou cadastre uma nova cliente."}
          action={
            <Link href="/clientes/novo" className={buttonVariants({ variant: "secondary" })}>
              <UserPlus aria-hidden />
              Nova cliente
            </Link>
          }
        />
      ) : (
        <>
          <ResponsiveTable
            caption="Lista de clientes"
            columns={columns}
            rows={rows}
            rowKey={(o) => o.client.id}
            renderCard={(o) => (
              <div className="rounded-[var(--radius-card)] border border-line bg-surface p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <Link href={`/clientes/${o.client.id}`} className="block truncate font-semibold text-ink">
                      {o.client.fullName}
                    </Link>
                    <p className="tabular text-sm text-muted">{formatPhone(o.client.phone)}</p>
                  </div>
                  {actions(o)}
                </div>
                <div className="mt-3">
                  <ClientStatusBadges overview={o} />
                </div>
                <dl className="mt-3 grid grid-cols-2 gap-3 border-t border-line pt-3 text-sm">
                  <div>
                    <dt className="text-xs text-muted">Último atendimento</dt>
                    <dd className="tabular">{lastVisit(o)}</dd>
                  </div>
                  <div>
                    <dt className="text-xs text-muted">Próximo</dt>
                    <dd className="tabular">{nextVisit(o)}</dd>
                  </div>
                  <div className="col-span-2">
                    <dt className="text-xs text-muted">Serviço preferido</dt>
                    <dd>{serviceName(o.client.preferredService)}</dd>
                  </div>
                </dl>
              </div>
            )}
          />
          <Pagination
            page={currentPage}
            pageCount={pageCount}
            total={filtered.length}
            itemLabel={filtered.length === 1 ? "cliente" : "clientes"}
            onPageChange={setPage}
          />
        </>
      )}

      <ConfirmDialog
        open={toToggle !== null}
        onOpenChange={(open) => !open && setToToggle(null)}
        title={toToggle?.client.active ? "Desativar cliente?" : "Reativar cliente?"}
        description={
          toToggle?.client.active
            ? `${toToggle.client.fullName} deixa de aparecer na agenda e nas buscas de clientes ativas. O histórico é mantido e você pode reativar quando quiser.`
            : `${toToggle?.client.fullName ?? "A cliente"} volta a aparecer na agenda e nas buscas.`
        }
        confirmLabel={toToggle?.client.active ? "Desativar" : "Reativar"}
        onConfirm={async () => {
          if (!toToggle) return;
          await repositories.clients.setActive(tenant.id, toToggle.client.id, !toToggle.client.active);
          query.reload();
        }}
      />
    </div>
  );
}
