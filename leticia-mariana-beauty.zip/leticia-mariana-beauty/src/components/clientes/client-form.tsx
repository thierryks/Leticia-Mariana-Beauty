"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { LoaderCircle, TriangleAlert } from "lucide-react";
import Link from "next/link";
import { useState, type ReactNode } from "react";
import { Controller, useForm, useWatch } from "react-hook-form";
import { DateField } from "@/components/shared/date-field";
import { FormField } from "@/components/shared/form-field";
import { PhoneInput } from "@/components/shared/phone-input";
import { FormAlert } from "@/components/shared/states";
import { Button } from "@/components/ui/button";
import { DialogBody, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { NativeSelect } from "@/components/ui/native-select";
import { Textarea } from "@/components/ui/textarea";
import { useTenant } from "@/features/tenant/session-context";
import { useAsyncData } from "@/hooks/use-async-data";
import { CLIENT_SOURCE_LABEL } from "@/lib/constants/labels";
import { formatPhone, normalizeBrazilianPhone } from "@/lib/formatters/phone";
import { EMPTY_CLIENT_FORM, clientFormSchema, toClientInput, type ClientFormValues } from "@/lib/validators/client";
import { DuplicatePhoneError, repositories } from "@/repositories";
import { CLIENT_SOURCES, type Client } from "@/types/client";
import type { Service } from "@/types/service";
import { RestrictedBlock } from "./restricted-block";

function toFormValues(client?: Client): ClientFormValues {
  if (!client) return EMPTY_CLIENT_FORM;
  return {
    fullName: client.fullName,
    phone: formatPhone(client.phone),
    birthDate: client.birthDate ?? "",
    instagram: client.instagram ?? "",
    preferredService: client.preferredService ?? "",
    emergencyContact: client.emergencyContact ?? "",
    source: client.source ?? "",
    notes: client.notes ?? "",
    sensitivities: client.sensitivities ?? "",
  };
}

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <fieldset className="space-y-4">
      <legend className="mb-3 text-[0.95rem] font-semibold text-brown">{title}</legend>
      {children}
    </fieldset>
  );
}

interface ClientFormProps {
  client?: Client;
  services: Service[];
  variant: "page" | "dialog";
  onSaved: (client: Client) => void;
  onCancel: () => void;
}

export function ClientForm({ client, services, variant, onSaved, onCancel }: ClientFormProps) {
  const tenant = useTenant();
  const editing = Boolean(client);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [pendingDuplicate, setPendingDuplicate] = useState<ClientFormValues | null>(null);

  const {
    control,
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<ClientFormValues>({
    resolver: zodResolver(clientFormSchema),
    defaultValues: toFormValues(client),
    mode: "onTouched",
  });

  const phone = useWatch({ control, name: "phone" });
  const normalized = normalizeBrazilianPhone(phone) ?? "";
  // Alerta de possível duplicidade pelo telefone, sempre dentro da empresa atual.
  const duplicate = useAsyncData(`dup:${tenant.id}:${normalized}:${client?.id ?? ""}`, async () =>
    normalized ? repositories.clients.findByPhone(tenant.id, normalized, client?.id) : null,
  );

  async function save(values: ClientFormValues, allowDuplicatePhone: boolean) {
    setSaveError(null);
    try {
      const input = toClientInput(values);
      const saved = client
        ? await repositories.clients.update(tenant.id, client.id, input)
        : await repositories.clients.create(tenant.id, input, { allowDuplicatePhone });
      onSaved(saved);
    } catch (error) {
      if (error instanceof DuplicatePhoneError) {
        setPendingDuplicate(values);
        return;
      }
      setSaveError("Não foi possível salvar. Confira os dados e tente de novo.");
    }
  }

  const onSubmit = handleSubmit((values) => save(values, false));
  const activeServices = services.filter((s) => s.active || s.id === client?.preferredService);

  const fields = (
    <div className="space-y-8">
      {saveError && <FormAlert title={saveError} />}
      {pendingDuplicate && duplicate.data && (
        <FormAlert tone="warning" title="Já existe uma cliente com este telefone">
          <p>
            {duplicate.data.fullName} usa o mesmo número. Se for outra pessoa (ex.: telefone compartilhado), você pode
            salvar mesmo assim.
          </p>
          <div className="mt-3 flex flex-wrap gap-2">
            <Button size="sm" onClick={() => save(pendingDuplicate, true)} disabled={isSubmitting}>
              Salvar mesmo assim
            </Button>
            <Link href={`/clientes/${duplicate.data.id}`} className="inline-flex h-9 items-center px-2 text-sm text-gold-ink underline-offset-4 hover:underline">
              Abrir cadastro existente
            </Link>
          </div>
        </FormAlert>
      )}

      <Section title="Dados principais">
        <FormField label="Nome completo" error={errors.fullName?.message}>
          <Input autoComplete="off" {...register("fullName")} />
        </FormField>
        <div className="grid gap-4 sm:grid-cols-2">
          <Controller
            control={control}
            name="phone"
            render={({ field }) => (
              <FormField
                label="Telefone (WhatsApp)"
                error={errors.phone?.message}
                hint={
                  duplicate.data && !pendingDuplicate ? (
                    <span className="flex items-center gap-1.5 text-amber">
                      <TriangleAlert aria-hidden className="size-3.5" />
                      {`Possível duplicidade: ${duplicate.data.fullName} já usa este número.`}
                    </span>
                  ) : undefined
                }
              >
                <PhoneInput
                  name={field.name}
                  value={field.value}
                  onChange={field.onChange}
                  onBlur={field.onBlur}
                  ref={field.ref}
                  autoComplete="off"
                />
              </FormField>
            )}
          />
          <FormField label="Data de nascimento" optional error={errors.birthDate?.message}>
            <DateField {...register("birthDate")} />
          </FormField>
        </div>
        <FormField label="Instagram" optional error={errors.instagram?.message}>
          <Input placeholder="@perfil" autoComplete="off" {...register("instagram")} />
        </FormField>
      </Section>

      <Section title="Atendimento">
        <div className="grid gap-4 sm:grid-cols-2">
          <FormField label="Serviço preferido" optional>
            <NativeSelect {...register("preferredService")}>
              <option value="">Sem preferência</option>
              {activeServices.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </NativeSelect>
          </FormField>
          <FormField label="Como conheceu o studio" optional error={errors.source?.message}>
            <NativeSelect {...register("source")}>
              <option value="">Não informado</option>
              {CLIENT_SOURCES.map((s) => (
                <option key={s} value={s}>
                  {CLIENT_SOURCE_LABEL[s]}
                </option>
              ))}
            </NativeSelect>
          </FormField>
        </div>
        <FormField label="Contato de emergência" optional hint="Nome e telefone." error={errors.emergencyContact?.message}>
          <Input autoComplete="off" {...register("emergencyContact")} />
        </FormField>
        <FormField label="Observações" optional error={errors.notes?.message}>
          <Textarea {...register("notes")} placeholder="Preferências de horário, estilo de cílios, etc." />
        </FormField>
      </Section>

      <RestrictedBlock title="Alergias ou sensibilidades informadas">
        <FormField label="O que a cliente informou" optional error={errors.sensitivities?.message}>
          <Textarea {...register("sensitivities")} placeholder="Ex.: sensibilidade a cola comum." className="bg-surface" />
        </FormField>
      </RestrictedBlock>
    </div>
  );

  const actions = (
    <>
      <Button variant="secondary" onClick={onCancel} disabled={isSubmitting}>
        Cancelar
      </Button>
      <Button type="submit" disabled={isSubmitting}>
        {isSubmitting ? (
          <>
            <LoaderCircle aria-hidden className="animate-spin" />
            Salvando…
          </>
        ) : editing ? (
          "Salvar alterações"
        ) : (
          "Cadastrar cliente"
        )}
      </Button>
    </>
  );

  if (variant === "dialog") {
    return (
      <form onSubmit={onSubmit} noValidate className="flex min-h-0 flex-1 flex-col">
        <DialogBody>{fields}</DialogBody>
        <DialogFooter>{actions}</DialogFooter>
      </form>
    );
  }

  return (
    <form onSubmit={onSubmit} noValidate className="space-y-8">
      {fields}
      <div className="flex flex-col-reverse gap-2 border-t border-line pt-5 sm:flex-row sm:justify-end">{actions}</div>
    </form>
  );
}
