"use client";

import {
  ArrowLeft,
  CalendarPlus,
  Eye,
  EyeOff,
  LockKeyhole,
  MessageCircle,
  Pencil,
  RefreshCcw,
  UserCheck,
  UserRoundX,
  UserX,
} from "lucide-react";
import Link from "next/link";
import { useMemo, useState, type ReactNode } from "react";
import { ConfirmDialog } from "@/components/shared/confirm-dialog";
import { ResponsiveDialog } from "@/components/shared/responsive-dialog";
import { EmptyState, ErrorState, LoadingState } from "@/components/shared/states";
import { Button, buttonVariants } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { isBlockingStatus } from "@/features/appointments/rules";
import { buildClientOverviews } from "@/features/clients/overview";
import { useTenant } from "@/features/tenant/session-context";
import { useAsyncData } from "@/hooks/use-async-data";
import { useNow } from "@/hooks/use-now";
import { CLIENT_SOURCE_LABEL } from "@/lib/constants/labels";
import { STUDIO_SETTINGS } from "@/lib/constants/studio";
import { formatDateKey, formatInTimezone, formatShortDate } from "@/lib/datetime";
import { formatPhone, whatsappLink } from "@/lib/formatters/phone";
import { cn } from "@/lib/utils";
import { repositories } from "@/repositories";
import { ClientAppointmentsList } from "./client-appointments-list";
import { ClientForm } from "./client-form";
import { ClientStatusBadges } from "./client-status";
import { RestrictedBlock } from "./restricted-block";

function InfoRow({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="grid grid-cols-[9rem_1fr] gap-3 py-2.5 text-sm">
      <dt className="text-muted">{label}</dt>
      <dd className="min-w-0 break-words text-ink">{children || "—"}</dd>
    </div>
  );
}

export function ClientProfile({ id }: { id: string }) {
  const tenant = useTenant();
  const tz = tenant.timezone;
  const now = useNow();
  const [editing, setEditing] = useState(false);
  const [confirmToggle, setConfirmToggle] = useState(false);
  const [revealRestricted, setRevealRestricted] = useState(false);

  const query = useAsyncData(`client:${tenant.id}:${id}`, async () => {
    const [client, appointments, services] = await Promise.all([
      repositories.clients.getById(tenant.id, id),
      repositories.appointments.listByClient(tenant.id, id),
      repositories.services.list(tenant.id),
    ]);
    return { client, appointments, services };
  });

  const overview = useMemo(() => {
    const data = query.data;
    if (!data?.client) return null;
    return buildClientOverviews([data.client], data.appointments, data.services, now)[0] ?? null;
  }, [query.data, now]);

  if (query.error) return <ErrorState message="Não foi possível carregar esta cliente." onRetry={query.reload} />;
  if (query.loading) return <LoadingState rows={3} label="Carregando cliente…" />;
  if (!query.data?.client || !overview) {
    return (
      <EmptyState
        icon={UserRoundX}
        title="Cliente não encontrada"
        description="Ela pode ter sido cadastrada em outra empresa ou o endereço está incorreto."
        action={
          <Link href="/clientes" className={buttonVariants({ variant: "secondary" })}>
            Voltar para clientes
          </Link>
        }
      />
    );
  }

  const { client } = overview;
  const { appointments, services } = query.data;
  const serviceName = services.find((s) => s.id === client.preferredService)?.name;

  const upcoming = appointments.filter((a) => isBlockingStatus(a.status) && a.status !== "completed" && new Date(a.endAt).getTime() >= now);
  const history = [...appointments.filter((a) => !upcoming.includes(a))].reverse();
  const completedCount = appointments.filter((a) => a.status === "completed").length;
  const m = overview.maintenance;

  const maintenanceText = (() => {
    const fmt = (ms: number) => formatInTimezone(ms, "dd/MM", tz);
    switch (m.kind) {
      case "scheduled":
        return `Próximo horário já marcado para ${formatShortDate(m.appointment.startAt, tz)}.`;
      case "upcoming":
        return `Ideal entre ${fmt(m.dueFrom)} e ${fmt(m.dueTo)} (${STUDIO_SETTINGS.maintenanceWindowDays.from} a ${STUDIO_SETTINGS.maintenanceWindowDays.to} dias após o último atendimento).`;
      case "due":
        return `No prazo agora: até ${fmt(m.dueTo)}. Vale chamar a cliente para marcar.`;
      case "overdue":
        return `Passou do prazo há ${m.daysLate} ${m.daysLate === 1 ? "dia" : "dias"} (limite era ${fmt(m.dueTo)}). Pela política do studio, pode ser cobrada como nova aplicação.`;
      case "none":
        return "Ainda sem atendimento concluído para calcular.";
    }
  })();

  return (
    <div className="space-y-6">
      <Link href="/clientes" className="inline-flex items-center gap-1.5 text-sm text-muted hover:text-brown">
        <ArrowLeft aria-hidden className="size-4" />
        Clientes
      </Link>

      <header className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
        <div className="min-w-0 space-y-2">
          <h1 className="brand-title text-[1.6rem] leading-tight text-brown sm:text-[1.85rem]">{client.fullName}</h1>
          <div className="flex flex-wrap items-center gap-3 text-sm text-muted">
            <a
              href={whatsappLink(client.phone)}
              target="_blank"
              rel="noopener noreferrer"
              className="tabular inline-flex items-center gap-1.5 text-gold-ink underline-offset-4 hover:underline"
            >
              <MessageCircle aria-hidden className="size-4" />
              {formatPhone(client.phone)}
              <span className="sr-only">(abre o WhatsApp)</span>
            </a>
            {client.instagram && <span>{client.instagram}</span>}
          </div>
          <ClientStatusBadges overview={overview} />
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="secondary" onClick={() => setEditing(true)}>
            <Pencil aria-hidden />
            Editar
          </Button>
          {client.active && (
            <Link href={`/agenda?novo=1&cliente=${client.id}`} className={buttonVariants()}>
              <CalendarPlus aria-hidden />
              Novo agendamento
            </Link>
          )}
          <Button variant="ghost" onClick={() => setConfirmToggle(true)}>
            {client.active ? <UserX aria-hidden /> : <UserCheck aria-hidden />}
            {client.active ? "Desativar" : "Reativar"}
          </Button>
        </div>
      </header>

      <Tabs defaultValue="geral">
        <TabsList aria-label="Seções do perfil">
          <TabsTrigger value="geral">Visão geral</TabsTrigger>
          <TabsTrigger value="agendamentos">Agendamentos ({upcoming.length})</TabsTrigger>
          <TabsTrigger value="historico">Histórico ({history.length})</TabsTrigger>
          <TabsTrigger value="observacoes">Observações</TabsTrigger>
        </TabsList>

        <TabsContent value="geral">
          <div className="grid gap-6 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Dados cadastrais</CardTitle>
              </CardHeader>
              <CardContent className="pt-2">
                <dl className="divide-y divide-line">
                  <InfoRow label="Telefone">{formatPhone(client.phone)}</InfoRow>
                  <InfoRow label="Nascimento">{client.birthDate ? formatDateKey(client.birthDate) : ""}</InfoRow>
                  <InfoRow label="Instagram">{client.instagram}</InfoRow>
                  <InfoRow label="Serviço preferido">{serviceName}</InfoRow>
                  <InfoRow label="Contato de emergência">{client.emergencyContact}</InfoRow>
                  <InfoRow label="Como conheceu">{client.source ? CLIENT_SOURCE_LABEL[client.source] : ""}</InfoRow>
                  <InfoRow label="Cliente desde">{formatShortDate(client.createdAt, tz)}</InfoRow>
                </dl>
              </CardContent>
            </Card>

            <div className="space-y-6">
              <Card className={cn((m.kind === "due" || m.kind === "overdue") && "border-gold/60")}>
                <CardHeader>
                  <CardTitle>Manutenção sugerida</CardTitle>
                  <RefreshCcw aria-hidden className="size-4.5 text-gold-ink" />
                </CardHeader>
                <CardContent className="pt-2 text-sm text-ink/85">{maintenanceText}</CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Resumo</CardTitle>
                </CardHeader>
                <CardContent className="grid grid-cols-3 gap-3 pt-3 text-center">
                  {[
                    ["Concluídos", completedCount],
                    ["Cancelamentos", overview.timeline.cancellations],
                    ["Faltas", overview.timeline.noShows],
                  ].map(([label, value]) => (
                    <div key={label} className="rounded-xl bg-sand/50 px-2 py-3">
                      <p className="tabular text-xl font-semibold text-brown">{value}</p>
                      <p className="text-xs text-muted">{label}</p>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {client.sensitivities && (
                <p className="flex items-center gap-2 rounded-xl border border-mauve/30 bg-mauve-soft/50 px-4 py-3 text-sm text-mauve">
                  <LockKeyhole aria-hidden className="size-4" />
                  Há alergias ou sensibilidades registradas. Veja na aba Observações.
                </p>
              )}
            </div>

            <div className="space-y-3 lg:col-span-2">
              <h2 className="text-sm font-semibold text-brown">Próximos horários</h2>
              <ClientAppointmentsList appointments={upcoming.slice(0, 3)} timezone={tz} emptyText="Nenhum horário marcado." />
              <h2 className="pt-3 text-sm font-semibold text-brown">Últimos atendimentos</h2>
              <ClientAppointmentsList
                appointments={history.filter((a) => a.status === "completed").slice(0, 3)}
                timezone={tz}
                emptyText="Nenhum atendimento concluído ainda."
              />
            </div>
          </div>
        </TabsContent>

        <TabsContent value="agendamentos">
          <ClientAppointmentsList appointments={upcoming} timezone={tz} emptyText="Nenhum horário marcado." />
        </TabsContent>

        <TabsContent value="historico">
          <ClientAppointmentsList
            appointments={history}
            timezone={tz}
            emptyText="Sem histórico ainda. Atendimentos, cancelamentos e faltas aparecem aqui."
          />
        </TabsContent>

        <TabsContent value="observacoes" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Observações</CardTitle>
            </CardHeader>
            <CardContent className="pt-2 text-sm whitespace-pre-line text-ink/85">
              {client.notes ?? "Nenhuma observação registrada."}
            </CardContent>
          </Card>

          <RestrictedBlock title="Alergias ou sensibilidades informadas">
            {client.sensitivities ? (
              revealRestricted ? (
                <div className="space-y-3">
                  <p className="rounded-xl bg-surface p-3.5 text-sm whitespace-pre-line text-ink">{client.sensitivities}</p>
                  <Button size="sm" variant="secondary" onClick={() => setRevealRestricted(false)}>
                    <EyeOff aria-hidden />
                    Ocultar
                  </Button>
                </div>
              ) : (
                <Button size="sm" variant="secondary" onClick={() => setRevealRestricted(true)}>
                  <Eye aria-hidden />
                  Mostrar informação restrita
                </Button>
              )
            ) : (
              <p className="text-sm text-ink/70">Nada informado.</p>
            )}
          </RestrictedBlock>
          <p className="text-xs text-muted">Fotos e fichas de anamnese entram em etapa futura, junto com o termo de consentimento.</p>
        </TabsContent>
      </Tabs>

      <ResponsiveDialog open={editing} onOpenChange={setEditing} title="Editar cliente" desktop="drawer" rawContent>
        {editing && (
          <ClientForm
            client={client}
            services={services}
            variant="dialog"
            onCancel={() => setEditing(false)}
            onSaved={() => {
              setEditing(false);
              query.reload();
            }}
          />
        )}
      </ResponsiveDialog>

      <ConfirmDialog
        open={confirmToggle}
        onOpenChange={setConfirmToggle}
        title={client.active ? "Desativar cliente?" : "Reativar cliente?"}
        description={
          client.active
            ? "Ela deixa de aparecer na agenda e nas buscas de clientes ativas. O histórico é mantido e você pode reativar quando quiser."
            : "Ela volta a aparecer na agenda e nas buscas."
        }
        confirmLabel={client.active ? "Desativar" : "Reativar"}
        onConfirm={async () => {
          await repositories.clients.setActive(tenant.id, client.id, !client.active);
          query.reload();
        }}
      />
    </div>
  );
}
