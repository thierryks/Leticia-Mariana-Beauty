import { RefreshCcw, Sparkle, UserCheck, UserX } from "lucide-react";
import { ToneBadge } from "@/components/shared/status-badge";
import type { ClientOverview } from "@/features/clients/overview";

/** Situação da cliente: sempre com texto (nunca só cor). */
export function ClientStatusBadges({ overview }: { overview: ClientOverview }) {
  const { client, maintenance, isNew } = overview;
  return (
    <span className="flex flex-wrap gap-1.5">
      {client.active ? (
        <ToneBadge tone="sage" icon={UserCheck}>
          Ativa
        </ToneBadge>
      ) : (
        <ToneBadge tone="slate" icon={UserX}>
          Inativa
        </ToneBadge>
      )}
      {client.active && isNew && (
        <ToneBadge tone="gold" icon={Sparkle}>
          Nova
        </ToneBadge>
      )}
      {client.active && maintenance.kind === "due" && (
        <ToneBadge tone="amber" icon={RefreshCcw}>
          Manutenção no prazo
        </ToneBadge>
      )}
      {client.active && maintenance.kind === "overdue" && (
        <ToneBadge tone="clay" icon={RefreshCcw}>
          Manutenção atrasada
        </ToneBadge>
      )}
    </span>
  );
}
