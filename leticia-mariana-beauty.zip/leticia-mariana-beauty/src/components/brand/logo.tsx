import { cn } from "@/lib/utils";

/**
 * Monograma "LM" do brand book: letras em Cinzel com o traço dourado
 * que nasce da perna do L, como um fio de cílio.
 */
export function Monogram({ className, title = "Letícia Mariana Beauty" }: { className?: string; title?: string }) {
  return (
    <svg viewBox="0 0 64 64" role="img" aria-label={title} className={cn("text-gold", className)}>
      <text
        x="10"
        y="44"
        fill="currentColor"
        style={{ fontFamily: "var(--font-display)", fontSize: 38, fontWeight: 500 }}
      >
        L
      </text>
      <text
        x="22"
        y="40"
        fill="currentColor"
        style={{ fontFamily: "var(--font-display)", fontSize: 30, fontWeight: 500 }}
      >
        M
      </text>
      <path
        d="M14 47 C 26 53, 40 52, 54 40"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.4"
        strokeLinecap="round"
      />
    </svg>
  );
}

export function Wordmark({ className, compact = false }: { className?: string; compact?: boolean }) {
  return (
    <div className={cn("flex items-center gap-3", className)}>
      <Monogram className={compact ? "size-10" : "size-12"} />
      <div className="leading-none">
        <p className="brand-title text-[0.95rem] tracking-[0.16em] whitespace-nowrap text-brown">Letícia Mariana</p>
        <p className="mt-1.5 text-[0.62rem] font-medium tracking-[0.42em] text-gold-ink">BEAUTY</p>
      </div>
    </div>
  );
}
