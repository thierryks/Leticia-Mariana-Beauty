import type { ComponentProps } from "react";
import { cn } from "@/lib/utils";

export const fieldBase =
  "w-full min-w-0 rounded-[var(--radius-field)] border border-sand-strong bg-surface px-3.5 text-[0.9375rem] text-ink placeholder:text-muted/80 transition-colors outline-none focus-visible:border-gold-ink focus-visible:outline-2 focus-visible:outline-offset-0 focus-visible:outline-gold/40 disabled:cursor-not-allowed disabled:bg-sand/40 disabled:opacity-70 aria-invalid:border-clay aria-invalid:focus-visible:outline-clay/30";

export function Input({ className, type = "text", ...props }: ComponentProps<"input">) {
  return <input data-slot="input" type={type} className={cn(fieldBase, "h-11", className)} {...props} />;
}
