import type { ComponentProps } from "react";
import { cn } from "@/lib/utils";
import { fieldBase } from "./input";

export function Textarea({ className, rows = 3, ...props }: ComponentProps<"textarea">) {
  return <textarea data-slot="textarea" rows={rows} className={cn(fieldBase, "py-2.5 leading-relaxed", className)} {...props} />;
}
