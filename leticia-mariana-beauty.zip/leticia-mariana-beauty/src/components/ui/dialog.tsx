"use client";

import { X } from "lucide-react";
import { Dialog as DialogPrimitive } from "radix-ui";
import type { ComponentProps } from "react";
import { cn } from "@/lib/utils";

export const Dialog = DialogPrimitive.Root;
export const DialogTrigger = DialogPrimitive.Trigger;
export const DialogClose = DialogPrimitive.Close;

export function DialogOverlay({ className, ...props }: ComponentProps<typeof DialogPrimitive.Overlay>) {
  return (
    <DialogPrimitive.Overlay
      className={cn(
        "fixed inset-0 z-50 bg-brown-deep/35 backdrop-blur-[2px]",
        className,
      )}
      {...props}
    />
  );
}

type Side = "center" | "right" | "left" | "bottom";

const sideClasses: Record<Side, string> = {
  center:
    "top-1/2 left-1/2 w-[calc(100%-2rem)] max-w-lg -translate-x-1/2 -translate-y-1/2 rounded-[18px] max-h-[calc(100dvh-2rem)]",
  right: "inset-y-0 right-0 w-full max-w-md rounded-l-[18px]",
  left: "inset-y-0 left-0 w-[86%] max-w-xs rounded-r-[18px]",
  bottom: "inset-x-0 bottom-0 max-h-[92dvh] rounded-t-[20px]",
};

export interface DialogContentProps extends ComponentProps<typeof DialogPrimitive.Content> {
  side?: Side;
  hideClose?: boolean;
}

export function DialogContent({ className, children, side = "center", hideClose, ...props }: DialogContentProps) {
  return (
    <DialogPrimitive.Portal>
      <DialogOverlay />
      <DialogPrimitive.Content
        className={cn(
          "fixed z-50 flex flex-col overflow-hidden border border-line bg-background shadow-[0_24px_60px_-20px_rgb(68_55_43/0.45)] outline-none",
          sideClasses[side],
          className,
        )}
        {...props}
      >
        {children}
        {!hideClose && (
          <DialogPrimitive.Close
            className="absolute top-3.5 right-3.5 inline-flex size-10 items-center justify-center rounded-full text-muted transition-colors hover:bg-sand hover:text-brown"
            aria-label="Fechar"
          >
            <X className="size-5" aria-hidden />
          </DialogPrimitive.Close>
        )}
      </DialogPrimitive.Content>
    </DialogPrimitive.Portal>
  );
}

export function DialogHeader({ className, ...props }: ComponentProps<"div">) {
  return <div className={cn("border-b border-line px-5 pt-5 pb-4 pr-16 sm:px-6", className)} {...props} />;
}

export function DialogBody({ className, ...props }: ComponentProps<"div">) {
  return <div className={cn("flex-1 overflow-y-auto px-5 py-5 sm:px-6", className)} {...props} />;
}

export function DialogFooter({ className, ...props }: ComponentProps<"div">) {
  return (
    <div
      className={cn(
        "flex flex-col-reverse gap-2 border-t border-line bg-surface px-5 py-4 sm:flex-row sm:justify-end sm:px-6",
        className,
      )}
      {...props}
    />
  );
}

export function DialogTitle({ className, ...props }: ComponentProps<typeof DialogPrimitive.Title>) {
  return <DialogPrimitive.Title className={cn("brand-title text-lg text-brown", className)} {...props} />;
}

export function DialogDescription({ className, ...props }: ComponentProps<typeof DialogPrimitive.Description>) {
  return <DialogPrimitive.Description className={cn("mt-1 text-sm text-muted", className)} {...props} />;
}
