"use client";

import { LogOut, ShieldCheck } from "lucide-react";
import { useRouter } from "next/navigation";
import type { ReactNode } from "react";
import { PageHeader } from "@/components/shared/page-header";
import { ErrorState, LoadingState } from "@/components/shared/states";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { demoAuthAdapter } from "@/features/auth/demo-auth-adapter";
import { useSession } from "@/features/tenant/session-context";
import { useAsyncData } from "@/hooks/use-async-data";
import { STUDIO_SETTINGS } from "@/lib/constants/studio";
import { repositories } from "@/repositories";

const WEEKDAY_NAMES = ["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"];

function workingDaysLabel(days: readonly number[]) {
  const sorted = [...days].sort((a, b) => a - b);
  const names = sorted.map((d) => WEEKDAY_NAMES[d]);
  const contiguous = sorted.every((d, i) => i === 0 || d === sorted[i - 1]! + 1);
  if (contiguous && names.length > 2) return `${names[0]} a ${names[names.length - 1]!.toLowerCase()}`;
  return names.join(", ");
}

function Row({ label, value }: { label: string; value: ReactNode }) {
  return (
    <div className="grid grid-cols-[minmax(0,10rem)_1fr] gap-4 py-3 text-sm first:pt-0 last:pb-0">
      <dt className="text-muted">{label}</dt>
      <dd className="min-w-0 font-medium text-brown">{value}</dd>
    </div>
  );
}

function Section({ title, description, children }: { title: string; description?: string; children: ReactNode }) {
  return (
    <Card>
      <CardHeader>
        <div>
          <CardTitle>{title}</CardTitle>
          {description && <CardDescription>{description}</CardDescription>}
        </div>
      </CardHeader>
      <CardContent>{children}</CardContent>
    </Card>
  );
}

export function SettingsView() {
  const { user, tenant } = useSession();
  const router = useRouter();
  const professionals = useAsyncData(`settings-professionals:${tenant.id}`, () =>
    repositories.professionals.list(tenant.id),
  );

  return (
    <div className="space-y-6">
      <PageHeader
        title="Configurações"
        description="Dados do studio, regras da agenda e da sua conta. Nesta etapa os valores são fixos; a edição chega com o banco de dados."
      />

      <div className="grid gap-6 lg:grid-cols-2">
        <Section title="Studio" description="Identificação usada nos relatórios e mensagens.">
          <dl className="divide-y divide-line">
            <Row label="Nome" value={tenant.name} />
            <Row label="Identificador" value={<span className="tabular">{tenant.slug}</span>} />
            <Row label="Fuso horário" value={tenant.timezone} />
            <Row label="Moeda" value="Real (BRL)" />
          </dl>
        </Section>

        <Section title="Agenda" description="Regras usadas para horários livres e lembretes.">
          <dl className="divide-y divide-line">
            <Row
              label="Atendimento"
              value={`${workingDaysLabel(STUDIO_SETTINGS.workingWeekdays)}, das ${STUDIO_SETTINGS.openingTime} às ${STUDIO_SETTINGS.closingTime}`}
            />
            <Row label="Intervalo entre horários" value={`${STUDIO_SETTINGS.slotStepMinutes} minutos`} />
            <Row label="Menor janela livre" value={`${STUDIO_SETTINGS.minFreeSlotMinutes} minutos`} />
            <Row
              label="Manutenção sugerida"
              value={`${STUDIO_SETTINGS.maintenanceWindowDays.from} a ${STUDIO_SETTINGS.maintenanceWindowDays.to} dias após extensão ou manutenção`}
            />
            <Row label="Cliente nova" value={`${STUDIO_SETTINGS.newClientDays} dias após o cadastro`} />
          </dl>
        </Section>

        <Section title="Profissionais" description="Quem aparece na agenda e nos agendamentos.">
          {professionals.error && <ErrorState onRetry={professionals.reload} />}
          {!professionals.error && !professionals.data && <LoadingState rows={2} label="Carregando profissionais…" />}
          {professionals.data && (
            <ul className="divide-y divide-line">
              {professionals.data.map((p) => (
                <li key={p.id} className="flex items-center justify-between gap-3 py-3 first:pt-0 last:pb-0 text-sm">
                  <span className="font-medium text-brown">{p.name}</span>
                  <span className={p.active ? "text-sage" : "text-muted"}>{p.active ? "Ativa" : "Inativa"}</span>
                </li>
              ))}
            </ul>
          )}
        </Section>

        <Section title="Conta" description={`Conectada como ${user.userName}.`}>
          <Button
            variant="secondary"
            onClick={() => {
              demoAuthAdapter.signOut();
              router.replace("/login");
            }}
          >
            <LogOut aria-hidden />
            Sair do sistema
          </Button>
        </Section>

        <Section title="Privacidade e dados" description="Como o sistema trata os dados das clientes.">
          <ul className="space-y-3 text-sm text-ink/85">
            <li className="flex gap-3">
              <ShieldCheck aria-hidden className="mt-0.5 size-4 shrink-0 text-sage" />
              Alergias e sensibilidades ficam num bloco restrito e só aparecem sob clique.
            </li>
            <li className="flex gap-3">
              <ShieldCheck aria-hidden className="mt-0.5 size-4 shrink-0 text-sage" />
              Clientes são desativadas, nunca apagadas. O histórico fica preservado.
            </li>
            <li className="flex gap-3">
              <ShieldCheck aria-hidden className="mt-0.5 size-4 shrink-0 text-sage" />
              Nesta etapa todos os dados são fictícios e ficam só no navegador.
            </li>
          </ul>
        </Section>
      </div>
    </div>
  );
}
