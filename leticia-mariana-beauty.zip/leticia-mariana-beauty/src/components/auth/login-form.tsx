"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { Eye, EyeOff, LoaderCircle } from "lucide-react";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Controller, useForm } from "react-hook-form";
import { FormField } from "@/components/shared/form-field";
import { PhoneInput } from "@/components/shared/phone-input";
import { FormAlert } from "@/components/shared/states";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { AuthError, demoAuthAdapter } from "@/features/auth/demo-auth-adapter";
import { loginSchema, type LoginFormValues } from "@/lib/validators/auth";

export function LoginForm() {
  const router = useRouter();
  const [showPassword, setShowPassword] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [showRecovery, setShowRecovery] = useState(false);

  const {
    control,
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: { phone: "", password: "" },
    mode: "onTouched",
  });

  const onSubmit = handleSubmit(async ({ phone, password }) => {
    setAuthError(null);
    try {
      await demoAuthAdapter.signIn(phone, password);
      router.replace("/dashboard");
    } catch (error) {
      // Nunca registrar a senha ou o telefone em log.
      setAuthError(error instanceof AuthError ? error.message : "Não foi possível entrar agora. Tente de novo.");
    }
  });

  return (
    <form onSubmit={onSubmit} noValidate className="space-y-5" aria-busy={isSubmitting}>
      {authError && <FormAlert title={authError} />}

      <Controller
        control={control}
        name="phone"
        render={({ field }) => (
          <FormField label="Telefone" error={errors.phone?.message}>
            <PhoneInput
              name={field.name}
              value={field.value}
              onChange={field.onChange}
              onBlur={field.onBlur}
              ref={field.ref}
              autoComplete="username"
              disabled={isSubmitting}
            />
          </FormField>
        )}
      />

      <div className="space-y-1.5">
        <div className="relative">
          <FormField label="Senha" error={errors.password?.message}>
            <Input
              type={showPassword ? "text" : "password"}
              autoComplete="current-password"
              disabled={isSubmitting}
              className="pr-12"
              {...register("password")}
            />
          </FormField>
          <button
            type="button"
            onClick={() => setShowPassword((v) => !v)}
            aria-label={showPassword ? "Ocultar senha" : "Mostrar senha"}
            aria-pressed={showPassword}
            className="absolute top-[1.75rem] right-1 inline-flex size-10 items-center justify-center rounded-full text-muted hover:bg-sand hover:text-brown"
          >
            {showPassword ? <EyeOff aria-hidden className="size-4.5" /> : <Eye aria-hidden className="size-4.5" />}
          </button>
        </div>
        <div className="flex justify-end">
          <button
            type="button"
            onClick={() => setShowRecovery((v) => !v)}
            aria-expanded={showRecovery}
            className="text-sm text-gold-ink underline-offset-4 hover:underline"
          >
            Esqueci minha senha
          </button>
        </div>
        {showRecovery && (
          <p role="status" className="rounded-xl bg-sand/70 px-3.5 py-3 text-sm text-ink/80">
            A recuperação de acesso por código chega na próxima etapa. Por enquanto, fale com o suporte do sistema.
          </p>
        )}
      </div>

      <Button type="submit" size="lg" className="w-full" disabled={isSubmitting}>
        {isSubmitting ? (
          <>
            <LoaderCircle aria-hidden className="animate-spin" />
            Entrando…
          </>
        ) : (
          "Entrar"
        )}
      </Button>
    </form>
  );
}
