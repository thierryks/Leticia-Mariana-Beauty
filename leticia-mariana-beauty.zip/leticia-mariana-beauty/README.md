# Letícia Mariana Beauty — Sistema de gestão (Etapa 1)

Sistema web responsivo para o studio de extensão de cílios **Letícia Mariana Beauty**: agenda, clientes e serviços, com estrutura multiempresa pronta para virar SaaS.

Esta etapa roda **apenas com dados demonstrativos** (fictícios), guardados na memória do navegador. Recarregar a página restaura os dados originais.

## Como rodar no seu computador

Requisitos: **Node.js 20.9 ou mais recente** e npm.

```bash
npm install
npm run dev
```

Abra <http://localhost:3000>. Para entrar na demonstração:

| Campo    | Valor             |
| -------- | ----------------- |
| Telefone | `(21) 90000-0000` |
| Senha    | `cilios2026`      |

A senha de demonstração não aparece na interface e não fica em texto no código (a comparação é feita por hash).

### Verificações

```bash
npm run typecheck   # TypeScript (strict)
npm run lint        # ESLint (regras do Next.js)
npm run test        # Vitest — regras de agenda, BRL, telefone, validação, tenant
npm run build       # build de produção
npm run check       # tudo acima, em sequência
```

## O que já funciona

- **Login** por telefone e senha (simulado), com validação, mostrar/ocultar senha, carregamento e bloqueio após 5 tentativas.
- **Layout** com menu lateral fixo no desktop e menu em gaveta no celular/tablet; busca de clientes no topo; botão "Novo agendamento" sempre à mão no celular.
- **Dashboard**: saudação, data, indicadores do dia, agenda de hoje, alertas e atalhos.
- **Agenda**: visão por dia, navegação entre dias, filtros por profissional e status, horários livres, detalhes e criação de agendamento com **bloqueio de conflito**.
- **Novo agendamento**: o seletor de horário mostra só os horários livres da profissional, para o serviço e o dia escolhidos (cancelados e faltas não ocupam).
- **Clientes**: busca (sem acento, por nome ou telefone), filtros, tabela no desktop e cartões no celular, paginação, cadastro com alerta de telefone duplicado, perfil com abas e desativação (sem exclusão).
- **Serviços**: cards, busca, filtro ativo/inativo, cadastro e edição.
- **Financeiro**: previsto, sinais recebidos e pendentes, concluídos, movimento por dia e sinais a receber, por hoje, semana ou mês. Sem registro de pagamentos ainda.
- **Configurações**: dados do studio, regras da agenda, profissionais e saída. Valores fixos nesta etapa.

## Regras importantes

- **Horário final** = início + duração + intervalo de preparo.
- **Conflito**: duas marcações ativas da mesma profissional não podem se sobrepor. Cancelados, remarcados e faltas liberam o horário. A regra roda ao vivo no formulário **e de novo ao salvar** (`src/features/appointments/rules.ts`).
- **Dinheiro** sempre em centavos inteiros; exibição em BRL.
- **Datas** salvas em UTC e exibidas no fuso da empresa (`America/Sao_Paulo`), semana começando na segunda.
- **Manutenção** sugerida entre 15 e 20 dias após extensão ou manutenção (remoção não conta), conforme a política do brand book.
- **Multiempresa**: todo registro tem `tenantId` e toda leitura passa por `scopeToTenant`. Os mocks incluem uma segunda empresa só para provar o isolamento.
- **LGPD**: alergias/sensibilidades ficam em bloco restrito e só aparecem sob clique; nada pessoal vai para logs; clientes são desativadas, nunca apagadas.

## Estrutura

```
src/
  app/                 rotas (App Router)
    (auth)/login       tela de login
    (dashboard)/       área logada: dashboard, agenda, clientes, serviços
  components/
    ui/                componentes base no padrão shadcn/ui (Radix)
    shared/            cabeçalho, indicadores, status, estados, campos, dialogs, filtros, tabela
    layout/ brand/ auth/ dashboard/ agenda/ clientes/ servicos/
  features/            regras de negócio puras (agenda, clientes, dashboard, auth, tenant)
  lib/                 formatadores, validadores (Zod), datas, constantes
  repositories/        contratos da camada de dados + implementação mock
  mocks/               dados demonstrativos
  types/               modelos TypeScript
tests/                 testes Vitest
```

## Decisões e hipóteses

- **Visual**: segue o brand book (bege `#EDE4D9`, off-white `#F9F8F4`, dourado `#D4AF37`, marrom `#5B4A3B`, Cinzel + Montserrat, Allura nas frases da marca) em vez do roxo descrito no briefing. O dourado puro é só ornamento; texto dourado usa um tom escurecido com contraste AA.
- **Fontes** vêm do npm (`@fontsource`), sem depender do Google Fonts no build.
- **shadcn/ui**: os componentes foram escritos no padrão do shadcn (Radix + `cva` + `tailwind-merge`) e o `components.json` já está pronto para usar `npx shadcn add` depois.
- **Selects nativos** nos formulários: melhores no celular e acessíveis por padrão.
- "**Pagamentos pendentes**" no dashboard = sinais pendentes, até o módulo financeiro existir.
- Status que liberam a agenda: cancelado (cliente ou studio), remarcado e falta.
- Serviços e preços nos mocks são **fictícios**.

## Limitações desta etapa

- Sem banco de dados: tudo some ao recarregar.
- Login simulado no navegador (não é autenticação de produção).
- Ainda não dá para mudar status, remarcar ou cancelar um agendamento existente.
- "Bloquear horário" e Relatórios aparecem como "Em breve".
- Alertas de estoque e de lembrete são exemplos fixos.

## Próximos passos recomendados

1. **Supabase**: tabelas com `tenant_id`, Row Level Security por empresa, Auth por telefone com cookies httpOnly, e a regra de conflito no banco (exclusion constraint em `tstzrange`). Os pontos estão comentados em `src/repositories/*` e `src/features/appointments/rules.ts`.
2. **Ciclo do atendimento**: confirmar, iniciar, concluir, cancelar e remarcar com histórico de alterações (auditoria), além de bloqueios e folgas na agenda.
3. **Lembretes pelo WhatsApp e sinal**: fila de mensagens com registro de envio/falha e controle do sinal ligado ao financeiro.

## Migrar para Supabase sem mexer nas telas

As telas só falam com `src/repositories/index.ts`. Para trocar:

1. Crie `src/repositories/supabase/*` implementando as mesmas interfaces (`AppointmentRepository`, `ClientRepository`, …).
2. Troque as atribuições em `src/repositories/index.ts`.
3. Substitua `src/features/auth/demo-auth-adapter.ts` pelo Supabase Auth.

Nunca coloque a service role key no cliente nem em variáveis `NEXT_PUBLIC_`.
